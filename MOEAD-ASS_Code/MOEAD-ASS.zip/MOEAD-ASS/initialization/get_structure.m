function str = get_structure(name)
%STRUCTURE Summary of this function goes here
% 
% Structure used in this toolbox.
% 
% individual structure:
% parameter: the parameter space point of the individual. it's a column-wise
% vector.
% objective: the objective space point of the individual. it's column-wise
% vector. It only have value after evaluate function is called upon the
% individual.
%
% subproblem structure:
% weight: the decomposition weight for the subproblem.
% neighbour: the index of the neighbour of this subproblem.
% optimal: the current optimal value of the current structure. 
% curpoiont: the current individual of the subproblem.
% oldpoint: the backup individual of the subproblem used to caculate the
% utility.
% utility: the searching utility of this subproblem.
%
% testmop structure:
% name: the name of the test problem.
% od: the number of objective.
% pd: the number of variable.
% domain: the domain, which is a pd*2 matrix, with domain(:,1) and
% domain(:,2) to specificy the lower and upper limit on every variable.
%
% parameter strucutre.
% the parameter setting structure is explained in loadpapams.m
%
%

switch name
    case 'individual' 
        str = struct('parameter',[],'objective',[]);
    case 'PreSubp' 
        str = struct('PrePoints',[],'LCBs',[],'OptimumIdx',[],'OptimumPara',[],'subpmin',[]);        
    case 'subproblem' 
        str = struct('weight',[],'direction',[],'directlength',[],'neighbors',[],...
        'curpoint',[],'subpmin',[],'subpobjs',[],'prescreenFit',[],'evalTimes',0);
    case 'parameter'
        str = struct('evaluation',200,'Dmethod','tch','L1',80,'L2',20,'Ke',5,...
            'DE_Pop',20,'DE_Gens',50,'DE_CR',0.1,'DE_F',0.5,'MOEAD_Gens',500,...
        'MOEAD_CR',1.0,'MOEAD_F',0.5,'MOEAD_NeiSize',20,'MOEAD_NeiUseR',0.9,'MOEAD_UpSize',2);
    case 'CModel'
        str = struct('center',[],'idx',[],'model',[]);   
    case 'GPmodel'
        str = struct('regr','regpoly0','corr','corrgauss','ThetaP',[],...
            'p',[],'beta',[],'gamma',[],'sigma2',0.0,'S',[],...
        'Ssc',[],'Ysc',[],'C',[],'Ft',[],'G',[],'perf',[]); 
    case 'PreInd' 
        str = struct('parameter',[],'PredObj',[],'PredVar',[]);
    case 'hyperparams'    
        str = struct('mean', [], 'cov', [], 'lik', []);   
    case 'post'    
        str = struct('alpha', [], 'sW', [], 'L', []);          
    otherwise
        error('the structure name requried does not exist!');
end