function K = MTGP_Bonilla_covSEard(hyp, x, z, i)
% Squared Exponential covariance function with isotropic distance and scaling
% measure. 
%
% Based on the covSEisoU.m function of the GPML Toolbox - 
%   with the following changes:
%       - only elements of x(:,1:end-1)/z(:,1:end-1) will be analyzed, 
%       - x(:,end)/z(:,end) will be ignored, as it contains only the label information
%       - independent of the label all x values will have the same hyp
%       - output-scaling hyperparameter is fixed to 1
%
% The covariance function is parameterized as:
%
% k(x^p,x^q) = exp(-(x^p - x^q)'*inv(P)*(x^p - x^q)/2) 
%
% where the P matrix is ell^2 times the unit matrix.
% The hyperparameters are:
%
% hyp = [ (theta_c,1)
%         (theta_c,2)
%           ...
%         (theta_c,k)
%         log(ell1_1)
%         log(ell1_2)
%          .
%         log(ell1_D)
%         log(sqrt(sf2_1))]
%
% by Haitao Liu
% 2017/03/02

if nargin<2, K = 'sum([1:nL])+D+1'; return; end                  % report number of parameters
if nargin<3, z = []; end                                   % make sure, z exists
xeqz = numel(z)==0; dg = strcmp(z,'diag') && numel(z)>0;        % determine mode

D = size(x(:,1:end-1),2) ;
nL = max(x(:,end));

T = nL*(nL+1)/2;
rou = hyp(1:T) ;
ell1 = hyp(T+1:T+D);                                 % characteristic length scale
sf2_1 = hyp(T+D+1) ;

% precompute squared distances
if nargin < 4
  K = MTGP_covCC_chol_nD(rou,x,z).*MTGP_covSEard([ell1;sf2_1],x,z) ;
else                                                               % derivatives
  if i <= T
	K = MTGP_covCC_chol_nD(rou,x,z,i).*MTGP_covSEard([ell1;sf2_1],x,z) ;
  elseif i >= T+1 && i <= T+D+1
	K = MTGP_covCC_chol_nD(rou,x,z).*MTGP_covSEard([ell1;sf2_1],x,z,i-T) ;
  else
    error('Unknown hyperparameter')
  end
end