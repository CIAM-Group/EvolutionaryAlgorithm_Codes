function model = mySTGP(S,Y,opts,index)

Ss{1} = S ; Yy{1} = Y ;
num_task = 1 ;
dim = size(S,2) ;

ell = opts.ell ; sf2 = opts.sf2 ; sn2 = opts.sn2 ;
hyp.cov = [log(ell) log(sqrt(sf2(index)))] ;
hyp.lik = log(sqrt(sn2))*ones(num_task,1) ;

MTGP_mode = opts.MTGP_mode ;
switch MTGP_mode
    case 'MTGP_diff_sn2' % functions with different noise variances for the tasks
        meanfunc = [] ;
        likfunc = @likGauss_diffsn2_my;
        inffunc = @MTGP_infExact_diffsn2_my ;
        GPfunc = @MTGP_diffsn2_my ;
        hyp.lik = log(sqrt(sn2)); % must be D*1 vector
    case 'MTGP_no_sn2' % functions with no noise variances
        meanfunc = [] ;
        likfunc = @likGauss_nosn2_my;
        inffunc = @MTGP_infExact_nosn2_my ;
        GPfunc = @MTGP_nosn2_my ;
        hyp.lik = [];
end

covfunc = 'MTGP_covSEard' ;

optSet.method = opts.method ; % 'GradientDescent', 'fmincon'
optSet.optimize = opts.optimize ;
optSet.numOptFC = opts.numOptFC ;
optSet.restarts = opts.restarts ;
optSet.Xnorm = opts.Xnorm  ;
optSet.Ynorm = opts.Ynorm ;

model = MTGP_freeform_fit(Ss,Yy,GPfunc,meanfunc,covfunc,likfunc,inffunc,hyp,optSet) ;

end % end main function