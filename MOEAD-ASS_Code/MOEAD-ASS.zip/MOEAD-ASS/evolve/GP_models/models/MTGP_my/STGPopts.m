function opts = STGPopts()
% set default options for STGP

% parameters for SE covariance function
opts.ell = 0.5 ; opts.sf2 = 0.5 ; opts.sn2 = 0.001 ;

% noise GP (default) or noise-free GP
opts.MTGP_mode = 'MTGP_diff_sn2' ;

% preprocess of training data
opts.Xnorm = 'N' ;
opts.Ynorm = 'Y' ;

% optimization settings
opts.method = 'GradientDescent' ; % 'GradientDescent', 'fmincon'
opts.optimize = 'on' ;
opts.numOptFC = 500 ;
opts.restarts = 0 ;

end