function [m,s2,p,rmse_test,raae_test,rmae_test,imse] = MTGP_freeform_predict(S_test,Y_test,model)
% Bonilla E V, Chai K M A, Williams C K I. Multi-task Gaussian process prediction[C]//NIPs. 2007, 20: 153-160.
% Use a multi-task GP model for prediction
% Inputs:
%         S_test: a cell in which S_test{i} means the test points for the ith task
%         Y_test: a cell in which Y_test{i} represents the responses of the sampled points S_test{i} for the ith task
%         model: a multi-task gaussian model obtained by MTGP_freeform_fit.m
% Outputs:
%          m: a cell in which m{i} is the predictions for S_test{i}
%          S2: a cell in which s2{i} is the prediction variances for S_test{i}
%          p:
%          rmse_test: a vector where rmse_test(i) is the rmse value of the GP model for the ith task
% By H.T. Liu 2017/01/20
%% prepare test data
x_test = [] ; y_test = [] ;
y_train_mean = model.y_train_mean ;
y_train_std = model.y_train_std ;
x_train_mean = model.x_train_mean ;
x_train_std = model.x_train_std ;
num_task = model.num_task ;
for i = 1:model.num_task
    x = [(S_test{i}-repmat(x_train_mean(i,:),size(S_test{i},1),1)) ./ repmat(x_train_std(i,:),size(S_test{i},1),1), i*ones(size(S_test{i},1),1)] ;
	%x = [S_test{i},i*ones(size(S_test{i},1),1)] ;
    x_test = [x_test;x] ;
    if ~isempty(Y_test)
	    y = (Y_test{i}-y_train_mean(i))/y_train_std(i) ;
        y_test = [y_test;y] ;
    else
        y_test = [] ;
    end
end

%% perform prediction
if isempty(Y_test)
    [results.m results.s2 fmu fs2 results.p] = feval(model.GPfunc,model.hyp, model.inffunc, model.meanfunc, model.covfunc, model.likfunc, ...
                                                model.x_train, model.y_train, x_test);
else
    [results.m results.s2 fmu fs2 results.p] = feval(model.GPfunc,model.hyp, model.inffunc, model.meanfunc, model.covfunc, model.likfunc, ...
                                                model.x_train, model.y_train, x_test, y_test);
end



%% reshape of results
index = 1 ;
if ~isempty(Y_test)
    rmse_test = zeros(num_task,1) ;
    raae_test = zeros(num_task,1) ;
    rmae_test = zeros(num_task,1) ;
    imse = zeros(num_task,1) ; 
else
    %warning('warning: no Y_test data to assess model accuracy. \n') ;
    rmse_test = [] ;
    raae_test = [] ;
    rmae_test = [] ;
    imse = [] ;
end

for i = 1:num_task
    num_i = size(S_test{i},1) ;
	m{i} = results.m(index:index+num_i-1)*y_train_std(i) + y_train_mean(i); % restore prediction mean
	%s2{i} = results.s2(index:index+num_i-1) ;
    s2{i} = results.s2(index:index+num_i-1)*y_train_std(i)^2 ; % restore prediction variance
    if ~isempty(Y_test)
        p{i} = exp(results.p(index:index+num_i-1)) ;
        rmse_test(i) = RMSE(Y_test{i},m{i}) ;
        raae_test(i) = RAAE(Y_test{i},m{i}) ;
        rmae_test(i) = RMAE(Y_test{i},m{i}) ;
        imse(i) = sqrt(mean(s2{i})) ;
    end
	index = index+num_i ;
end
end