function [EvaInds,Archive,subproblems,CosAngleMatrix]=init(mop,params)
%Set up the initial setting for the MOEA/D.
%loading the params.
global evalCounter itrCounter idealpoint;  
    evalCounter = 0;
    itrCounter = 1;
    idealpoint=ones(mop.od,2)*Inf;
    EvaInds=[];Archive=[];
  %initial the subproblems for MOEA/D-DE.
  subproblems = init_weights(params,mop.od);
  preInd=get_structure('PreInd');
  [subproblems.curpoint]=deal(preInd); 
  [subproblems.subpmin]=deal(Inf);
  [subproblems.evalTimes]=deal(0);
  %initial the population.
  initialSize=params.initsize;lowerbound=mop.domain(:,1);domains=mop.domain(:,2)-mop.domain(:,1);
  pop=lhsdesign(initialSize,mop.pd,'iterations',5).*repmat(domains',initialSize,1)+repmat(lowerbound',initialSize,1);
  indiv=get_structure('individual'); NewEvaInds=repmat(indiv,1,initialSize); NewIdealpoint=idealpoint(:,2); 
    for i=1:initialSize
      indiv.parameter=pop(i,:)';
      [v,ind]=evaluate(mop,indiv);
      NewEvaInds(i)=ind;
      NewIdealpoint=min(NewIdealpoint,v-(1e-6));
    end
  idealpoint(:,1)=idealpoint(:,2); idealpoint(:,2)=NewIdealpoint;  EvalSubps=[];CosAngleMatrix=[];
  [EvaInds,Archive,subproblems,CosAngleMatrix]=updateData(EvaInds,NewEvaInds,Archive,idealpoint,subproblems,CosAngleMatrix,EvalSubps);
end
function subp=init_weights(params,objDim)
% init_weights function initialize a pupulation of subproblems structure
% with the generated decomposition weight and the neighborhood relationship.
%initialize direction vectors with unity simplex;
%compute their neighborhood relationship and get their corresponding weight vectors
    H=params.MOEAD_H;
	M = simplex_weightno(H, 0, objDim); 
    W = zeros(objDim, M); C = 0; V = zeros(objDim,1);
    [W, ~] = simplex_weightset(W, C, V, H, 0, objDim, objDim);
    W = W/(H+0.0);
    v = squareform(pdist(W'));
    W((W==0))=1.0E-06; dirctlength=sqrt(sum(W.^2));
    Weights=1./W; Weights=Weights./repmat(sum(Weights),objDim,1);
    %Set up the neighbourhood.
    [~, neighborrelation]= sort(v);
    p=get_structure('subproblem'); subp=repmat(p,1,M);
    weightCells=num2cell(Weights,1);[subp.weight]=weightCells{:};
    directionCells=num2cell(W,1);[subp.direction]=directionCells{:};
    dirctlengthCells=num2cell(dirctlength);[subp.directlength]=dirctlengthCells{:};
%     neighborCells=num2cell(neighborrelation(1:params.MOEAD_NeiSize,:),1);[subp.neighbors]=neighborCells{:};
    neighborCells=num2cell(neighborrelation,1);[subp.neighbors]=neighborCells{:};
end
function M = simplex_weightno(unit, sum, dim)

M = 0;

if dim == 1
    M = 1; 
    return;
end

for i=0:1:(unit - sum)
    M = M + simplex_weightno(unit, sum+i, dim-1);
end

end
function [w, c] =simplex_weightset(w, c, v, unit, sum, objdim, dim)

if dim == objdim
    v = zeros(objdim, 1);
end

if dim == 1
    c       = c+1;
    v(1)    = unit-sum;
    w(:,c)  = v;
    return;
end

for i=0:1:(unit - sum)
    v(dim)  = i;
    [w, c]  = simplex_weightset(w, c, v, unit, sum+i, objdim, dim-1);
end

end