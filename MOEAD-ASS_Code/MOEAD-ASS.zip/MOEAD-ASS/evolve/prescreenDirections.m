function Selectdirections=prescreenDirections(params,CosAngleMatrix,Archive,subproblems)
[~,CloseDirs]=max(CosAngleMatrix,[],2);
ActDirs=unique(CloseDirs');
if length(subproblems)-length(ActDirs)>params.N_task
    RemainIdxes=setdiff(1:length(subproblems),ActDirs);
    ActDirs=[ActDirs,RemainIdxes(randperm(length(RemainIdxes),params.N_task))];
end
% also can use 0.1*length(ActDirs) or 2*N_task instead of N_task
Act_CosAngleMatrix=CosAngleMatrix(Archive,ActDirs);
evalTimes=[subproblems(ActDirs).evalTimes];
[Npoints,Ndirs]=size(Act_CosAngleMatrix);
AverageRanks=zeros(Npoints,Ndirs);
for i=1:Npoints
    [~,FarthestIdx]=sort(Act_CosAngleMatrix(i,:));
    AverageRanks(i,FarthestIdx)=(1:Ndirs)/Ndirs;
end
Fits=sum(AverageRanks.^100)+1.0*evalTimes;
% Fits=sum(exp(-400*(1-AverageRanks).^2));
SelectDirIdx=zeros(1,params.N_task);
cutvalue=1;
Divers_Idxes=find(Fits<cutvalue);
while length(Divers_Idxes)<params.N_task
    cutvalue=cutvalue*1.2;
    Divers_Idxes=find(Fits<cutvalue);
end
cluseridx=kmeans([subproblems(ActDirs(Divers_Idxes)).direction]',params.Ke);
for i=1:params.Ke
    idxes=Divers_Idxes(cluseridx==i);
    [~,DirIxs]=min(Fits(idxes));
    SelectDirIdx(i)=ActDirs(idxes(DirIxs));   
end
Selectdirections=SelectDirIdx;
end