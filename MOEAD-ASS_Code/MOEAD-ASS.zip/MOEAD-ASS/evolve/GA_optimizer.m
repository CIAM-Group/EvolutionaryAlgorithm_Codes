function CandInds=GA_optimizer(mop,params,subproblems,FalseTime,MTGP_model,Archive,EvaInds)
Task_PopSize=20;
Mut_initial=5;
Gens=10000;%In practice, 2000 is good enough
mu_rate=2/mop.pd;
if FalseTime(1)~=0
    Task_PopSize=ceil(Task_PopSize*(1.2^FalseTime(1)));
    mu_rate=min(1,2^(FalseTime(1)+1)/mop.pd);
end
%% %%%%%%%%%%%%%%%%%%%%%%---------Inilization
Subpsize=length(subproblems); subpmins=[subproblems.subpmin];
N_obj=params.N_obj; Archive_size=length(Archive); EP_size=size(EvaInds,2);
lowerbound=mop.domain(:,1);domains=mop.domain(:,2)-mop.domain(:,1); dims=mop.pd;
PreIndiv=get_structure('PreInd');
initialpop=cell(1,Subpsize);
for i=1:Subpsize
    initialSize=Task_PopSize-Mut_initial;
    pop=lhsdesign(initialSize,dims,'iterations',1).*repmat(domains',initialSize,1)+repmat(lowerbound',initialSize,1);
    objs=subobjective(subproblems(i).weight,[EvaInds.objective],params.Dmethod);
    [~,idx]=sort(objs);
    EliteInds=EvaInds(idx(1:Mut_initial));
    mut_pop=zeros(dims,Mut_initial);
    for mu_idx=1:Mut_initial
    mut_pop(:,mu_idx) = realmutate(EliteInds(mu_idx).parameter,mop.domain,mu_rate);
    end
    initialpop{i}=[pop',mut_pop];
end
parfor i=1:Subpsize
%     pops=repmat(lowerbound,1,Task_PopSize)+rand(dims,Task_PopSize).*repmat(domains,1,Task_PopSize);
    pops=initialpop{i};
    Inds=repmat(PreIndiv,Task_PopSize,1);
    [Ypred,Vpred] = predict_tasks(pops',MTGP_model,subproblems);
    for j=1:Task_PopSize
    Inds(j).parameter=pops(:,j);
    Inds(j).PredObj=Ypred{i}(j);
    Inds(j).PredVar=Vpred{i}(j);
    end
    Subp=get_structure('PreSubp');
    Subp.PrePoints=Inds;
    LCBs=LCBcalculation(Ypred{i},Vpred{i},subpmins(i),Archive_size,EP_size,N_obj);
    Subp.LCBs=LCBs;
    [~,OptimumIdx]=min(LCBs);
    Subp.OptimumIdx=OptimumIdx;
    Subp.OptimumPara=pops(:,OptimumIdx);
    Subp.subpmin=subpmins(i);
    Subp.weight=subproblems(i).weight;
    for gen_index=1:Gens%% Evolution
    ind=genetic_op(Subp,mop,mu_rate);% reproducation
    Subp=update(Subp,i,ind,MTGP_model,Task_PopSize,Archive_size,EP_size,N_obj);% repalcement
    end
    Subps{1,i}=Subp;  
end
for i=1:Subpsize
    subp=Subps{1,i};
    BestIndIndex=subp.OptimumIdx;
    Points=subp.PrePoints;
    subproblems(i).curpoint=Points(BestIndIndex);
    subproblems(i).PrePoints=Points;
    subproblems(i).LCBs=subp.LCBs;
    LCBs=subp.LCBs;
    subproblems(i).prescreenFit=LCBs(BestIndIndex);
    subproblems(i).evalTimes=subproblems(i).evalTimes+1; 
end
%% %%%%%%%%%%%%%%%%%%%------------>Prescreen<------------%%%%%%%%%%%%%%%%%%%%%%%
CandInds=prescreenSolutions(params,subproblems,EvaInds);
end
%% mating
function ind=genetic_op(subproblem,mop,mu_rate)
%% mating selection 
  points=subproblem.PrePoints;
  pops=[points.parameter];
  popsize=size(pops,2);
  MatPoolSize=4;
  idxes=randperm(popsize,MatPoolSize);
  parent=pops(:,idxes)';
  LCBs_tem=subproblem.LCBs;
  [~,ranks]=sort(LCBs_tem(idxes));
  temppoint=DE_SBXPM_geneticOps(parent,mop.domain(:,1)',mop.domain(:,2)',false,ranks);
  newpoint = realmutate(temppoint',mop.domain, mu_rate);
  ind = get_structure('PreInd');
  ind.parameter = newpoint;
end
%% replacing
function Subp=update(Subp,index,ind,MTGP_model,Task_PopSize,Archive_size,EP_size,N_obj)
  [Ypred,Vpred] = predict_tasks(ind.parameter.',MTGP_model,Subp);
  if strcmp(MTGP_model.method,'TrGP')
  predYs=Ypred{1};
  predVs=Vpred{1};
  else
  predYs=Ypred{index};
  predVs=Vpred{index};
  end
  minObjs=Subp.subpmin;
  OldLCBs=Subp.LCBs;
  LCBs=LCBcalculation(predYs,predVs,minObjs,Archive_size,EP_size,N_obj);
  NewLCBs=repmat(LCBs,Task_PopSize,1);
  C=NewLCBs<OldLCBs; %new solution is better?
  if any(C)
    toupdate = randsample(find(C),1);
    ind.PredObj=predYs;
    ind.PredVar=predVs;
    Oldpoints=Subp.PrePoints;
    Oldpoints(toupdate)=ind;
    Subp.PrePoints=Oldpoints;
    UpdateLCBs=NewLCBs(toupdate);
    if UpdateLCBs<OldLCBs(Subp.OptimumIdx)
       Subp.OptimumIdx=toupdate;
       Subp.OptimumPara=ind.parameter;
    end
    OldLCBs(toupdate)=UpdateLCBs;
	Subp.LCBs=OldLCBs;
  end
end
function LCBs=LCBcalculation(Ypred,Vpred,Objsmin,Archive_size,EP_size,N_obj)
ND_rate=Archive_size/EP_size;
differ=Objsmin-Ypred;
s=sqrt(Vpred);
gamma=10*exp(-0.02*Archive_size.^2)+0.1./(1+exp(-100*(differ)));
% gamma=10*exp(-80*ND_rate.^N_obj)+0.5./(1+exp(-80*(differ)));
LCBs=Ypred-gamma.*s-Objsmin;
end
function CandInds=prescreenSolutions(params,allsubproblems,EvaInds)
%% %%%%%%%%%%%%%%%%%%%------------>Expected Improvement Check<------------%%%%%%%%%%%%%%%%%%%%%%%
Logi_qualityCheck=[allsubproblems.prescreenFit]<Inf;
subproblems=allsubproblems(Logi_qualityCheck);
AllprescreenFits=[subproblems.LCBs];
Allpoints=[subproblems.PrePoints];
AllPointSize=size(AllprescreenFits,1);
prescreenSize=ceil(1.0*AllPointSize);
[val,pos]=sort(AllprescreenFits);
CandFits=val(1:prescreenSize,:);
CandPointsIdx=pos(1:prescreenSize,:);
Ind=get_structure('individual'); CandInds=[];CandInds2=[];
for level_idx=1:prescreenSize
prescreenFits=CandFits(level_idx,:); CandIdxes=CandPointsIdx(level_idx,:);
SubpSize=length(prescreenFits);
flag=true(1,SubpSize);
%% %%%%%%%%%%%%%%%%%%%------------>closenessFilter<------------%%%%%%%%%%%%%%%%%%%%%%%
for i=1:SubpSize
closeness=isclose(Allpoints(CandIdxes(i),i),EvaInds,1e-6);
if closeness %if it is too close to existing solutions?
    flag(i)=false;
end
end
 unfilterredIndex=find(flag); SelIndexOneLevel=[];SelIndexOneLevel2=[];
 while ~isempty(unfilterredIndex)
     selectedIndex=tournamentsel(prescreenFits(unfilterredIndex),unfilterredIndex,3);
     closeness=isclose(Allpoints(CandIdxes(selectedIndex),selectedIndex),CandInds,params.Mindiffer);
     closeness2=isclose(Allpoints(CandIdxes(selectedIndex),selectedIndex),CandInds2,1e-5);     
     if ~closeness %if it is close to newly generated solutions?
         Ind.parameter=Allpoints(CandIdxes(selectedIndex),selectedIndex).parameter;
         CandInds=[CandInds,Ind];
         SelIndexOneLevel=[SelIndexOneLevel,selectedIndex];
     elseif ~closeness2
         Ind.parameter=Allpoints(CandIdxes(selectedIndex),selectedIndex).parameter;
         CandInds2=[CandInds2,Ind];
         SelIndexOneLevel2=[SelIndexOneLevel2,selectedIndex];         
     end
     unfilterredIndex(unfilterredIndex==selectedIndex)=[];
 end
    Allpoints(:,SelIndexOneLevel)=[];
    CandFits(:,SelIndexOneLevel)=[];
    CandPointsIdx(:,SelIndexOneLevel)=[];
    if isempty(CandFits)||length(CandInds)>=params.Ke
        break;
    end
end
if isempty(CandInds)
    if isempty(CandInds2)
    fprintf('!!!!!!!!!!!there is a serious problem: no solution is generated in this iteration/n');
    else
    CandInds=CandInds2;
    fprintf('newly generated solutions are very close to the existing solutions!!!/n');
    end
end
end
function closeness=isclose(ind,inds,Mindiffer)
closeness=false;
for i=1:length(inds)
    closeness=sum((ind.parameter-inds(i).parameter).^2)<Mindiffer^2;
    if closeness
    break;
    end
end
end
function prescreenIdx=tournamentsel(prescreenvutil,idxes,tournamentsize)
    Nidxes=length(idxes);
    if Nidxes<tournamentsize
        perm=1:Nidxes;
    else
        perm=randperm(Nidxes,tournamentsize);
    end
    [~,idx]=min(prescreenvutil(perm));
    prescreenIdx=idxes(perm(idx));
end
function ind = realmutate(ind, domains, rate)
%REALMUTATE Summary of this function goes here
%   Detailed explanation goes here
  % double rnd, delta1, delta2, mut_pow, deltaq;
  % double y, yl, yu, val, xy;
  % double eta_m = id_mu;
  eta_m=20;
  if (isstruct(ind))
      a = ind.parameter;
  else
      a = ind;
  end
  for j = 1:length(a)
      r = rand;
      if (r <= rate) 
        y = a(j);
        yl = domains(j,1);
        yu = domains(j,2);
        delta1 = (y - yl) / (yu - yl);
        delta2 = (yu - y) / (yu - yl);
        rnd = rand;
        mut_pow = 1.0 / (eta_m + 1.0);
        if (rnd <= 0.5) 
	      xy = 1.0 - delta1;
	      val = 2.0 * rnd + (1.0 - 2.0 * rnd) * (xy^(eta_m + 1.0));
	      deltaq = (val^mut_pow) - 1.0;
        else 
	      xy = 1.0 - delta2;
	      val = 2.0 * (1.0 - rnd) + 2.0 * (rnd - 0.5) * (xy^ (eta_m + 1.0));
	      deltaq = 1.0 - (val^mut_pow);
        end
        y = y + deltaq * (yu - yl);
        if (y < yl)
	      y=yl+rand*(a(j)-yl);
        elseif (y > yu)
	      y=yu-rand*(yu-a(j));
        end
        a(j) = y;        
      end
  end
  if isstruct(ind)
      ind.parameter = a;
  else
      ind = a;
  end
end
