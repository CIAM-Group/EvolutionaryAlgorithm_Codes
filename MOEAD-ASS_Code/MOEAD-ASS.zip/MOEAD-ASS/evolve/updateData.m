function [AllEvaInds,NewArchive,subproblems,CosAngleMatrix]=updateData(EvaInds,NewEvaInds,OldArchive,idealpoint,subproblems,CosAngleMatrix,EvalSubps)
AllEvaInds=[EvaInds,NewEvaInds];
Noldinds=length(EvaInds);Nnewinds=length(NewEvaInds);NewIdx=Noldinds+(1:Nnewinds);
NewArchive=updateArchive(EvaInds,OldArchive,NewEvaInds,NewIdx);
if max(idealpoint(:,1)-idealpoint(:,2))>1e-5
    UpdateAll=true;
else
    UpdateAll=false;
end
[CosAngleMatrix,subproblems]=updateAngleSubps(CosAngleMatrix,subproblems,idealpoint(:,2),UpdateAll,EvaInds,NewEvaInds,EvalSubps);
end
function Archive=updateArchive(EvaInds,Archive,NewEvaInds,NewIdx)
if ~isempty(NewEvaInds)
if isempty(Archive)
Archive=NewIdx(1);NewIdx(1)=[];
EvaInds=NewEvaInds(1);NewEvaInds(1)=[];
end
ArchiveObjs=[EvaInds(Archive).objective];    
NewObjs=[NewEvaInds.objective];
while ~isempty(NewIdx)
    Objs=NewObjs(:,1);
    differ=ArchiveObjs-repmat(Objs,1,length(Archive));
    if ~any(all(differ<=0))
      if any(all(differ>=0))
          dominatingLogs=all(differ>0);
          Archive(dominatingLogs)=[];
          ArchiveObjs(:,dominatingLogs)=[];
          Archive=[Archive,NewIdx(1)];ArchiveObjs=[ArchiveObjs,NewObjs(:,1)];
      else
          Archive=[Archive,NewIdx(1)];ArchiveObjs=[ArchiveObjs,NewObjs(:,1)];
      end
    end
     NewIdx(1)=[];  NewObjs(:,1)=[];
end
end
end
function [CosAngleMatrix,subproblems]=updateAngleSubps(CosAngleMatrix,subproblems,idealpoint,UpdateAll,EvaInds,NewEvaInds,EvalSubps)
directions=[subproblems.direction]; Ndirections=size(directions,2); DirectLength=[subproblems.directlength];
if UpdateAll
    [subproblems.subpmin]=deal(Inf);
    [subproblems.evalTimes]=deal(0);
    ReEvalInds=[EvaInds,NewEvaInds];
    Npoints=length(ReEvalInds);NewCosAngleMatrix=zeros(Npoints,Ndirections);
    for i=1:Npoints
    TransObj=ReEvalInds(i).objective-idealpoint;
    ModObj=sqrt(sum(TransObj.^2));
    NewCosAngleMatrix(i,:)=(TransObj'*directions)./(DirectLength*ModObj);
    end
    CosAngleMatrix=NewCosAngleMatrix;    
else
    for i=1:length(EvalSubps)
        SubpIndex=EvalSubps(i);
        subproblems(SubpIndex).evalTimes=subproblems(SubpIndex).evalTimes+1;
    end    
    OldCosAngleMatrix=CosAngleMatrix;
    ReEvalInds=NewEvaInds;
    Npoints=length(ReEvalInds);NewCosAngleMatrix=zeros(Npoints,Ndirections);
    for i=1:Npoints
    TransObj=ReEvalInds(i).objective-idealpoint;
    ModObj=sqrt(sum(TransObj.^2));
    NewCosAngleMatrix(i,:)=(TransObj'*directions)./(DirectLength*ModObj);
    end
    CosAngleMatrix=[OldCosAngleMatrix;NewCosAngleMatrix];
end
end