function demo()
clear; clc;
restoredefaultpath; matlabrc;
addpath(genpath(pwd));
rng('default'); rng('shuffle');streamOffset=randi(10000);
tic;
cal_igd='yes';
%%
methodname='MOEAD-ASS';
maxruntime=1; sel=20;
testset={'ZDT1','ZDT2','ZDT3','ZDT4','ZDT6','WFG1','WFG2','WFG3','WFG4','WFG5','WFG6','WFG7','WFG8','WFG9','DTLZ1','DTLZ2','DTLZ3','DTLZ4','DTLZ5','DTLZ6','DTLZ7'};
%%
% delete(gcp('nocreate'));parpool(5);
for i=1:length(testset)
    testname=testset{i};
    [params,mop]=loadparams(testname);
    PS=cell(1,maxruntime);PF=PS;
       if strcmp(cal_igd,'yes')
          igd=zeros(maxruntime,1);
          [PFtrue,~] = true_pareto(deblank(mop.name),500,mop.pd);
       end
    for j=1:maxruntime
    setupRandStream(streamOffset,j);
    [EvaPS,EvaPF]=moeadass(mop,params,sel);
       if strcmp(cal_igd,'yes')
          igd(j)=IGD(PFtrue,EvaPF{1,end});
          fprintf('The IGD-values in first %d run times for %s testing %s problem\n',j,methodname,testname)
          fprintf('%.4f \n',igd) 
       end
        PS{1,j}=cell2mat(EvaPS(end)); PF{1,j}=cell2mat(EvaPF(end));
    end
        fprintf('mean_igd=%.4f,medianigd=%.4f\n',mean(igd),median(igd));
        file_name = strcat('PFandPS_',methodname,testname);
        fold_name=strcat('result_',methodname);
        judge       = exist(fold_name,'dir');
        if judge ~= 7
        system(['mkdir ' fold_name]);
        end 
   file_path= strcat(cd,['\' fold_name '\']);     
   save([file_path,file_name],'PF','PS'); 
end
  toc
end

