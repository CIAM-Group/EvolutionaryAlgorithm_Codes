% pareto.m
% 
% The Matlab source codes to generate the PF and the PS of the test
%   instances for CEC 2009 Multiobjective Optimization Competition.
% 
% Usage: [pf, ps] = pareto(problem_name, no_of_points, variable_dim)
% 
% Please refer to the report for more information.
% 
% History:
%   v1 Sept.08 2008

function [pf, ps] = true_pareto(name, no, dim)

    if nargin<3, dim = 3; end
    if nargin<2, no  = 500; end
    switch name
       case{'WZL1','WZL2','WZL3','WZL4','WZL5','WZL6','WZL7','WZL8'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-pf(1,:);
            ps          = [];
%             ps(1,:)     = linspace(0,1,no);
%             x_pos=ps(1,:);
%             ps = 0.9*prod(abs(cos(pi*x_pos)).^D)*prod(sin(E*pi*repmat(x_pos,[1,n-M+1])+0.5*pi*(n+2)*repmat(M:n,[M-1,1])/n),1)';
       case{'WZL9'}
            pf          = zeros(2,no);
            ps(1,:)     = linspace(0,1,no);
            pf(1,:)     = 1-cos(0.5*pi*ps(1,:));
            pf(2,:)     = 1-sin(0.5*pi*ps(1,:));
            ps          = [];
%             ps(1,:)     = linspace(0,1,no);
%             x_pos=ps(1,:);
%             ps = 0.9*prod(abs(cos(pi*x_pos)).^D)*prod(sin(E*pi*repmat(x_pos,[1,n-M+1])+0.5*pi*(n+2)*repmat(M:n,[M-1,1])/n),1)';
        case{'ZDT6'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0.2808,1,no);
            pf(2,:)     = 1-pf(1,:).^2;
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = 0;
        case{'ZDT3'}
            no          = no*4-131;
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:))-pf(1,:).*sin(10*pi*pf(1,:)); 
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = 0;
            ParetoF = ParetoFilter(pf);
            ind     = cec09filter(ParetoF,500);
            pf      = (ParetoF(:, ind));
            clear ParetoF ind;
         case {'GLT1'}
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = repmat((2:dim)',[1,no])/dim-0.55;    
            pf(1,1:round(0.5*no)) = linspace(0,0.25,round(0.5*no));
            pf(1,(round(0.5*no)+1):no) = linspace(0.75,1,no-round(0.5*no));
            pf(2,:) = 1-pf(1,:);
        case {'F1','GLT2'}
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = repmat((2:dim)',[1,no])/dim-0.55;         
            pf          = zeros(2,no);
            pf(1,:)     = 1-cos(pi*ps(1,:)/2);
            pf(2,:)     = 10-10*sin(pi*ps(1,:)/2);
        case {'F2','GLT3'}
%             ps(1,:)     = linspace(0,1,no);
%             ps(2:dim,:) = 0.5*repmat((2:dim)',[1,no])/dim-0.55;         
%             pf(1,1:round(0.25*no)) = linspace(0,0.05,round(0.25*no));
%             pf(1,(round(0.25*no)+1):round(0.75*no)) = linspace(0.05,0.95,round(0.75*no)-round(0.25*no));
%             pf(1,(round(0.75*no)+1):no) = linspace(0.95,1,no-round(0.75*no));
%             pf(2,1:round(0.25*no)) = 1-9*pf(1,1:round(0.25*no));
%             pf(2,(round(0.25*no)+1):round(0.75*no)) = 5/9-pf(1,(round(0.25*no)+1):round(0.75*no))/9;
%             pf(2,(round(0.75*no)+1):no) = 9-9*pf(1,(round(0.75*no)+1):no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = repmat((2:dim)',[1,no])/dim-0.55;         
            pf(1,1:round(0.5*no)) = linspace(0,0.05,round(0.5*no));
            pf(1,(round(0.5*no)+1):no) = linspace(0.05,1,no-round(0.5*no));
            pf(2,1:round(0.5*no)) = 1-19*pf(1,1:round(0.5*no));
            pf(2,(round(0.5*no)+1):no) = 1/19-pf(1,(round(0.5*no)+1):no)/19;
        case {'F3'}
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = 0.5*repmat((2:dim)',[1,no])/dim;         
            pf          = zeros(2,no);
       %%  F3-1
%           pf(1,1:round(0.5*no)) = 0.5*(cos(pi*ps(1,1:round(0.5*no)))).^0.5;
%           pf(2,1:round(0.5*no)) = (0.5+0.5*(sin(pi*ps(1,1:round(0.5*no)))).^0.5);
%           pf(1,(round(0.5*no)+1):no) = (1-0.5*(-cos(pi*(ps(1,(round(0.5*no)+1):no)))).^0.5);
%           pf(2,(round(0.5*no)+1):no) = 0.5-0.5*(sin(pi*(ps(1,(round(0.5*no)+1):no)))).^0.5;
      %%  F3-2
            pf(1,:)     = linspace(0,1,no);   
            pf(2,1:round(0.5*no)) = 1-0.5*(2*ps(1,1:round(0.5*no))).^4;
            pf(2,(round(0.5*no)+1):no) = 0.5*(2*(1-ps(1,(round(0.5*no)+1):no))).^4;   
        case 'GLT4'
            no          = no*3+56;
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 2-2*(pf(1,:).^0.5).*(cos(2*pi*pf(1,:).^0.5).^2);
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(0.5*pi*repmat(ps(1,:),[dim-1,1]));
            ParetoF = ParetoFilter(pf);
            ind     = cec09filter(ParetoF,500);
            pf    =(ParetoF(:, ind));
            clear ParetoF ind;
        case {'ZDT1','ZDT4','MOP1','LZ1','LZ2','LZ3','LZ4','LZ5','F4','F5'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:));
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(0.5*pi*repmat(ps(1,:),[dim-1,1]));
        case {'ZDT2','MOP2','LZ9'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-pf(1,:).^2;
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(0.5*pi*repmat(ps(1,:),[dim-1,1]));
        case 'MOP3'
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = sqrt(1-pf(1,:).^2);
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(0.5*pi*repmat(ps(1,:),[dim-1,1]));
        case 'MOP4'
            no          = no*3+56;
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-(pf(1,:).^0.5).*(cos(2*pi*pf(1,:)).^2);
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(0.5*pi*repmat(ps(1,:),[dim-1,1]));
            ParetoF = ParetoFilter(pf);
            ind     = cec09filter(ParetoF,500);
            pf    =(ParetoF(:, ind));
            clear ParetoF ind;
         case 'MOP5'
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:));
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(0.5*pi*repmat(ps(1,:),[dim-1,1]));
         case {'MOP6','WZL10','WZL11','WZL12','WZL13','WZL14','WZL15','WZL16','WZL17'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = ps(1,:).*ps(2,:);
            pf(2,:)     = ps(1,:).*(1-ps(2,:));
            pf(3,:)     = 1-ps(1,:);   
            clear s t;
            case {'DTLZ1'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 0.5*ps(1,:).*ps(2,:);
            pf(2,:)     = 0.5*ps(1,:).*(1-ps(2,:));
            pf(3,:)     = 0.5*(1-ps(1,:));   
            clear s t;
            case {'mDTLZ1'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 0.5*(1-ps(1,:).*ps(2,:));
            pf(2,:)     = 0.5*(1-ps(1,:).*(1-ps(2,:)));
            pf(3,:)     = 0.5*(ps(1,:));   
            clear s t;            
         case {'MOP7','LZ6','DTLZ2','DTLZ3','DTLZ4'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = cos(0.5*pi*ps(1,:)).*cos(0.5*pi*ps(2,:));
            pf(2,:)     = cos(0.5*pi*ps(1,:)).*sin(0.5*pi*ps(2,:));
            pf(3,:)     = sin(0.5*pi*ps(1,:));   
            clear s t;
         case {'mDTLZ2','mDTLZ3','mDTLZ4'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 1-cos(0.5*pi*ps(1,:)).*cos(0.5*pi*ps(2,:));
            pf(2,:)     = 1-cos(0.5*pi*ps(1,:)).*sin(0.5*pi*ps(2,:));
            pf(3,:)     = 1-sin(0.5*pi*ps(1,:));   
            clear s t;
        case{'DTLZ5','DTLZ6'}
             ps          = [];
             objD=3;
             P = [0:1/(no-1):1;1:-1/(no-1):0]';
             P = P./repmat(sqrt(sum(P.^2,2)),1,size(P,2));
             P = [P(:,ones(1,objD-2)),P];
             P = P./sqrt(2).^repmat([objD-2,objD-2:-1:0],size(P,1),1);
             pf=P';
        case 'DTLZ7'
            ps          = [];
            objD=3;
            interval     = [0,0.251412,0.631627,0.859401];
            median       = (interval(2)-interval(1))/(interval(4)-interval(3)+interval(2)-interval(1));
            X            = ReplicatePoint(no,objD-1);
            X(X<=median) = X(X<=median)*(interval(2)-interval(1))/median+interval(1);
            X(X>median)  = (X(X>median)-median)*(interval(4)-interval(3))/(1-median)+interval(3);
            P            = [X,2*(objD-sum(X/2.*(1+sin(3*pi.*X)),2))];
            pf=P';             
        case {'WZL18'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = (1-cos(0.5*pi*ps(1,:))).*(1-cos(0.5*pi*ps(2,:)));
            pf(2,:)     = (1-cos(0.5*pi*ps(1,:))).*(1-sin(0.5*pi*ps(2,:)));
            pf(3,:)     = 1-sin(0.5*pi*ps(1,:));   
            clear s t;
         case 'WFG1'
            M = 2;
            h = UniformPoint(no,M);
            for i = 1 : size(h,1)
                c = ones(1,M);
                k = find(h(i,:)~=0,1);
                for j = k+1 : M
                    temp     = h(i,j)/h(i,k)*prod(1-c(M-j+2:M-k));
                    c(M-j+1) = (temp^2-temp+sqrt(2*temp))/(temp^2+1);
                end
                for j = 1 : M
                    h(i,j) = prod(1-c(1:M-j)).*(1-sqrt(1-c(M-j+1)^2));
                end
                temp   = acos(c(1))*2/pi;                   
                h(i,M) = 1 - temp - cos(10*pi*temp+pi/2)/10/pi;
            end
            h = repmat(2:2:2*M,size(h,1),1).*h;
            pf = h';
            ps = [];
         case 'WFG2'
            M = 2;
            x = ReplicatePoint(no,M-1);
            x(:,1) = sqrt(x(:,1));
            x = [x,zeros(size(x,1),1)];
            h = fliplr(cumprod([ones(size(x,1),1),1-cos(x(:,1:end-1)*pi/2)],2)).*[ones(size(x,1),1),1-sin(x(:,end-1:-1:1)*pi/2)];
            h(:,M) = 1-x(:,1).*(cos(5*pi*x(:,1))).^2;
            h = repmat(2:2:2*M,size(h,1),1).*h;
            hh = h(NDSort(h,1)==1,:);
            pf = hh';
            ps = [];                  
         case 'WFG3'
            M = 2;
            PopDec    = (0:1/(no-1):1)';
            PopDec    = [PopDec,zeros(no,M-2)+0.5,zeros(no,1)];
            h = fliplr(cumprod([ones(size(PopDec,1),1),PopDec(:,1:end-1)],2)).*[ones(size(PopDec,1),1),1-PopDec(:,end-1:-1:1)];
            h         = repmat(2:2:2*M,size(h,1),1).*h;
            pf = h';
            ps = [];
         case {'WFG4','WFG5','WFG6','WFG7','WFG8','WFG9'}
            M = 2;
            h = UniformPoint(no,M);
            h = h./repmat(sqrt(sum(h.^2,2)),1,M);
            h = repmat(2:2:2*M,size(h,1),1).*h;
            pf = h';
            ps = [];            
         case {'F8','F10'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 1-ps(1,:).*ps(2,:);
            pf(2,:)     = 1-ps(1,:).*(1-ps(2,:));
            pf(3,:)     = ps(1,:);   
            clear s t;
%          case {'F8'}
%             num         = floor(sqrt(no));
%             no          = num*num;
%             [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
%             ps          = zeros(dim,no);
%             ps(1,:)     = reshape(s,[1,no]);
%             ps(2,:)     = reshape(t,[1,no]);            
%             ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
%             pf          = zeros(3,no);
%             pf(1,:)     = (1-cos(0.5*pi*ps(1,:))).*(1-cos(0.5*pi*ps(2,:)));
%             pf(2,:)     = (1-cos(0.5*pi*ps(1,:))).*(1-sin(0.5*pi*ps(2,:)));
%             pf(3,:)     = 1-sin(0.5*pi*ps(1,:));   
%             clear s t;
         case {'F9'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 1-cos(0.5*pi*ps(1,:)).*cos(0.5*pi*ps(2,:));
            pf(2,:)     = 1-cos(0.5*pi*ps(1,:)).*sin(0.5*pi*ps(2,:));
            pf(3,:)     = 1-sin(0.5*pi*ps(1,:));   
            clear s t;
        case 'UF1'
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:));
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(6.0*pi*repmat(ps(1,:),[dim-1,1]) + repmat((2:dim)',[1,no])*pi/dim);
        case 'UF2'
            pf            = zeros(2,no);
            pf(1,:)       = linspace(0,1,no);
            pf(2,:)       = 1-sqrt(pf(1,:));
            ps            = zeros(dim,no);
            ps(1,:)       = linspace(0,1,no);
            X1            = repmat(ps(1,:),[dim,1]);
            A             = 6.0*pi*X1 + pi/dim*repmat((1:dim)',[1,no]);
            B             = 0.3*X1.*(X1.*cos(4.0*A)+2.0).*cos(A);
            ps(3:2:dim,:) = B(3:2:dim,:);
            B             = 0.3*X1.*(X1.*cos(4.0*A)+2.0).*sin(A);
            ps(2:2:dim,:) = B(2:2:dim,:);
            clear A B;
        case {'UF3','LZ7','LZ8','F6','F7'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:));
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = repmat(ps(1,:),[dim-1,1]).^(0.5+1.5*(repmat((0:1:(dim-2))',[1,no]))/(dim-2.0));
        case 'UF4'
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-pf(1,:).^2;
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(6.0*pi*repmat(ps(1,:),[dim-1,1]) + repmat((2:dim)',[1,no])*pi/dim);
        case 'UF5'
            no          = 21;
            pf          = zeros(2,no);
            pf(1,:)     = (0:1:20)/20.0;
            pf(2,:)     = 1-pf(1,:);
            ps          = zeros(dim,no);
            ps(1,:)     = pf(1,:);
            ps(2:dim,:) = sin(6.0*pi*repmat(ps(1,:),[dim-1,1]));
        case 'UF6'
            num                     = floor(no/3);
            pf                      = zeros(2,no);
            pf(1,1:num)             = 0.0;
            pf(1,(num+1):(2*num))   = linspace(0.25,0.5,num);
            pf(1,(2*num+1):no)      = linspace(0.75,1.0,no-2*num);
            pf(2,:)                 = 1-pf(1,:);
            ps                      = zeros(dim,no);
            ps(1,:)                 = pf(1,:);
            ps(2:dim,:)             = sin(6.0*pi*repmat(ps(1,:),[dim-1,1]) + repmat((2:dim)',[1,no])*pi/dim);
        case 'UF7'
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-pf(1,:);
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(6.0*pi*repmat(ps(1,:),[dim-1,1]) + repmat((2:dim)',[1,no])*pi/dim);
        case {'UF8','UF10'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = 2.0*repmat(ps(2,:),[dim-2,1]).*sin(2.0*pi*repmat(ps(1,:),[dim-2,1]) + repmat((3:dim)',[1,no])*pi/dim);             
            pf          = zeros(3,no);
            pf(1,:)     = cos(0.5*pi*ps(1,:)).*cos(0.5*pi*ps(2,:));
            pf(2,:)     = cos(0.5*pi*ps(1,:)).*sin(0.5*pi*ps(2,:));
            pf(3,:)     = sin(0.5*pi*ps(1,:));   
            clear s t;
        case 'UF9'
            num             = floor(sqrt(no));
            no              = num*num;
            noA             = floor(num/2);
            A               = zeros(1,num);
            A(1,1:noA)      = linspace(0,0.25,noA);
            A(1,noA+1:num)  = linspace(0.75,1,num-noA);
            [s,t]           = meshgrid(A,linspace(0,1,num));
            ps              = zeros(dim,no);
            ps(1,:)         = reshape(s,[1,no]);
            ps(2,:)         = reshape(t,[1,no]);            
            ps(3:dim,:)     = 2.0*repmat(ps(2,:),[dim-2,1]).*sin(2.0*pi*repmat(ps(1,:),[dim-2,1]) + repmat((3:dim)',[1,no])*pi/dim);             
            pf              = zeros(3,no);
            pf(1,:)         = ps(1,:).*ps(2,:);
            pf(2,:)         = (1.0-ps(1,:)).*ps(2,:);
            pf(3,:)         = 1.0-ps(2,:);    
            clear A s t;
        case 'CF1'
            no          = 21;
            pf          = zeros(2,no);
            pf(1,:)     = (0:1:20)/20.0;
            pf(2,:)     = 1-pf(1,:);
            ps          = [];
        case 'CF2'
            no          = floor(no/3.0);
            pf          = zeros(2,3*no);
            pf(1,(no+1):(2*no))   = linspace(0.25^2,0.25,no);
            pf(1,(2*no+1):(3*no)) = linspace(0.75^2,1.0,no);
            pf(2,:)     = 1-sqrt(pf(1,:));
            ps          = []; 
        case 'CF3'
            no          = floor(no/3.0);
            pf          = zeros(2,3*no);
            pf(1,(no+1):(2*no))     = linspace(0.25^0.5,0.5^0.5,no);
            pf(1,(2*no+1):(3*no))   = linspace(0.75^0.5,1.0^0.5,no);
            pf(2,:)     = 1-pf(1,:).^2;
            ps          = [];
        case {'CF4','CF5'}
            no          = floor(no/4.0);
            pf          = zeros(2,4*no);
            pf(1,1:(2*no))          = linspace(0,0.5,2*no);
            pf(2,1:(2*no))          = 1-pf(1,1:(2*no));
            pf(1,(2*no+1):(3*no))   = linspace(0.5,0.75,no);
            pf(2,(2*no+1):(3*no))   = -0.5*pf(1,(2*no+1):(3*no))+0.75;
            pf(1,(3*no+1):(4*no))   = linspace(0.75,1.0,no);
            pf(2,(3*no+1):(4*no))   = 1.125-pf(1,(3*no+1):(4*no));
            ps          = [];
        case {'CF6','CF7'}
            no          = floor(no/4.0);
            pf          = zeros(2,4*no);
            pf(1,1:(2*no))          = linspace(0,0.5,2*no);
            pf(2,1:(2*no))          = (1.0-pf(1,1:(2*no))).^2;
            pf(1,(2*no+1):(3*no))   = linspace(0.5,0.75,no);
            pf(2,(2*no+1):(3*no))   = 0.5*(1.0-pf(1,(2*no+1):(3*no)));
            pf(1,(3*no+1):(4*no))   = linspace(0.75,1.0,no);
            pf(2,(3*no+1):(4*no))   = 0.25*sqrt(1.0-pf(1,(3*no+1):(4*no)));
            ps          = []; 
        case 'CF8'
            no          = floor(no/5.0);
            pf          = zeros(3,5*no);
            for k = 0:1:4
                s = k*no+1; 
                e = k*no+no;
                pf(3,s:e) = linspace(0,1,no);
                pf(1,s:e) = sqrt(k/4.0*(1.0-pf(3,s:e).^2));
                pf(2,s:e) = sqrt(1-pf(1,s:e).^2-pf(3,s:e).^2);
            end
            ps          = []; 
        case {'CF9','CF10'}
            no1         = floor(sqrt(no/12));
            no          = 4*no1*no1;
            pf          = zeros(3,3*no);
            s           = 1; 
            e           = no;
            pf(1,s:e)   = 0;
            pf(2,s:e)   = linspace(0,1,no);
            pf(3,s:e)   = sqrt(1-pf(2,s:e).^2);            
            for k = 1:1:2
                s = k*no+1; 
                e = k*no+no;
                A = repmat(linspace(0,1,4*no1),[no1,1]);
                B = repmat((linspace(2*k-1, 2*k, no1)/4.0)',[1,4*no1]);
                B = sqrt(B.*repmat(1-linspace(0,1,4*no1).^2,[no1,1]));
                pf(3,s:e) = reshape(A,1,no);
                pf(1,s:e) = reshape(B,1,no);
                pf(2,s:e) = sqrt((1-pf(1,s:e).^2-pf(3,s:e).^2));
            end
            ps          = [];             
    end
end

function W = ReplicatePoint(SampleNum,M)
    if M > 1
        SampleNum = (ceil(SampleNum^(1/M)))^M;
        Gap       = 0:1/(SampleNum^(1/M)-1):1;
        eval(sprintf('[%s]=ndgrid(Gap);',sprintf('c%d,',1:M)))
        eval(sprintf('W=[%s];',sprintf('c%d(:),',1:M)))
    else
        W = (0:1/(SampleNum-1):1)';
    end
end
