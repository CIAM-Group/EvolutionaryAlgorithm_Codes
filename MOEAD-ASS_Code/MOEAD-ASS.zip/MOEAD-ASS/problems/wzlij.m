function mop=wzlij(mop,testname,dimension)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.
    switch lower(testname)
        case 'wzlij1'
            mop=wzlij1(mop, dimension);
        case 'wzlij2'
            mop=wzlij2(mop, dimension);
        case 'wzlij3'
            mop=wzlij3(mop, dimension);
        case 'wzlij4'
            mop=wzlij4(mop, dimension);
        case 'wzlij5'
            mop=wzlij5(mop, dimension);     
        case 'wzlij6'
            mop=wzlij6(mop, dimension); 
        case 'wzlij7'
            mop=wzlij7(mop, dimension); 
        case 'wzlij8'
            mop=wzlij8(mop, dimension); 
        case 'wzlij9'
            mop=wzlij9(mop, dimension);                              
        otherwise 
            error('Undefined test problem name');                
    end 
end

%%
function p = wzlij1(p,dim)
 p.name = 'WZLIJ1';
 p.pd = dim;% default dim=30
 p.od = 2;
 p.domain = [0,1;-1*ones(dim-1,1),ones(dim-1,1)];
 p.func = @evaluate;

 function y = evaluate(x)
    n = size(x,1);
    io = 3:2:n;
    ie = 2:2:n;
    t = x-0.9*sin(pi*(1:1:n)'/n); 
    g1 = 2.0/length(io)*(sum(abs(t(io)).^0.7));
    g2 = 2.0/length(ie)*(sum(abs(t(ie)).^0.7));
    y = zeros(2,1);
    y(1) = g1+(1-cos(pi*x(1)/2));
    y(2) = g2+(10-10*sin(pi*x(1)/2));
 end
end
%%
function p = wzlij2(p,dim)
 p.name = 'WZLIJ2';
 p.pd = dim;% default dim=30
 p.od = 2;
 p.domain = [0,1;-1*ones(dim-1,1),ones(dim-1,1)];
 p.func = @evaluate;

 function y = evaluate(x)
    n = size(x,1);
    io = 3:2:n;
    ie = 2:2:n;
    t = x-0.9*sin(pi*(1:1:n)'/n);
    g1 = 2.0/length(io)*(sum(abs(t(io)+sin(1*pi*(t(io)))/(1*pi)).^1));
    g2 = 2.0/length(ie)*(sum(abs(t(ie)+sin(1*pi*(t(ie)))/(1*pi)).^1)); 
    y = zeros(2,1);
    y(1) = g1+x(1);
    if x(1)<=0.05
       y(2) = g2+(1-19*x(1));
    else
       y(2) = g2+(1/19-x(1)/19);
    end
 end
end
%%
function p = wzlij3(p,dim)
 p.name = 'WZLIJ3';
 p.pd = dim;% default dim=30
 p.od = 2;
 p.domain = [0,1;-1*ones(dim-1,1),ones(dim-1,1)];
 p.func = @evaluate;

 function y = evaluate(x)
    n = size(x,1);
    io = 3:2:n;
    ie = 2:2:n;
    t = x-0.9*sin(pi*(1:1:n)'/n);
    g1 = 2.0/length(io)*(sum(1-exp(-1*abs(t(io)).^1)));
    g2 = 2.0/length(ie)*(sum(1-exp(-1*abs(t(ie)).^1)));
    y = zeros(2,1);
    y(1) = g1+x(1);
    if x(1)<=0.5
       y(2) = g2+1-0.5*(2*x(1)).^4;
    else
       y(2) = g2+0.5*(2*(1-x(1))).^4;
    end
 end
end
%%
function p = wzlij4(p,dim)
 p.name = 'WZLIJ4';
 p.pd = dim;% default dim=30
 p.od = 2;
 p.domain = [0,1;-1*ones(dim-1,1),ones(dim-1,1)];
 p.func = @evaluate;
 
 function y = evaluate(x)    
    n = size(x,1);
    io = 3:2:n;
    ie = 2:2:n;
    t1 = x(io)-1.8*abs(x(1)-0.55)*cos(5.0*pi*(x(1))+(io)'*pi/n);
    t2 = x(ie)-1.8*abs(x(1)-0.55)*sin(5.0*pi*(x(1))+(ie)'*pi/n);
    g1 = 2.0/length(io)*sum(t1.^2.0);
    g2 = 2.0/length(ie)*sum(t2.^2.0);
    y = zeros(2,1);
    y(1) = x(1)+g1;
    y(2) = (1.0-sqrt(x(1)))+g2;
 end
end

%%
function p = wzlij5(p,dim)
 p.name = 'WZLIJ5';
 p.pd = dim;% default dim=30
 p.od = 2;
 p.domain = [0,1;-1*ones(dim-1,1),ones(dim-1,1)];
 p.func = @evaluate;
 
 function y = evaluate(x)
    n = size(x,1);
    io = 3:2:n;
    ie = 2:2:n;
    t1 = x(io)-(0.75*(abs(x(1)-0.55).^2)*cos(16.0*pi*x(1)+4.0*(io)'*pi/n)+1.4*abs(x(1,:)-0.55)).*cos(4.0*pi*x(1)+(io)'*pi/n);
    t2 = x(ie)-(0.75*(abs(x(1)-0.55).^2)*cos(16.0*pi*x(1)+4.0*(ie)'*pi/n)+1.4*abs(x(1,:)-0.55)).*sin(4.0*pi*x(1)+(ie)'*pi/n);
    g1 = 2.0/length(io)*sum(t1.^2.0);
    g2 = 2.0/length(ie)*sum(t2.^2.0);   
    y = zeros(2,1);
    y(1) = x(1)+g1;
    y(2) = (1.0-sqrt(x(1)))+g2;
 end
end
%%
function p = wzlij6(p,dim)
 p.name = 'WZLIJ6';
 p.od = 2;
 p.pd = dim;% default dim=30
 p.domain = [0,1;-1*ones(dim-1,1),ones(dim-1,1)];
 p.func = @evaluate;
   
 function y = evaluate(x)
    n = size(x,1);
    io = 3:2:n;
    ie = 2:2:n;
    t = x-0.9*sin(2.0*pi*x(1)+pi*(1:1:n)'/n);
    t1 = t(io);
    t2 = t(ie);
    g1 = 0.02/length(io)*(length(io)+100*sum(t1.*t1)- sum(cos(10*pi*t1)));%0.25Ҳ����
    g2 = 0.02/length(ie)*(length(ie)+100*sum(t2.*t2)- sum(cos(10*pi*t2)));
    y = zeros(2,1);
    y(1) = g1+x(1);
    y(2) = g2+(1.0-sqrt(x(1)));   
 end
end

%%
function p = wzlij7(p,dim)
 p.name = 'WZLIJ7';
 p.od = 2;
 p.pd = dim;% default dim=30
 p.domain = [0,1;-1*ones(dim-1,1),ones(dim-1,1)];
 p.func = @evaluate;
   
 function y = evaluate(x)
    y = zeros(2,1);
    n = size(x,1);
    io = 3:2:n;
    ie = 2:2:n;
    t = x-0.9*sin(2.0*pi*x(1)+pi*(1:1:n)'/n);
    t1 = t(io);
    t2 = t(ie);
    g1 = 0.05/length(io)*(100*sum(t1.*t1)-1*prod(cos(20*pi*t1./sqrt(io)'))+1);
    g2 = 0.05/length(ie)*(100*sum(t2.*t2)-1*prod(cos(20*pi*t2./sqrt(ie)'))+1);
    y(1) = g1+x(1);
    y(2) = g2+(1.0-sqrt(x(1)));   
 end
end

function p = wzlij8(p,pdim)
 p.name ='WZLIJ8';
 p.od = 3;
 p.pd = pdim;% default dim=10
 p.domain = [-1.0*ones(pdim,1) 1.0*ones(pdim,1)]; p.domain(1:2,1) = 0.0; p.domain(1:2,2) = 1.0;
 p.func = @evaluate;
 function y = evaluate(x)
    odim = 3;
    y = zeros(odim,1);
    xm = x(odim:pdim,1);
    d_vars = 0.9*ones(pdim-odim+1,1);
    for d_var = 1:odim-1
     d_vars = d_vars.*sin(2*pi*x(d_var)+pi*(odim:1:pdim)'/pdim);
    end
    t= xm-d_vars;
    g= sum(abs(t).^2);
    y(1) = (1-prod(x(1:odim-1,1)))+g;
    y(odim) = x(1)+g;
    for i = 2:odim-1
        y(i) = (1-prod(x(1:odim-i,1))*(1-x(odim-i+1)))+g;
    end               
 end
end
%%
function p = wzlij9(p,pdim)
 p.name = 'WZLIJ9';
 p.od = 3;
 p.pd = pdim;% default dim=10
 p.domain = [-1.0*ones(pdim,1) 1.0*ones(pdim,1)]; p.domain(1:2,1) = 0.0; p.domain(1:2,2) = 1.0;
 p.func = @evaluate;
 function y = evaluate(x)
     odim=3;
     y=zeros(odim,1);
     xm=x(odim:pdim,1);
     d_vars=0.9*ones(pdim-odim+1,1);
     for d_var=1:odim-1
      d_vars = d_vars.*sin(2*pi*x(d_var)+pi*(odim:1:pdim)'/pdim);
     end
     t=xm-d_vars;
     g=0.01*(sum(1+100*(t).^2-cos(4*pi*(t))));
     y(1)=(1-prod(cos(pi*x(1:odim-1,1)./2)))+g;
     y(odim)=(1-sin(pi*x(1)/2))+g;
     for i=2:odim-1
         y(i)=(1-prod(cos(pi*x(1:odim-i,1)./2))*sin(pi*x(odim-i+1)./2))+g;
     end  
 end
end

