function mop=lgz(mop,testname,dimension)
%%run for mop problems
switch lower(testname)
        case 'lgz1'
            mop=lgz1(mop,dimension);
        case 'lgz2'
            mop=lgz2(mop,dimension);
        case 'lgz3'
            mop=lgz3(mop,dimension);        
        case 'lgz4'
            mop=lgz4(mop,dimension);        
        case 'lgz5'
            mop=lgz5(mop,dimension);        
        case 'lgz6'
            mop=lgz6(mop,dimension);        
        case 'lgz7'
            mop=lgz7(mop,dimension);   
        otherwise
        error('Undefined test problem name');
end
end
%%
function p=lgz1(p,dim)
   p.name='LGZ1';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(2,1);
      t=x-sin(0.5*pi*x(1));
      sumt=-0.9*(t.^2)+abs(t).^0.6;
      g =2*sin(0.875*pi*x(1)+0.0625*pi)*(sum(sumt)-sumt(1)); 
      y(1)=(1+g)*x(1);
      y(2)=(1+g)*(1-sqrt(x(1)));
    end
end
%%
function p=lgz2(p,dim)
   p.name='LGZ2';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
       y=zeros(2,1);         
       t=x-sin(0.5*pi*x(1));
       sumt=abs(t)./(1+exp(5*abs(t)));
       g =10*sin(pi*x(1))*(sum(sumt)-sumt(1));
       y(1)=(1+g)*x(1);
       y(2)=(1+g)*(1-x(1).^2);
   end
end
%%
function p=lgz3(p,dim)
   p.name='LGZ3';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(2,1);         
      t=x-sin(0.5*pi*x(1));
      sumt=abs(t)./(1+exp(5*abs(t)));
      g =10*sin(pi*x(1)/2)*(sum(sumt)-sumt(1));
      y(1)=(1+g)*cos(pi*x(1)/2);
      y(2)=(1+g)*sin(pi*x(1)/2);
   end
end
%%
function p=lgz4(p,dim)
   p.name='LGZ4';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
    function y=evaluate(x)
        y=zeros(2,1); 
        t=x-sin(0.5*pi*x(1));
        sumt=abs(t)./(1+exp(5*abs(t)));
        g =10*sin(pi*x(1))*(sum(sumt)-sumt(1));        
        y(1)=(1+g)*x(1);
        y(2)=(1+g)*(1-x(1).^(0.5)*(cos(2*pi*x(1))).^2);
    end
end
%%
function p=lgz5(p,dim)
   p.name='LGZ5';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
    function y=evaluate(x)
        y=zeros(2,1);
        %[dim, num]  = size(x);
        %t=x-(sin(2*pi*x(1) + pi/dim*repmat((1:dim)',[1,num]))).^2;
        t=x-sin(0.5*pi*x(1));
        sumt=-0.9*(t.^2)+abs(t).^0.6;
        g =2*abs(cos(pi*x(1)))*(sum(sumt)-sumt(1));
        y(1)=(1+g)*x(1);
        y(2)=(1+g)*(1-sqrt(x(1)));
    end
end
%%
function p=lgz6(p,dim)
   p.name='LGZ6';
   p.od=3;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
    function y=evaluate(x)
        y=zeros(3,1);
        t=x-x(1)*x(2);
        sumt=-0.9*(t.^2)+abs(t).^0.6;
        g =2*sin(pi*x(1))*(sum(sumt)-sumt(1)-sumt(2));
        y(1)=(1+g)*x(1)*x(2);
        y(2)=(1+g)*x(1)*(1-x(2));
        y(3)=(1+g)*(1-x(1));
    end
end
%%
function p=lgz7(p,dim)
   p.name='LGZ7';
   p.od=3;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
    function y=evaluate(x)
        y=zeros(3,1);
        t=x-x(1)*x(2);
        sumt=-0.9*(t.^2)+abs(t).^0.6;
        g =2*sin(pi*x(1))*(sum(sumt)-sumt(1)-sumt(2));
        y(1)=(1+g)*cos(x(1)*pi/2)*cos(x(2)*pi/2);
        y(2)=(1+g)*cos(x(1)*pi/2)*sin(x(2)*pi/2);
        y(3)=(1+g)*sin(x(1)*pi/2);
    end
end
