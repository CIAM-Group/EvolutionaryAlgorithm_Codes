function [subproblem] = SubpAlpha(SortInds, params, subproblem, idealpoint)
    X = [SortInds.parameter]; y = [SortInds.objective];
    Obj = [SortInds.PredObjs]; Var = [SortInds.PredVars];
    Ndata = size(X, 2);
    bound =[0, 2];
    if size(y, 1) ~= size(X, 2)
        y = y';
    end
    EvaObj = subobjective(subproblem.weight, y', params.Dmethod);
    [SubpObj, SubpVar] = tchGP(subproblem.weight, Obj, Var, idealpoint);
    SubpStd = sqrt(SubpVar);
    select = leastSquare(SubpObj, SubpStd, EvaObj);
    subproblem.alpha = select;
end

function [SubpMeans, SubpVars] = tchGP(weight, ObjMeans, ObjVars, idealpoint)
% Transfer the obective prediction to subproblem
    [Nobj, Nw] = size(weight);
    Nind = size(ObjMeans, 2);
    if Nind == 1
        U = weight .* repmat((ObjMeans - idealpoint), 1, Nw);
        V = (weight .^ 2) .* repmat(ObjVars, 1, Nw);
    elseif Nw == 1
        U = repmat(weight, 1, Nind) .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (repmat(weight, 1, Nind) .^ 2) .* ObjVars;
    elseif Nw == Nind
        U = weight .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (weight .^ 2) .* ObjVars;
    else
        error('individual size must be same as weight size, or equals 1');
    end

    Cur_u = U(1, :); Cur_v = V(1, :);

    for i = 2:Nobj
        u1 = Cur_u; v1 = Cur_v;
        u2 = U(i, :); v2 = V(i, :);
        t = sqrt(v1 + v2);
        a = (u1 - u2) ./ t;
        Cur_u = u1 .* normcdf(a) + u2 .* normcdf(-a) + t .* normpdf(a);
        Cur_v = (u1 .^ 2 + v1) .* normcdf(a) + (u2 .^ 2 + v2) .* normcdf(-a) + (u1 + u2) .* t .* normpdf(a) - Cur_u .^ 2;

        if any(Cur_v < 0)
            if all(Cur_v >- eps)
                Cur_v(Cur_v < 0) = 0;
                warning('Predicted objective variance is less than 0, and has been corrected to 0');
            else
                error('Predicted objective variance is less than 0, and the error is too large');
            end

        end
        if any(isnan([Cur_u, Cur_v]))
            Cur_u = 0; Cur_v = 0;
        end
    end
    SubpMeans = Cur_u; SubpVars = Cur_v;
end

function [bound] = UPBound(SubpObj, SubpStd)
    Ndata = length(SubpObj);
    alphaArr = zeros(1, Ndata - 1);
    [sortStd, sortIdx] = sort(SubpStd);
    sortObj = SubpObj(sortIdx);
    for i = 2 : Ndata
        alphaArr(i) = (sortObj(i - 1) - sortObj(i)) ./ (sortStd(i - 1) - sortStd(i));
    end
    bound = max(alphaArr);
end

function [bound] = CalcAlpha(PredObj, PredVar, EvaObj)
    [~, RO] = sort(EvaObj);
    PredR = PredObj(RO);
    VarR = PredVar(RO);
    Ndata = length(EvaObj); bounds = zeros(1, Ndata - 1);
    eq = bounds; bound = [inf, inf];
    for i = 2 : Ndata
        bounds(i - 1) = (PredR(i - 1) - PredR(i)) ./ (VarR(i - 1) - VarR(i));
        if VarR(i - 1) - VarR(i) < 0
            eq(i - 1) = -1;
        else
            eq(i - 1) = 1;
        end
    end
    success = 1;
    while bound(1) >= bound(2)
        for i = 1 : length(bounds)
            if eq(i) == -1 || success > 1
                if isinf(bound(2))
                    bound(2) = bounds(i);
                elseif bounds(i) < bound(2) && bounds(i) > bound(1)
                    bound(2) = bounds(i);
                end
            else
                if isinf(bound(1)) && bounds(i) < bound(2)
                    bound(1) = bounds(i);
                elseif bounds(i) > bound(1) && bounds(i) < bound(2)
                    bound(1) = bounds(i);
                end
            end
        end
        if bound(1) >= bound(2)
            success = success + 1;
        end
    end
end

function [alpha] = leastSquare(PredObj, PredVar, EvaObj)
    if size(PredObj, 1) == 1
        PredObj = PredObj';
    end
    if size(PredVar, 1) == 1
        PredVar = PredVar';
    end
    if size(EvaObj, 1) == 1
        EvaObj = EvaObj';
    end
    alpha = (PredVar' * PredVar) \ PredVar' * (PredObj - EvaObj);
end

function [obj] = h(x, EvaObj, SubpObj, SubpVar)
    if size(SubpObj, 1) == 1
        SubpObj = SubpObj';
    end
    if size(SubpVar, 1) == 1
        SubpVar = SubpVar';
    end
    if size(EvaObj, 1) == 1
        EvaObj = EvaObj';
    end
    obj = (EvaObj - (SubpObj - x .* SubpVar)).^2;
end