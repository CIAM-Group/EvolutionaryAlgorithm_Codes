function [CandInds, CandIdx]=prescreen_hv(params,subproblems,EvaInds, mop, settingStruct)
    global idealpoint;
    Popsize=length(subproblems);
    CandInds = [];
    flag=true(1,Popsize);
    random = settingStruct.random;
    strategy = settingStruct.strategy;
    if strcmp(strategy, 'None')
        %% %%%%%%%%%%%%%%%%%%%------------>closenessFilter<------------%%%%%%%%%%%%%%%%%%%%%%%
        for i=1:Popsize
            closeness=isclose(subproblems(i).curpoint,EvaInds,params.Mindiffer);
            if closeness 
                flag(i)=false;
            end
        end
        unfilterredIndex=find(flag);
        if isempty(unfilterredIndex)
            fprintf('The candidate is too close to each other \n')
        end
        weights=[subproblems(flag).weight];
        Nidxes=length(unfilterredIndex);
        if length(weights)>params.Ke
            idx=kmeans(weights',params.Ke);
            cluseridx=idx';
            EvalNu=params.Ke;
        else 
            EvalNu=Nidxes;
            cluseridx=1:EvalNu;
        end
        CandIdx = [];
        fit = [subproblems.prescreenFit];
        subpmins = [subproblems.subpmin];
        obj = (fit - subpmins) ./ subpmins;
        for i = 1 : EvalNu
            candidxes = unfilterredIndex(cluseridx == i);
            tempObj = obj(candidxes);
            screenFit = tempObj;
            while ~isempty(candidxes)
                if random
                    index = randsample(candidxes, 1);
                    selectedIndex = index;
                else
                    [~,index]=min(screenFit);
                    selectedIndex=candidxes(index);
                end
                closeness=isclose(subproblems(selectedIndex).curpoint,[subproblems(CandIdx).curpoint],params.Mindiffer);
                if ~closeness
                    CandIdx = [CandIdx, selectedIndex];
                    break;
                else
                    candidxes(candidxes==selectedIndex)=[];
                    screenFit(index) = [];
                end
            end
        end
        Newidealpoint = idealpoint(:, 2);
        for i = 1 : length(CandIdx)
            CandInd=get_structure('individual');
            CandInd.parameter = subproblems(CandIdx(i)).curpoint.parameter;
            [real_value, ~]=evaluate(mop, CandInd);
            CandInd.objective = real_value;
            Newidealpoint = min(Newidealpoint,real_value-5e-2);
            CandInds = [CandInds, CandInd];
        end
        idealpoint(:,1)=idealpoint(:,2); idealpoint(:,2)=Newidealpoint;    
    else
        Newidealpoint = idealpoint(:, 2);
        cluseridx = 0; CandIdx = 0;
        for i = 1 : length(subproblems)
            CandInd=get_structure('individual');
            CandInd.parameter = subproblems(i).curpoint.parameter;
            [real_value, ~]=evaluate(mop, CandInd);
            CandInd.objective = real_value;
            Newidealpoint = min(Newidealpoint,real_value-5e-2);
            CandInds = [CandInds, CandInd];
        end
        idealpoint(:,1)=idealpoint(:,2); idealpoint(:,2)=Newidealpoint;    
    end
end

function closeness=isclose(ind,inds,Mindiffer)
    closeness=false;
    for i=1:length(inds)
        dist = sum((ind.parameter-inds(i).parameter).^2);
        closeness=dist < Mindiffer;
        if closeness
            break;
        end
    end
end
 