function predInds=ModelEvaluate(predInds, Model, params, GPstruct)
    name = GPstruct.GPname;
    obj_model = Model.model;
    %% Global model prediction
    Popsize=size(predInds.parameter, 2);
    Nobj=params.N_obj;
    X = [predInds.parameter]';

    %% Model prdiction
    switch name
        case 'CoMOGP'
            model = obj_model;
            [u, s] = predict_tasks(X, model);
            u =cell2mat(u); s = cell2mat(s);
            PredObj = u'; PredVar = s';
        case 'InGP'
            PredObj = zeros(Nobj, Popsize); PredVar = zeros(Nobj, Popsize);
            for i = 1 : Nobj
                dmodel = obj_model{i};
                [u, s] = predict_tasks(X, dmodel);
                PredObj(i, :) = cell2mat(u); PredVar(i, :) = cell2mat(s);
            end
        case 'DEGP'
            PredVar = zeros(Nobj, Popsize); PredObj = zeros(Nobj, Popsize);
            for j = 1 : Nobj
                dmodel = obj_model{j};
                [y, mse] = predictor0(X, dmodel);
                PredObj(j, :) = y; PredVar(j, :) = mse;
            end
        case 'RBF'
            model = obj_model;
            y = zeros(Nobj, 1);
            for i = 1 : Nobj
                dmodel = model{i};
                y(i) = my_rbfpredict(dmodel.RBF_Model, dmodel.P, X);
            end
            PredObj = y; PredVar = 0;
    end
    predInds.PredObjs = PredObj; predInds.PredVars = PredVar;
end