function [subproblems]=moeadde(mop,params,subproblems,model, AFstruct, NP_size, GPstruct, strategy)
    Popsize=length(subproblems);
    NeiUseR = params.MOEAD_NeiUseR;
    Gens = params.MOEAD_Gens;
    idealArr = zeros(Gens, Popsize);

    if strcmp(strategy, 'None')
        for i=1 : Gens
            selindex=randperm(Popsize);
            for j=1 : Popsize
                index = selindex(j);
                useneighbour = rand < NeiUseR;
                ind = genetic_op(subproblems,params,mop,index,useneighbour);
    %             [~, v] = evaluate(mop, ind);
    %             EvaObj = subobjective(subproblems(j).weight, v.objective, params.Dmethod);
                predInd=ModelEvaluate(ind, model, params, GPstruct);
    %             [SubpObj, SubpVar] = tchGP(subproblems(j).weight, predInd.PredObjs, predInd.PredVars, idealpoint);
    %             ideal = (SubpObj - EvaObj) ./ SubpVar;
    %             idealArr(i, j) = ideal;
                [subproblems]=update(params,subproblems,index,predInd,useneighbour, AFstruct, NP_size, model);% repalcement
            end
        end
    else
        lu = mop.domain;
        Ndec = mop.pd;
        minerror = 1e-5;
        for i = 1 : Popsize
            [bestInd, bestFit, predObj, predVar] = DE(Ndec, Gens, minerror, lu', model.model, params, subproblems(i));
            subproblems(i).curpoint.parameter = bestInd';
            subproblems(i).prescreenFit = bestFit;
            subproblems(i).SubpObjs = predObj;
            subproblems(i).SubpVars = predVar;
        end
    end
end
%% mating
function ind = genetic_op(subproblems,params,mop,index,useneighbour)
%% mating selection 
  if useneighbour
    parentindex=subproblems(index).neighbors;
  else
    parentindex=(1:length(subproblems))';
  end
  MatPoolSize=4; Counter=1;
  SelectIdx=zeros(1,MatPoolSize); SelectIdx(Counter)=index;
  while(Counter<MatPoolSize)
      parent = ceil(length(parentindex)*rand);
      indexsel = parentindex(parent);
      if ~any(ismember(indexsel, SelectIdx))
          Counter=Counter+1;
          SelectIdx(Counter)=indexsel;
      end
  end 
  temppoint = de_crossover(subproblems,SelectIdx,params.MOEAD_F,params.MOEAD_CR,mop);
  newpoint = realmutate(temppoint,mop.domain, 1/mop.pd);
  ind = get_structure('PredInd');
  ind.parameter = newpoint;
end
function ind = de_crossover(subproblems,SelectIdx,F,CR,mop)
  jrandom = ceil(rand*mop.pd);
  %retrieve the individuals.
  points = [subproblems(SelectIdx).curpoint];
  selectpoints = [points.parameter];
  ind = selectpoints(:,1);
  %DE operation.
  for i=1:mop.pd
      if (rand<CR || i==jrandom)
          value = selectpoints(i,1) + F.*(selectpoints(i,2)-selectpoints(i,3));
          lowbound = mop.domain(i,1);
          upbound = mop.domain(i,2);
          %handle the boundary.
          if (value<lowbound)
            ind(i)=lowbound + rand*(selectpoints(i,1)-lowbound);
          elseif (value>upbound)
            ind(i)=upbound - rand*(upbound - selectpoints(i,1));
          else
            ind(i)=value;             
          end
      end     
  end
end
function ind = realmutate(ind, domains, rate)
%REALMUTATE Summary of this function goes here
%   Detailed explanation goes here

  % double rnd, delta1, delta2, mut_pow, deltaq;
  % double y, yl, yu, val, xy;
  % double eta_m = id_mu;
  eta_m=20;
  if (isstruct(ind))
      a = ind.parameter;
  else
      a = ind;
  end
  for j = 1:length(a)
      r = rand;
      if (r <= rate) 
        y = a(j);
        yl = domains(j,1);
        yu = domains(j,2);
        delta1 = (y - yl) / (yu - yl);
        delta2 = (yu - y) / (yu - yl);
        rnd = rand;
        mut_pow = 1.0 / (eta_m + 1.0);
        if (rnd <= 0.5) 
	      xy = 1.0 - delta1;
	      val = 2.0 * rnd + (1.0 - 2.0 * rnd) * (xy^(eta_m + 1.0));
	      deltaq = (val^mut_pow) - 1.0;
        else 
	      xy = 1.0 - delta2;
	      val = 2.0 * (1.0 - rnd) + 2.0 * (rnd - 0.5) * (xy^ (eta_m + 1.0));
	      deltaq = 1.0 - (val^mut_pow);
        end
	  
        y = y + deltaq * (yu - yl);
        if (y < yl)
	      y=yl+rand*(a(j)-yl);
        elseif (y > yu)
	      y=yu-rand*(yu-a(j));
        end
        a(j) = y;        
      end
  end
  if isstruct(ind)
      ind.parameter = a;
  else
      ind = a;
  end
end
%% replacing
function [subproblems]=update(params,subproblems,index,predInd,useneighbour, AFstruct, NP_size, model)
    if useneighbour
        updateindex=subproblems(index).neighbors;
    else
        updateindex=(1:length(subproblems))';
    end 
    select_problem = subproblems(updateindex);       
    oldobj=[select_problem.prescreenFit];
    switch AFstruct.name
        case 'EI'
            [newobj, ~, ~]=SubpExI([select_problem.weight],[select_problem.subpmin],predInd.PredObjs,predInd.PredVars,params.Dmethod);
        case 'PI'
            newobj=SubpPI([select_problem.weight],[select_problem.subpmin],predInd.PredObjs,predInd.PredVars,params.Dmethod);
        case 'LCB'
            [newobj, ~, ~]=SubpLCB([select_problem.weight],predInd.PredObjs,predInd.PredVars,[select_problem.alpha],params.Dmethod);
        case 'ALCB'
            newobj=ALCB([select_problem.weight], predInd.PredObjs, predInd.PredVars,params.Dmethod, NP_size, [select_problem.subpmin]);
        case 'LCB_LS'
            [newobj, ~, ~] = LCB_LS([select_problem.weight],predInd.PredObjs,predInd.PredVars,[select_problem.alpha],[select_problem.subpmin], params.Dmethod);
        case 'GP-RBF'
            Obj = zeros(params.N_obj, 1);
            for i = 1 : params.N_obj
                dmodel = model.RBF{i};
                ind = [predInd.PredObjs(i), predInd.PredVars(i)];
                y = my_rbfpredict(dmodel.RBF_Model, dmodel.P, ind);
                Obj(i) = y;
            end
            newobj = subobjective([select_problem.weight], Obj, params.Dmethod);
        case 'RBF'
            newobj = subobjective([select_problem.weight], predInd.PredObjs, params.Dmethod);
        otherwise
            error('No such name for Acqusition Function!')
    end
      %new solution is better?
      if size(newobj, 2) ~= size(oldobj, 2)
          newobj = repmat(newobj, size(oldobj, 1), size(oldobj, 2));
      end
      C=newobj<oldobj;  
      %repace with the new one
       if (length(C(C==1))<= params.MOEAD_UpSize)
           toupdate = updateindex(C);
       else
           toupdate = randsample(updateindex(C),params.MOEAD_UpSize);
       end

       for i=1:length(toupdate)
           subindex=toupdate(i);
           subproblems(subindex).curpoint=predInd;
           subproblems(subindex).prescreenFit = newobj(updateindex == subindex);
       end
end

function [SubpMeans, SubpVars] = tchGP(weight, ObjMeans, ObjVars, idealpoint)
    [Nobj, Nw] = size(weight);
    Nind = size(ObjMeans, 2);

    if Nind == 1
        U = weight .* repmat((ObjMeans - idealpoint), 1, Nw);
        V = (weight .^ 2) .* repmat(ObjVars, 1, Nw);
    elseif Nw == 1
        U = repmat(weight, 1, Nind) .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (repmat(weight, 1, Nind) .^ 2) .* ObjVars;
    elseif Nw == Nind
        U = weight .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (weight .^ 2) .* ObjVars;
    else
        error('individual size must be same as weight size, or equals 1');
    end

    Cur_u = U(1, :); Cur_v = V(1, :);

    for i = 2:Nobj
        u1 = Cur_u; v1 = Cur_v;
        u2 = U(i, :); v2 = V(i, :);
        t = sqrt(v1 + v2);
        a = (u1 - u2) ./ t;
        Cur_u = u1 .* normcdf(a) + u2 .* normcdf(-a) + t .* normpdf(a);
        Cur_v = (u1 .^ 2 + v1) .* normcdf(a) + (u2 .^ 2 + v2) .* normcdf(-a) + (u1 + u2) .* t .* normpdf(a) - Cur_u .^ 2;

        if any(Cur_v < 0)
            if all(Cur_v >- eps)
                Cur_v(Cur_v < 0) = 0;
                warning('Predicted objective variance is less than 0, and has been corrected to 0');
            else
                error('Predicted objective variance is less than 0, and the error is too large');
            end

        end

    end
    SubpMeans = Cur_u; SubpVars = Cur_v;
end