function MTGP_model=learn_gp(X,Y, GPstruct)
    ModelMethod = GPstruct.modelMethod;
    MTGP_mode = GPstruct.mode;
    %LEARN_MTGP Learns hyperparameters of mtgp model using minimize
    %% -------------------------normailization---------------------------------
    normY = 'Yes'; normX = 'Yes'; 
    N_dataset=length(X); N_task=length(X); N_dim=size(X{1}, 2);
    X_norm=X; sX=mat2cell(repmat([0;1],1,N_dim*N_dataset),[1,1],N_dim*ones(1,N_dataset));
    Y_norm=Y; sY=num2cell(repmat([0;1],1,N_dataset));
    Xtrain_range=cell(1,N_task);
    for i=1:N_dataset
        if strcmp(normY, 'Yes')
            sY{1,i}=mean(Y{i}); sY{2,i}=std(Y{i});
            Y_norm{i}=(Y{i}-sY{1,i})./sY{2,i};
        end
        if strcmp(normX, 'Yes')
            sX{1,i}=mean(X{i}); sX{2,i}=std(X{i});
            X_norm{i}=(X{i}-repmat(sX{1,i},size(X{i},1),1))./repmat(sX{2,i},size(X{i},1),1);
        end
        Xtrain_range{i}=max(X_norm{i})-min(X_norm{i});
        X_norm{i}=[X_norm{i},i*ones(size(X_norm{i},1),1)];     
    end
    %==============================================================================    
    %% -------------------------Model setting--------------------------------
%     ModelMethod = 'CoMOGP';
    %----------------------------Mean functions--------------------------------
    % model.meanfunc = {@meanSum, {@meanLinear, @meanConst}}; 
    % model.meanfunc =[];
    % model.meanfunc =@meanConst;
    %     model.meanfunc = {@meanPoly,1};
    switch GPstruct.meanfunc
        case '2'
        model.meanfunc = {@meanSum, {{@meanPoly,2}, @meanConst}};
        MeanRegDim = 2*N_dim+1;
        case '1'
        model.meanfunc = {@meanSum, {{@meanPoly, 1}, @meanConst}};
        MeanRegDim = N_dim + 1;
        case '0'
        model.meanfunc = {@meanSum, {{@meanPoly, 0}, @meanConst}};
        MeanRegDim = N_dim + 1;
    end
    % MeanRegDim = 1;
    %----------------------------GP functions----------------------------------
    %--------------------------likelihood function-----------------------------
    %--------------------------Inference methods-------------------------------
%     MTGP_mode = 'MTGP_diff_sn2';
    switch MTGP_mode
        case 'SingGP' % GP function, can only be used for single GP
            model.GPfunc = @gp;      
            model.likfunc = @likGauss;     %Gaussian likelihood
            model.inffunc = @infGaussLik;  
        case 'MTGP_no_sn2' %MTGP function without noise variance
            model.GPfunc = @MTGP_nosn2_my;        
            model.likfunc = @likGauss_nosn2_my;
            model.inffunc = @MTGP_infExact_nosn2_my;
            LikDim = 0;    
        case 'MTGP_sing_sn2' %MTGP function with one noise variance
            model.GPfunc = @MTGP_my;          
            model.likfunc = @likGauss_my;
            model.inffunc = @MTGP_infExact_my;
            LikDim = 1;            
        case 'MTGP_diff_sn2' %MTGP function with T independant noise variances
            model.GPfunc = @MTGP_diffsn2_my;
            model.likfunc = @likGauss_diffsn2_my;
            model.inffunc = @MTGP_infExact_diffsn2_my;
            LikDim = N_task; %each task have one noise
    end
    %--------------------------covariance function-----------------------------
    %============================================================================== 
    %% -------------------------Set Parameters---------------------------------
    % ell = 0.2*(max(Xtrain)-min(Xtrain))';
    ell = 1.0;% initial hyperparas
    sf2 = 1.0;
    sn2 = 1e-3;
    hyp= get_structure('hyperparams');
    post= get_structure('post');
    if strcmp(ModelMethod,'InGP')||strcmp(ModelMethod,'TrGP')
        N_model=N_dataset;
        if strcmp(func2str(model.GPfunc),'gp')
            X_train=cellfun(@(x) x(:,1:end-1),X_norm,'UniformOutput',false);
            Y_train=Y_norm;
            model.covfunc = @covSEard; %Squared Exponential covariance function        
        else
            X_train=X_norm; Y_train=Y_norm;
            model.covfunc = 'MTGP_covSEard';
        end
        hyp.mean=ones(MeanRegDim,1);
        if strcmp(MTGP_mode,'MTGP_no_sn2')
            hyp.lik=[];
        else
            hyp.lik=log(sqrt(sn2));
        end
        hyp.cov = [log(ell)*ones(1,N_dim) log(sqrt(sf2))]';
        hyps=repmat(hyp,1,N_model);
        for i=1:N_task
            hyps(i).cov=[log(ell*Xtrain_range{i}) log(sqrt(sf2))]';
        end
    else
        N_model=1;
        X_train={cell2mat(X_norm')};
        Y_train={cell2mat(Y_norm')};
        hyp.mean=ones(MeanRegDim,1);
        hyp.lik = log(sqrt(sn2))*ones(LikDim,1);            %must be T*1 vector

        corrs = zeros(1,N_task*(N_task+1)/2); %pre-define correlation matrix Kf
        for i = 1:N_task,corrs(i*(i+1)/2)=1; end
        switch ModelMethod % MOGP names
            case 'MTGP' % original MTGP (full rank) <- intrinsic coregionalization model (ICM)
                        % 2007-Multi-task Gaussian process prediction
                model.covfunc = 'MTGP_Bonilla_covSEard';
                hyp.cov = [corrs log(ell)*ones(1,N_dim) log(sqrt(sf2))]';             
            case 'SLFM' % semi-parametric latent factor model (also known as linear model of coregionalization)
                model.covfunc = 'MTGP_SLFM_covSEard_2tasks';
                hps = [corrs     log(ell)*ones(1,N_dim)     log(sqrt(sf2)) ...
                    corrs+0.1     log(ell+0.1)*ones(1,N_dim)     log(sqrt(sf2))]';
                hyp.cov = hps(1:(N_task*(N_task+1)/2+N_dim+1)*2);%%%%%here 2 latent functions are used, the number also can be N_task
            case 'CoMOGP' % Collaborative multi-output Gaussian process
                        % 2014-Collaborative multi-output Gaussian processes
                model.covfunc = 'MTGP_CoMOGP_covSEard_Mtasks';
                Xsss=zeros(1,N_task*(N_dim+1));
                for i=1:N_task
                    Xsss((i-1)*(N_dim+1)+1:i*(N_dim+1))=[log(ell*Xtrain_range{i}) log(sqrt(sf2))];
                end
                hyp.cov = [corrs log(ell)*ones(1,N_dim) log(sqrt(sf2)) Xsss]'; 
            case 'CONV' % process convolution
                model.covfunc = 'MTGP_covSEard_ProConv_Mtasks';
                hyp.cov = [corrs repmat([log(ell)*ones(1,N_dim) log(sqrt(sf2))],1,N_task)]';
        end
        hyps=repmat(hyp,1,N_model);
        posts=repmat(post,1,N_model);
    end

    %==============================================================================    
    %% -------------------------Hyperparameter Optimization -----------------------
    % optimization settings
    OptMethod = 'GradientDescent'; % 'GradientDescent', 'fmincon', 'DE'
%     numOptFC = -ceil(500/N_model); % maximum number of function evaluations. In practice, 100 is good enough!
    numOptFC = -100;
    %==============================================================================   
    for i=1:N_model
        switch OptMethod
            case 'GradientDescent'
                % optimize
                results.hyp=minimize(hyps(i),model.GPfunc,numOptFC,model.inffunc,model.meanfunc,model.covfunc,model.likfunc,X_train{i},Y_train{i});
                % train
                [results.nlml,results.dnlZ,results.post]=feval(model.GPfunc,results.hyp,model.inffunc,model.meanfunc,model.covfunc,model.likfunc,X_train{i},Y_train{i});
            case 'fmincon'
                % optimize
                results.hyp=hypOpt(hyps(i),model.GPfunc,numOptFC,model.inffunc,model.meanfunc,model.covfunc,model.likfunc,X_train{i},Y_train{i});
                % train
                [results.nlml,results.dnlZ]=feval(model.GPfunc,results.hyp,model.inffunc,model.meanfunc,model.covfunc,model.likfunc,X_train{i},Y_train{i});
        end
        hyps(i) = results.hyp;
        posts(i) = results.post;
    end  
        model.method=ModelMethod;
        model.S=X;
        model.Y=Y;
        model.x_norm = X_norm;
        model.y_norm = Y_norm;
        model.x_train = X_train;
        model.y_train = Y_train;    
        model.sX = sX;
        model.sY = sY;
        model.hyps = hyps;
        model.posts = posts;
        model.N_task = N_task;
        model.N_model = N_model;
        MTGP_model=model;
    
    % PopSize=1000; all_inds=zeros(PopSize,params.N_task);
    % lowerbound=mop.domain(:,1);domains=mop.domain(:,2)-mop.domain(:,1);
    % pops=lowerbound+rand(mop.pd,PopSize).*domains;
    % for j = 1 : PopSize
    %     [v,~]=evaluate(mop,pops(:,j));
    %     subobjs = subobjective([subproblems.weight], v, 'tch');
    %     all_inds(j,:)=subobjs;
    % end
    % [Ypred,~] = predict_tasks(pops',MTGP_model,subproblems);
    % raae_test = sum(abs(all_inds-cell2mat(Ypred)))./(PopSize*std(all_inds))
    % global evalCounter;
    % evalCounter = evalCounter-PopSize;
end

