function [EvaInds,subproblems]=init(mop,params,strategy)
%Set up the initial setting for the MOEA/D.
%loading the params.
global evalCounter itrCounter idealpoint;  
    evalCounter = 0;
    itrCounter = 1;
    idealpoint=ones(mop.od,2)*Inf;
  %initial the subproblems for MOEA/D-DE.
  subproblems = init_weights(params,mop.od,strategy);
  preInd=get_structure('PredInd');
  [subproblems.curpoint]=deal(preInd); 
  [subproblems.subpmin]=deal(Inf);
  %initial the population.
  initialSize=params.initsize;lowerbound=mop.domain(:,1);domains=mop.domain(:,2)-mop.domain(:,1);
  pop=lhsdesign(initialSize,mop.pd,'iterations',5).*repmat(domains',initialSize,1)+repmat(lowerbound',initialSize,1);
  indiv=get_structure('individual');EvaInds=repmat(indiv,1,initialSize); Newidealpoint = idealpoint(:, 2);
  for i=1:initialSize
      indiv.parameter=pop(i,:)';
      [v,ind]=evaluate(mop,indiv);
      EvaInds(i) = ind;
%       idealpoint(idealpoint>v)=v(idealpoint>v)-1e-3;
      idealpoint(:, 2) = min(idealpoint(:, 2),v-5e-2);
      obj=subobjective([subproblems.weight],v,params.Dmethod);
      LogiIdx=[subproblems.subpmin]>obj;
      temp=num2cell(obj(LogiIdx));
      [subproblems(LogiIdx).subpmin]=temp{:};
  end
end
function subp=init_weights(params,objDim,strategy)
% init_weights function initialize a pupulation of subproblems structure
% with the generated decomposition weight and the neighborhood relationship.
%initialize direction vectors with unity simplex;
%compute their neighborhood relationship and get their corresponding weight vectors
if ~strcmp(strategy, 'ASS')
    H=params.MOEAD_H;
% 	M = simplex_weightno(H, 0, objDim); 
    M = 100;
    W = zeros(objDim, M); C = 0; V = zeros(objDim,1);
    [W, ~] = simplex_weightset(W, C, V, H, 0, objDim, objDim);
    W = W/(H+0.0);
    v = squareform(pdist(W'));
%    W((W == 0)) = 1.0E-06;
%      W=1./W;
     %Set up the neighbourhood.
    [~, neighborrelation]= sort(v);
    p=get_structure('subproblem');
    subp=repmat(p,1,M);
    Wcells = mat2cell(W, objDim, ones(1, size(W,2)));
    [subp.weight] = Wcells{:};
    Tcells = mat2cell(neighborrelation(1:params.MOEAD_NeiSize,:), params.MOEAD_NeiSize, ones(1, M));
    [subp.neighbors] = Tcells{:};
else
    H=params.MOEAD_H;
	M = simplex_weightno(H, 0, objDim); 
    W = zeros(objDim, M); C = 0; V = zeros(objDim,1);
    [W, ~] = simplex_weightset(W, C, V, H, 0, objDim, objDim);
    W = W/(H+0.0);
    v = squareform(pdist(W'));
    W((W==0))=1.0E-06; dirctlength=sqrt(sum(W.^2));
    Weights=1./W; Weights=Weights./repmat(sum(Weights),objDim,1);
    %Set up the neighbourhood.
    [~, neighborrelation]= sort(v);
    p=get_structure('subproblem'); subp=repmat(p,1,M);
    weightCells=num2cell(Weights,1);[subp.weight]=weightCells{:};
    directionCells=num2cell(W,1);[subp.direction]=directionCells{:};
    dirctlengthCells=num2cell(dirctlength);[subp.directlength]=dirctlengthCells{:};
%     neighborCells=num2cell(neighborrelation(1:params.MOEAD_NeiSize,:),1);[subp.neighbors]=neighborCells{:};
    neighborCells=num2cell(neighborrelation,1);[subp.neighbors]=neighborCells{:};
end
end
function M = simplex_weightno(unit, sum, dim)
% simplex_weightno function compute the number of weight vectors with the given unit and sum.
% the output of this function M is the number of weight vectors with the given unit and sum.
    M = 0;

    if dim == 1
        M = 1; 
        return;
    end

    for i=0:1:(unit - sum)
        M = M + simplex_weightno(unit, sum+i, dim-1);
    end

end
function [w, c] =simplex_weightset(w, c, v, unit, sum, objdim, dim)

if dim == objdim
    v = zeros(objdim, 1);
end

if dim == 1
    c       = c+1;
    v(1)    = unit-sum;
    w(:,c)  = v;
    return;
end

for i=0:1:(unit - sum)
    v(dim)  = i;
    [w, c]  = simplex_weightset(w, c, v, unit, sum+i, objdim, dim-1);
end

end