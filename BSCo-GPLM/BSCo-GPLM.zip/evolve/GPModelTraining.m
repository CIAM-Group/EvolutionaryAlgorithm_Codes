function [CModels, selectIdx]=GPModelTraining(EvaInds,params, GPstruct, settingStruct)
    X=[EvaInds.parameter]'; y=[EvaInds.objective]';
    ts = GPstruct.ts;
    globalpred = settingStruct.globalpred;
    cluster = settingStruct.cluster;
    dynamic = settingStruct.dynamic;
    Ndec=size(X,2); [Ndata, Nobj] = size(y);
    EvaIdx = linspace(1, Ndata, Ndata);
    trainSize = ceil(ts * Ndata);
    if ~globalpred
        trainIdx = randsample(EvaIdx, trainSize);
        testIdx = setdiff(EvaIdx, trainIdx);
        name = GPstruct.GPname;
        temp_X = X(trainIdx, :);
        temp_y = y(trainIdx, :);
    else
        trainIdx = EvaIdx;
        testIdx = [];
        name = GPstruct.GPname;
        temp_X = X(trainIdx, :);
        temp_y = y(trainIdx, :);
    end
    Cdata = size(temp_X, 1);
    if cluster
        CModelInd = get_structure('CModel');
        if Cdata <= params.L1
            ClusterNo=1;
        else
            ClusterNo=1+ceil((Cdata-params.L1)/params.L2);
        end
        if ClusterNo~=1 
            CModels=repmat(CModelInd,1,ClusterNo);
            [centers,U,~] = fcm(temp_X,ClusterNo,[2.0,1000,10e-6,0]);
            [~,idx] = sort(U,2,'descend');
            CenterCell=mat2cell(centers',Ndec,ones(1,ClusterNo));
            IdxCell=mat2cell(idx(:,1:params.L1)',params.L1,ones(1,ClusterNo));
            [CModels.center]=CenterCell{:};
            [CModels.idx]= IdxCell{:};
        else
            CModels.idx = linspace(1, length(trainIdx), length(trainIdx));
        end
    else
        CModels.idx = linspace(1, length(trainIdx), length(trainIdx));
        ClusterNo = 1;
    end

    if length(testIdx) > 20 && ~dynamic
        test_X = X(testIdx, :);
        distMat = dist(train_X, test_X');
        D = sum(distMat);
        [~, sortIdx] = sort(D);
        selectIdx = testIdx(sortIdx(1 : 20));
    else
        selectIdx = testIdx;
    end

    switch name
        case 'CoMOGP'
            for j = 1 : ClusterNo
                train_X_cell = cell(1, Nobj); train_y_cell = cell(1, Nobj);
                train_X = temp_X(CModels(j).idx, :); train_y = temp_y(CModels(j).idx, :);
                for i = 1 : Nobj
                    train_X_cell{1, i} = train_X;
                    train_y_cell{1, i} = train_y(:, i);
                end      
                models = learn_gp(train_X_cell, train_y_cell, GPstruct);
                CModels(j).model = models;
            end
        case 'InGP'
            train_X_cell = cell(1, Nobj); train_y_cell = cell(1, Nobj);
            models = cell(1, Nobj);
            train_X = temp_X(CModels.idx, :); train_y = temp_y(CModels.idx, :);
            for i = 1 : Nobj
                train_X_cell{1, i} = train_X;
                train_y_cell{1, i} = train_y(:, i);
                model = learn_gp(train_X_cell(i), train_y_cell(i), GPstruct);
                models{i} = model;
            end
            CModels.model = models;
        case 'DEGP'
            LowBound=[10*eps*zeros(Nobj,Ndec),ones(Nobj,Ndec)];
            UpBound=[10*ones(Nobj,Ndec),2*ones(Nobj,Ndec)];
            InitTheta=LowBound+unifrnd(0,1,Nobj,2*Ndec).*(UpBound-LowBound); 
            models = cell(1, Nobj);
            train_X = temp_X(CModels.idx, :); train_y = temp_y(CModels.idx, :);
            for i=1:Nobj
                model=dacefit_DESolver(train_X,train_y(:, i),'regpoly0','corrgauss',InitTheta(i,:),LowBound(i,:),UpBound(i,:),params);
                models{i}=model;
            end
            CModels.model = models;
        case 'RBF'
            train_X = temp_X(CModels.idx, :); train_y = temp_y(CModels.idx, :);
            models = cell(1, Nobj);
            for i = 1 : Nobj
                srgOPT = srgtsRBFSetOptions(train_X, train_y(:, i), @my_rbfbuild, [], 'CUB', 0.0002, 1);
                dmodel = srgtsRBFFit(srgOPT);
                models{i} = dmodel;
            end
            CModels.model = models;
    end

end

function [trainIdx, sortIdx] = SelectTrainingData(F)
    XIdx = linspace(1, length(F), length(F));
    PFIdx = find(F == 1);
    otherIdx = setdiff(XIdx, PFIdx);
    PFnum = length(PFIdx); otherNum = length(otherIdx);
    PFtrain = floor(0.7 * PFnum); OtherTrain = floor(0.7 * otherNum);
    PFtrainIdx = randsample(PFIdx, PFtrain); OtherTrainIdx = randsample(otherIdx, OtherTrain);
    PFtestIdx = setdiff(PFIdx, PFtrainIdx); OthertestIdx = setdiff(otherIdx, OtherTrainIdx);
    trainIdx = [PFtrainIdx, OtherTrainIdx];
    sortIdx = [PFtestIdx, OthertestIdx];
end