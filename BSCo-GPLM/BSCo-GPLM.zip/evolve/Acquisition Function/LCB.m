function [obj] = LCB(PredObj, PredVar, kappa)
    s = sqrt(PredVar);

    if ~isreal(s)
        error('The subproblem MES (s) is estimated as a negtive value');
    end

    obj = PredObj' - kappa * PredVar';
    obj = obj';
end

    