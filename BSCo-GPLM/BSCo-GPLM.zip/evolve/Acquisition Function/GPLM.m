function [obj, SubpMeans, SubpVars] = GPLM(weights, ObjMeans, ObjVars, kappa, subpmins, method)
%     % itrCounter is a global varible
%      global itrCounter

    %SUBOBJECTIVE function evaluate a point's objective with a given method of
    %decomposition.

    %   Two method are implemented by far is Weighted-Sum and Tchebesheff.
    %   weight: is the decomposition weight.(column wise vector).
    %   ind: is the individual point(column wise vector).
    %   idealpoint: the idealpoint for Tchebesheff decomposition.
    %   method: is the decomposition method, the default is 'te' when is
    %   omitted.
    %
    %   weight and ind can also be matrix. in which have two scenairos:
    %   When weight is a matrix, then it's treated as a column wise set of
    %   weights. in that case, if ind is a size 1 column vector, then the
    %   subobjective is computed with every weight and the ind; if ind is also
    %   a matrix of the same size as weight, then the subobjective is computed
    %   in a column-to-column, with each column of weight computed against the
    %   corresponding column of ind.
    %   A row vector of subobjective is return in both case.
    global idealpoint;

    if strcmp(method, 'ws')
        [SubpMeans, SubpVars] = wsGP(weights, ObjMeans, ObjVars);
    elseif strcmp(method, 'tch')
        [SubpMeans, SubpVars] = tchGP(weights, ObjMeans, ObjVars, idealpoint(:, 2));
    else
        [SubpMeans, SubpVars] = tchGP(weights, ObjMeans, ObjVars, idealpoint(:, 2));
    end

    Nw = size(weights, 2); Nind = size(SubpMeans, 2);

    if Nw == Nind
        s = sqrt(SubpVars);
    elseif Nw == 1
        s = sqrt(SubpVars);
    elseif Nind == 1
        s = repmat(sqrt(SubpVars), 1, Nw);
    else
        error('individual size must be same as weight size, or equals 1');
    end

    if ~isreal(s)
        error('The subproblem MES (s) is estimated as a negtive value');
    end
    lcb = (SubpMeans - kappa.*s);
    obj = lcb;
end

% weighted sum scalarization Function
function [SubpMeans, SubpVars] = wsGP(weight, ObjMeans, ObjVars)
    s = size(weight, 2);
    indsize = size(ObjMeans, 2);

    if s == 1
        SubpMeans = (weight' * ObjMeans);
        SubpVars = ((weight .^ 2)' * ObjVars);
    elseif indsize == 1
        SubpMeans = (weight' * ObjMeans)';
        SubpVars = ((weight .^ 2)' * ObjVars)';
    elseif indsize == s
        SubpMeans = sum(weight .* ObjMeans);
        SubpVars = sum((weight .^ 2) .* ObjVars);
    else
        error('individual size must be same as weight size, or equals 1');
    end

end

% Techbycheff Scalarization Function
function [SubpMeans, SubpVars] = tchGP(weight, ObjMeans, ObjVars, idealpoint)
    [Nobj, Nw] = size(weight);
    Nind = size(ObjMeans, 2);

    if Nind == 1
        U = weight .* repmat((ObjMeans - idealpoint), 1, Nw);
        V = (weight .^ 2) .* repmat(ObjVars, 1, Nw);
    elseif Nw == 1
        U = repmat(weight, 1, Nind) .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (repmat(weight, 1, Nind) .^ 2) .* ObjVars;
    elseif Nw == Nind
        U = weight .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (weight .^ 2) .* ObjVars;
    else
        error('individual size must be same as weight size, or equals 1');
    end

    Cur_u = U(1, :); Cur_v = V(1, :);

    for i = 2:Nobj
        u1 = Cur_u; v1 = Cur_v;
        u2 = U(i, :); v2 = V(i, :);
        t = sqrt(v1 + v2);
        a = (u1 - u2) ./ t;
        Cur_u = u1 .* normcdf(a) + u2 .* normcdf(-a) + t .* normpdf(a);
        Cur_v = (u1 .^ 2 + v1) .* normcdf(a) + (u2 .^ 2 + v2) .* normcdf(-a) + (u1 + u2) .* t .* normpdf(a) - Cur_u .^ 2;
        if any(Cur_v < 0)
            Cur_v(Cur_v < 0) = 1e-6; 
            warning('Predicted objective variance is less than 0, and has been corrected to 0');
            % if all(Cur_v >- eps)
            %     Cur_v(Cur_v < 0) = 1e-6;
            %     warning('Predicted objective variance is less than 0, and has been corrected to 0');
            % else
            %     a = 1;
            %     error('Predicted objective variance is less than 0, and the error is too large');
            % end
        end
    end

    SubpMeans = Cur_u; SubpVars = Cur_v;
end
