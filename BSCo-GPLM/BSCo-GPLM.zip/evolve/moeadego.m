function [EvaPS,EvaPF, IterationsStructs]=moeadego(mop,params,ExistingEvaInds,subproblems,sel, AFstruct, PFtrue, GPstruct, settingStruct)
    %run MOEA/D-EGO for the given mop
    global itrCounter evalCounter;
    EvaPS = {};
    EvaPF = {};

    EvaPS{1, 1} = [ExistingEvaInds.parameter];
    EvaPF{1, 1} = [ExistingEvaInds.objective];
    StoreCounter = 1;
    %evolve
    SuccessPrescreen=false;
    UB = 0;
    IterationsStructs = struct();
    iterationsStructsPointer = 1;
    CosAngaleMatrix = [];
    LastSelect = [];

    while ~terminate(params)
        fprintf("Iteration %d \n", itrCounter);
        iterationtic = tic;
        [NewEvaInds,subproblems,MT_NewModel,SuccessPrescreen,SelectedIndexes, PS, PF, CosAngaleMatrix] = ...
        evolve(mop,params,ExistingEvaInds,subproblems,SuccessPrescreen, AFstruct, GPstruct, settingStruct, CosAngaleMatrix, LastSelect);

        if (evalCounter>=StoreCounter*params.evaluation/sel)
            StoreCounter=StoreCounter+1;
            EvaPS{1,StoreCounter}=[NewEvaInds.parameter]; 
            EvaPF{1,StoreCounter}=[NewEvaInds.objective];
        end        
        igd = IGD(PFtrue, EvaPF{1, end});
        fprintf('igd of iteration %d is %d \n', itrCounter, igd)
        fprintf('time for iteration %d is %d \n', itrCounter, toc(iterationtic))
        fprintf('Proceeding evaluations: %d \n', evalCounter)
     
        ExistingEvaInds=NewEvaInds;
        LastSelect = SelectedIndexes;
        itrCounter=itrCounter+1;
        
        IterationsStructs(iterationsStructsPointer).NewEvaInds = NewEvaInds;
        IterationsStructs(iterationsStructsPointer).PF = PF;
        IterationsStructs(iterationsStructsPointer).igd = igd;
        iterationsStructsPointer = iterationsStructsPointer + 1;
        
%         updateplot(itrCounter,evalCounter,ExistingEvaInds, AF, PFtrue, mop);
%         file_name = AF + "_res_data/"+ mop.name + "/data" + 1 + ".mat";
%         save(file_name, 'EvaInds');
    end
end
% The evoluation setp
function [NewEvaInds,subproblems,Model,SuccessPrescreen,SelectedIndexes, PS, PF, CosAngaleMatrix]=...
    evolve(mop,params,EvaInds,subproblems,SuccessPrescreen, AFstruct, GPstruct, settingStruct, CosAngaleMatrix, LastSelect)
    global idealpoint evalCounter;
    evalCounter = length(EvaInds);
    y = [EvaInds.objective]';
    X = [EvaInds.parameter]';
    [F, ~] = NDsort(y, inf);
    PF = y(F == 1, :);
    PS = X(F == 1, :);
    PFIdx = find(F == 1);
    NP_size = size(PF, 1);
%% Train GP model
    [Model, selectIdx]=GPModelTraining(EvaInds, params, GPstruct, settingStruct);
%     [Global_Model, ~, ~] = GPModelTraining(EvaInds, params, PreviousHyp, GPstruct, F, settingStruct, true);
    select_X = [EvaInds(selectIdx).parameter]; select_y = [EvaInds(selectIdx).objective]';
    sortInds = get_structure('PredInd');
    sortInds.parameter = select_X; sortInds.objective = select_y;
%% Predict on the testset
    if strcmp('LCB_LS', AFstruct.name)
        sortInds = ModelEvaluate(sortInds, Model, params, GPstruct);
    end

    if strcmp(AFstruct.name, 'GP-RBF')
        PredObj = [sortInds.PredObjs]'; PredVar = [sortInds.PredVars]';
        RBF_Y = [sortInds.objective];
        RBFModel = cell(1, params.N_obj);
        for i = 1 : params.N_obj
            RBF_X = [PredObj(:, i), PredVar(:, i)];
            srgOPT = srgtsRBFSetOptions(RBF_X, RBF_Y(:, i), @my_rbfbuild, [], 'CUB', 0.0002, 1);
            dmodel = srgtsRBFFit(srgOPT);
            RBFModel{i} = dmodel;
        end
        Model.RBF = RBFModel;
    end
    strategy = settingStruct.strategy;
    switch strategy
    case 'ASS'
        [SelectedIndexes, CosAngaleMatrix] = SubproblemSelect(EvaInds, params, subproblems, strategy, CosAngaleMatrix, LastSelect, PFIdx);
    case 'Improvement'
        [SelectedIndexes] = SubproblemSelect(EvaInds, params, subproblems, strategy);
    case 'None'
        SelectedIndexes = [];
    end
    evoproblems = subproblems(SelectedIndexes);

      %% %%%%%%%%%%%%%%%%%%%------------>Initialization for MOEA/D-DE<------------%%%%%%%%%%%%%%%%%%%%%%
    Nsubp=length(subproblems);
    if SuccessPrescreen
        NonInitindex=randperm(Nsubp,ceil(0.01*Nsubp)); 
    else
        NonInitindex=[]; 
    end
%     E = zeros(1, Nsubp);
    counter = evalCounter;
    if strcmp(strategy, 'None')
        for i=1:Nsubp
            if isempty(NonInitindex)||~ismember(i,NonInitindex)
                subproblems(i).curpoint.parameter=lhsdesign(1,mop.pd,'iterations',1)'.*(mop.domain(:,2)-mop.domain(:,1))+mop.domain(:,1);%update the initial solution 
                subproblems(i).curpoint.BaseCluster = [];
            end
            if SuccessPrescreen  
                obj = subobjective(subproblems(i).weight,[EvaInds.objective],params.Dmethod);
                subproblems(i).subpmin=min(obj);%update the current best value
            end
             subproblems(i).curpoint=ModelEvaluate(subproblems(i).curpoint, Model, params, GPstruct);
            switch AFstruct.name
                case 'EI'
                    [Fit, SubpObjs, SubpVars]=SubpExI(subproblems(i).weight,subproblems(i).subpmin,subproblems(i).curpoint.PredObjs,subproblems(i).curpoint.PredVars,params.Dmethod);
                case 'PI'
                    [Fit, SubpObjs, SubpVars]=SubpPI(subproblems(i).weight,subproblems(i).subpmin,subproblems(i).curpoint.PredObjs,subproblems(i).curpoint.PredVars,params.Dmethod);
                case 'LCB'
                    subproblems(i).alpha = AFstruct.kappa;
                    [Fit, SubpObjs, SubpVars]=SubpLCB(subproblems(i).weight, subproblems(i).curpoint.PredObjs,subproblems(i).curpoint.PredVars, subproblems(i).alpha, params.Dmethod);
                case 'ALCB'
                     [Fit, SubpObjs, SubpVars, ~]=ALCB(subproblems(i).weight, subproblems(i).curpoint.PredObjs,subproblems(i).curpoint.PredVars,params.Dmethod, NP_size, subproblems(i).subpmin);
                case 'GPLM'
                    [subproblems(i)] = SubpAlpha(sortInds, params, subproblems(i), idealpoint(:, 2));
                    [Fit, SubpObjs, SubpVars]=GPLM(subproblems(i).weight, subproblems(i).curpoint.PredObjs, subproblems(i).curpoint.PredVars, subproblems(i).alpha, subproblems(i).subpmin, params.Dmethod);
                case 'GP-RBF'
                    SubpObjs = 0; SubpVars = 0;
                    Obj = zeros(params.N_obj, 1);
                    PredObj = subproblems(i).curpoint.PredObjs';
                    PredVar = subproblems(i).curpoint.PredVars';
                    for j = 1 : params.N_obj
                        dmodel = Model.RBF{j};
                        ind = [PredObj(:, j), PredVar(:, j)];
                        y = my_rbfpredict(dmodel.RBF_Model, dmodel.P, ind);
                        Obj(j) = y;
                    end
                    Fit = subobjective(subproblems(i).weight, Obj, params.Dmethod);
    %                 Ind = get_structure('PredInd');
    %                 Ind.parameter = subproblems(i).curpoint.parameter;
    %                 [Ind.objective, ~] = evaluate(mop, Ind);
    %                 real = subobjective(subproblems(i).weight, Ind.objective, params.Dmethod);
    %                 error = abs(real - Fit);
    %                 E(i) = error;
                case 'RBF'
                    Fit = subobjective(subproblems(i).weight, subproblems(i).curpoint.PredObjs, params.Dmethod);
                    SubpObjs = Fit; SubpVars = 0;
                otherwise 
                    error('No such name for Acqusition Function!')
            end
            subproblems(i).prescreenFit=Fit;%update the prescreen fitness
            subproblems(i).SubpObjs=SubpObjs; 
            subproblems(i).SubpVars=SubpVars;
        end
    end
    evalCounter = counter;
    %% %%%%%%%%%%%%%%%%%%%------------>Optimization by MOEA/D-DE<------------%%%%%%%%%%%%%%%%%%%%%%%
    btic = tic;
    fprintf('MOEA/D start \n')
    if strcmp(strategy, 'None')
        [subproblems] = moeadde(mop, params, subproblems, Model, AFstruct, NP_size, GPstruct, strategy);
    else
        [evoproblems]=moeadde(mop, params, evoproblems, Model, AFstruct, NP_size, GPstruct, settingStruct.strategy);
    end
    fprintf('time for MOEA/D is %d \n', toc(btic));
    %% %%%%%%%%%%%%%%%%%%%------------>EHVI Prescreen<------------%%%%%%%%%%%%%%%%%%%%%%%
    fprintf('Prescreen begin \n')
%     [CandInds,cluseridx]=prescreen(params,subproblems,EvaInds);
    if strcmp(strategy, 'None')
        [CandInds, SelectedIndexes] = prescreen_hv(params, subproblems, EvaInds, mop, settingStruct);
    else
        [CandInds, ~] = prescreen_hv(params, evoproblems, EvaInds, mop, settingStruct);
    end
    %% %%%%%%%%%%%%%%%%%%%------------>Evaluation<------------%%%%%%%%%%%%%%%%%%%%%%%
    if isempty(CandInds)
        SuccessPrescreen=false;
        NewEvaInds=EvaInds;
    else
        SuccessPrescreen=true;
        NewEvaInds=[EvaInds,CandInds];
    end
    for i=1:length(CandInds)
        obj=subobjective([subproblems.weight],CandInds(i).objective,params.Dmethod);
        LogiIdx=[subproblems.subpmin]>obj;
        temp=num2cell(obj(LogiIdx));
        [subproblems(LogiIdx).subpmin]=temp{:};
    end
end

% should be updated at most by this new individual.
function y=terminate(params)
    global evalCounter;
    y = evalCounter>=params.evaluation;
end

function updateplot(gen,evalC,ExistingEvaInds, Pos, PFtrue, mop)
    df      = [ExistingEvaInds.objective];
    df = df';
    ds      = [ExistingEvaInds.parameter];
    ds = ds';
    str     = sprintf('gen=%d evalC=%d AF=%s', gen,evalC, Pos);

    hold off; 
    subplot(1,2,1);
    if size(df,2) == 2
        plot(PFtrue(1, :), PFtrue(2, :), 'o', 'MarkerSize',4);
        hold on
        plot(df(:,1), df(:,2), 'ro', 'MarkerSize',4);
        xlabel('f1', 'FontSize', 6);
        ylabel('f2', 'FontSize', 6);
        grid on;
    else
        plot3(df(:,1), df(:,2), df(:,3), 'ro', 'MarkerSize',4);
        xlabel('f1', 'FontSize', 6);
        ylabel('f2', 'FontSize', 6);
        zlabel('f3', 'FontSize', 6);
        grid on;
    end
    title(str, 'FontSize', 8);
    box on;
    drawnow;

    subplot(1,2,2);
    if size(ds,2) >= 3
        plot3(ds(:,1), ds(:,2), ds(:,3), 'ro', 'MarkerSize',4);
        xlabel('x1', 'FontSize', 6);
        ylabel('x2', 'FontSize', 6);
        zlabel('x3', 'FontSize', 6);  
        grid on;
    elseif size(ds,2) >= 2
        plot(ds(:,1), ds(:,2), 'ro', 'MarkerSize',4);
        xlabel('x1', 'FontSize', 6);
        ylabel('x2', 'FontSize', 6);
        grid on;
    end
    box on;
    drawnow;
    filename = Pos + "_res_pic/" + mop.name + "/iter" + gen + ".png";
    saveas(gcf, filename);
    clear df ds;
end
