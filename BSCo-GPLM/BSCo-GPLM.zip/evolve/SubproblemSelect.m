function varargout = SubproblemSelect(EvaInds, params, subproblems, strategy, varargin)
    switch strategy
    case 'ASS'
        global idealpoint
        NewEvaInds = EvaInds((end - params.Ke + 1) : end);
        OldEvaInds = EvaInds(1 : (end - params.Ke));
        if max(idealpoint(:, 1)-idealpoint(:, 2))>1e-5
            UpdateAll=true;
        else
            UpdateAll=false;
        end
        CosAngleMatrix = varargin{1};
        LastSelect = varargin{2};
        Archive = varargin{3};
        [CosAngleMatrix, subproblems] = updateAngleSubps(CosAngleMatrix, subproblems, idealpoint(:, 2), UpdateAll, OldEvaInds, NewEvaInds, LastSelect);
        [~,CloseDirs]=max(CosAngleMatrix,[],2);
        ActDirs=unique(CloseDirs');
        if length(subproblems)-length(ActDirs)>params.Ke
            RemainIdxes=setdiff(1:length(subproblems),ActDirs);
            ActDirs=[ActDirs,RemainIdxes(randperm(length(RemainIdxes),params.Ke))];
        end
        % also can use 0.1*length(ActDirs) or 2*N_task instead of N_task
        Act_CosAngleMatrix=CosAngleMatrix(Archive,ActDirs);
        evalTimes=[subproblems(ActDirs).evalTimes];
    %     evalTimes = 0;
        [Npoints,Ndirs]=size(Act_CosAngleMatrix);
        AverageRanks=zeros(Npoints,Ndirs);
        for i=1:Npoints
            [~,FarthestIdx]=sort(Act_CosAngleMatrix(i,:));
            AverageRanks(i,FarthestIdx)=(1:Ndirs)/Ndirs;
        end
        Fits=sum(AverageRanks.^100)+1.0*evalTimes;
        SelectDirIdx=zeros(1,params.Ke);
        cutvalue=1;
        Divers_Idxes=find(Fits<cutvalue);
        while length(Divers_Idxes)<params.Ke
            cutvalue=cutvalue*1.2;
            Divers_Idxes=find(Fits<cutvalue);
        end
        cluseridx=kmeans([subproblems(ActDirs(Divers_Idxes)).direction]',params.Ke);
        for i=1:params.Ke
            idxes=Divers_Idxes(cluseridx==i);
            [~,DirIxs]=min(Fits(idxes));
            SelectDirIdx(i)=ActDirs(idxes(DirIxs));   
        end
        varargout{1} =SelectDirIdx;
        varargout{2} = CosAngleMatrix;

    case 'Improvement'
        Nsubp = length(subproblems);
        weights = [subproblems.weight];
        subpIdx = linspace(1, Nsubp, Nsubp);
        idx = kmeans(weights', params.Ke);
        cluseridx = idx';
        SelectNu = params.Ke;
        Initialobj = [subproblems.subpmin]; newobj = Initialobj;

        for i = 1 : length(EvaInds)
            temp = subobjective([subproblems.weight], EvaInds(i).objective, params.Dmethod);
            newobj = min(temp, newobj);
        end
        improve = (Initialobj - newobj) ./ Initialobj;
        selectSubp = zeros(1, SelectNu);
        for i = 1 : SelectNu
            candidxes = subpIdx(cluseridx == i);
            screenFit = improve(candidxes);
            [~, selectIndex] = max(screenFit);
            selectSubp(i) = candidxes(selectIndex);
        end
        varargout{1} = selectSubp;
    end
end

