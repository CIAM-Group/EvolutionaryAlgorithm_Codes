function hyp_opt = hypOpt(hyp,GPfunc,numOptFC,inffunc,meanfunc,covfunc,likfunc,x_train,y_train)
% For GP hyperparameter optimization
% Inputs:
%         hyp: a structure containing initial hyperparameters
%             .mean: the mean paras
%             .cov: the covariance paras
%             .lik: the noise variance paras
%         GPfunc: the GP model to infer and predict
%         numOptFC: number of function evaluations in optimization
%         inffunc: inference method specified for GP
%         meanfunc: mean function specified for GP
%         covfunc: covariance function specified for GP, usually has the form KfKc where Kf is the task similarity matrix,
%                  and Kc is the typical convariance matrix.
%                  the hyperparameters thus come from the parameters in Kf and parameters in Kc
%         likfunc: likelihood function specified for GP
%         x_train: n by D matrix of training inputs
%         y_train: column vector of length n of training targets
% Outputs:
%         hyp_opt: a structure containing optimal hyperparameters
%
% By Haitao Liu
% 2017/03/04
%
% Test results show that fmincon and GA cannot provide better results than the widely used gradient descent method

solver = 'fmincon' ;

n_cov = length(hyp.cov) ; % number of covaraince paras
n_lik = length(hyp.lik) ; % number of noise paras
x0 = [hyp.cov,hyp.lik'] ; % combine cov and lik to form a design point
dim = length(x0) ;        % dimensonality of optimization problem, being equivalent to n_cov+n_lik

%lb = zeros(1,dim) - Inf ;
%ub = zeros(1,dim) + Inf ;
%lb(n_cov) = 0 ; ub(n_cov) = 1 ;

% for 1D example
%lb = [0.1, log(0.01), log(sqrt(0.01)) log(0.01), log(sqrt(0.01)), log(sqrt(1e-10)), log(sqrt(1e-10))] ;
%ub = [2.0, log(0.50), log(sqrt(0.50)) log(0.50), log(sqrt(0.50)), log(sqrt(1e-9)), log(sqrt(1e-9))] ;

OBJ = @(x)calNLML(x,n_cov,n_lik,GPfunc,inffunc,meanfunc,covfunc,likfunc,x_train,y_train) ;

switch solver
    case 'GradientDescent'
        %
    case 'fmincon'
        %options = optimset('Algorithm','interior-point','Display','off','gradobj','on','MaxIter', numOptFC) ;
        %[x_opt,nlml_opt] = fmincon(OBJ,x0,[],[],[],[],[],[],[],options) ;

        options = optimoptions('fminunc','Display','off','MaxFunctionEvaluations',numOptFC) ;
        [x_opt,nlml_opt] = fminunc(OBJ,x0,options);
    case 'GA'
        gaoptions = gaoptimset('Generations',500,'PopulationSize',100) ; 
        [x_opt,nlml_opt] = ga(OBJ,dim,[],[],[],[],lb,ub,[],gaoptions);
    case 'MC'
        n_cand = 10000 ;
        candidates = lhsdesign(n_cand,dim) ;
        candidates = candidates.*repmat((ub-lb),n_cand,1) + repmat(lb,n_cand,1) ;
        nlmls = zeros(n_cand,1) ;
        for i = 1:n_cand
            nlmls(i) = calNLML(candidates(i,:),n_cov,n_lik,GPfunc,inffunc,meanfunc,covfunc,likfunc,x_train,y_train) ;
        end
        [u,v] = find(nlmls == min(nlmls)) ;
        x_opt = candidates(u(1),:) ;
end

hyp_opt.cov = x_opt(1:n_cov) ;
hyp_opt.lik = x_opt(end-n_lik+1:end)' ;

end % end function

%###############
%function [nlml,grad_info] = calNLML(x,n_cov,n_lik,GPfunc,inffunc,meanfunc,covfunc,likfunc,x_train,y_train)
function nlml = calNLML(x,n_cov,n_lik,GPfunc,inffunc,meanfunc,covfunc,likfunc,x_train,y_train)
% objective function returns objective value and gradient information

hyp.cov = x(1:n_cov) ;
hyp.lik = x(end-n_lik+1:end)' ;
[nlml,dnlZ] = feval(GPfunc,hyp,inffunc,meanfunc,covfunc,likfunc,x_train,y_train);
%grad_info = [dnlZ.cov,dnlZ.lik']' ;

end