function K = MTGP_covSEard_CONV(hyp, x, z, i)
% Process covolution to create valid covariance functions (only *cross-covariance*)
% see, A. Melkumyan and F. Ramos, “Multi-kernel Gaussian processes,” in Proc. Int. Joint Conf. Artif. Intell., Barcelona, Spain, 2011, pp. 1408–1413
% The cross-covariance function between task i and task j is expressed as
%
% K(x_i,x'_j) = \int g_i(x_i - u)g_j(x'_j - u) du
%
% where g_i and g_j are the smoothing kernels.
% Squared Exponential covariance function with Automatic Relevance Detemination (ARD) distance measure. The covariance function is parameterized as:
%
% k(x^p,x^q) = sf2 * exp(-(x^p - x^q)'*inv(P)*(x^p - x^q)/2)
%
% where the P matrix is diagonal with ARD parameters ell_1^2,...,ell_D^2, where
% D is the dimension of the input space and sf2 is the signal variance. 
% Then, the cross covariance terms using Squared Exponential \times Squared Exponential can be expressed as
%
% K_{SE1 \times SE2}(x,x';P1,sf2_1,P2;sf2_2) = sf2_1*sf2_2 * 2^(dim/2) * [|P1|^0.25*|P2|^0.25] / [|P1+P2|^0.5]
%                                            * exp[-(x-x')'*inv(P1+P2)*(x-x')] 
%
% The hyperparameters for the cross covariance structure are:
%
% hyp = [ log(ell1_1)
%         log(ell1_2)
%          .
%         log(ell1_D)
%         log(sqrt(sf2_1))
%         log(ell2_1)
%         log(ell2_2)
%          .
%         log(ell2_D)
%         log(sqrt(sf2_2)) ]
%
% Copyright (c) by Carl Edward Rasmussen and Hannes Nickisch, 2010-09-10.
%
% See also COVFUNCTIONS.M.
%
% Modified by Haitao Liu 2017/06/21
% Here, x = [x, l] \in R^{n*(D+1)} where l is the task indicator

if nargin<2, K = '(2*D+2)'; return; end            % report number of parameters
if nargin<3, z = []; end                                   % make sure, z exists
xeqz = numel(z)==0; dg = strcmp(z,'diag') && numel(z)>0;        % determine mode

[n,D] = size(x(:,1:end-1));                                     % dimensionality
ell_SE1 = exp(hyp(1:D));
ell_SE2 = exp(hyp(D+1:2*D));                               % characteristic length scale
sf2_SE1 = exp(2*hyp(2*D+1));                                         % signal variance
sf2_SE2 = exp(2*hyp(2*D+2));

% precompute squared distances
P = ell_SE1.^2+ell_SE2.^2 ;
if dg                                                               % vector kxx
  K = zeros(size(x(:,1:end-1),1),1);
else
  if xeqz                                                 % symmetric matrix Kxx
    K = sq_dist(diag(1./sqrt(P))*x(:,1:end-1)');
  else                                                   % cross covariances Kxz
    K = sq_dist(diag(1./sqrt(P))*x(:,1:end-1)',diag(1./sqrt(P))*z(:,1:end-1)');
  end
end

term1 = 2^(D/2)*(prod(ell_SE1)*prod(ell_SE2))^0.5 ;
term2 = (prod(P))^0.5 ;
%K = sf2_SE1*sf2_SE2*term1/term2*exp(-K);                                                  % covariance
K = (sf2_SE1*sf2_SE2)^0.5*term1/term2*exp(-K); 
if nargin>3                                                        % derivatives
  if i<=D                                              % length scale parameters of SE1
    if dg
      K = 0.5*K + (-ell_SE1(i)^2/(ell_SE1(i)^2 + ell_SE2(i)^2))*K;
    else
      P = ell_SE1.^2+ell_SE2.^2 ;
      %P(i) = -0.5*P(i)^2/ell_SE1(i)^2 ;
      P(i) = 0.5*P(i)^2/ell_SE1(i)^2 ;
      if xeqz
        K = 0.5*K + (-ell_SE1(i)^2/(ell_SE1(i)^2 + ell_SE2(i)^2))*K + K.*sq_dist(x(:,i)'/sqrt(P(i)));
      else
        K = 0.5*K + (-ell_SE1(i)^2/(ell_SE1(i)^2 + ell_SE2(i)^2))*K + K.*sq_dist(x(:,i)'/sqrt(P(i)),z(:,i)'/sqrt(P(i)));
      end
    end
  elseif i>D && i<=2*D                                % length scale parameters of SE2
    if dg
      K = 0.5*K + (-ell_SE2(i-D)^2/(ell_SE1(i-D)^2 + ell_SE2(i-D)^2))*K;
    else
      P = ell_SE1.^2+ell_SE2.^2 ;
      %P(i-D) = -0.5*P(i-D)^2/ell_SE2(i-D)^2 ;
      P(i-D) = 0.5*P(i-D)^2/ell_SE2(i-D)^2 ;
      if xeqz
        K = 0.5*K + (-ell_SE2(i-D)^2/(ell_SE1(i-D)^2 + ell_SE2(i-D)^2))*K + K.*sq_dist(x(:,i-D)'/sqrt(P(i-D)));
      else
        K = 0.5*K + (-ell_SE2(i-D)^2/(ell_SE1(i-D)^2 + ell_SE2(i-D)^2))*K + K.*sq_dist(x(:,i-D)'/sqrt(P(i-D)),z(:,i-D)'/sqrt(P(i-D)));
      end
    end
  elseif i==2*D+1                                            % magnitude parameter
    K = K ;
  elseif i==2*D+2                                            % magnitude parameter
    K = K ;
  else
    error('Unknown hyperparameter')
  end
end