function [CosAngleMatrix,subproblems]=updateAngleSubps(CosAngleMatrix,subproblems,idealpoint,UpdateAll,EvaInds,NewEvaInds,EvalSubps)
    directions=[subproblems.direction]; Ndirections=size(directions,2); DirectLength=[subproblems.directlength];
    if UpdateAll
        [subproblems.subpmin]=deal(Inf);
        [subproblems.evalTimes]=deal(0);
        ReEvalInds=[EvaInds,NewEvaInds];
        Npoints=length(ReEvalInds);NewCosAngleMatrix=zeros(Npoints,Ndirections);
        for i=1:Npoints
            TransObj=ReEvalInds(i).objective-idealpoint;
            ModObj=sqrt(sum(TransObj.^2));
            NewCosAngleMatrix(i,:)=(TransObj'*directions)./(DirectLength*ModObj);
        end
        CosAngleMatrix=NewCosAngleMatrix;    
    else
        for i=1:length(EvalSubps)
            SubpIndex=EvalSubps(i);
            subproblems(SubpIndex).evalTimes=subproblems(SubpIndex).evalTimes+1;
        end    
        OldCosAngleMatrix=CosAngleMatrix;
        ReEvalInds=NewEvaInds;
        Npoints=length(ReEvalInds);NewCosAngleMatrix=zeros(Npoints,Ndirections);
        for i=1:Npoints
            TransObj=ReEvalInds(i).objective-idealpoint;
            ModObj=sqrt(sum(TransObj.^2));
            NewCosAngleMatrix(i,:)=(TransObj'*directions)./(DirectLength*ModObj);
        end
        CosAngleMatrix=[OldCosAngleMatrix;NewCosAngleMatrix];
    end
end

