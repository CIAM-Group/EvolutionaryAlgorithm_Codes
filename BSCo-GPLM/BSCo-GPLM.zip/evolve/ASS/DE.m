%------------------------------------------------------------------------
% This code is part of the program that produces the results in the following paper:
% Huixiang Zhen, Wenyin Gong, Ling Wang, Fei Ming, and Zuowen Liao. "Two-stage Data-driven Evolutionary Optimization for High-dimensional Expensive Problems", IEEE Transactions on Cybernetics, accepted, 2021.
% You are free to use it for non-commercial purposes. However, we do not offer any forms of guanrantee or warranty associated with the code. We would appreciate your acknowledgement.
%----------------------------------------------------------------------------------------------------------------------------------------

function [bestP,bestFitness, bestObj, bestVar] = DE(Dim, Max_NFEs,minerror,lu, model, params, subproblem)
    time_begin=tic;
    n = Dim; NP = 50; flag_er=0;
    % lu = [min(ghx); max(ghx)];
    LowerBound = lu(1, :);
    UpperBound = lu(2, :);
    
    % DE Parameters
    G=1;
    F=0.5; 
    CR=0.9;
    UB=UpperBound;
    LB=LowerBound;
    
    UB=repmat((UB),NP,1);
    LB=repmat((LB),NP,1);
    
    P=(UB-LB).*rand(NP,Dim)+LB;
    % for i = 1 : params.N_obj
    %     dmodel = model{i};
    %     dfitness=my_rbfpredict(dmodel.RBF_Model, dmodel.P, P);
    %     obj(i, :) = dfitness;
    % end
    % fitnessP = subobjective(weight, obj, params.Dmethod);
%     fitnessP = my_rbfpredict(model.RBF_Model, model.P, P);
%     [u, s] = kriging_predictor(P, model, ghx, ghy, mop.domain(:, 1)', mop.domain(:, 2)');
%     fitnessP = -(subpmin - u) .* normcdf((subpmin - u) ./ sqrt(s)) - s .* normpdf((subpmin - u) ./ sqrt(s));
    [u, s] = predict_tasks(P, model);
    PredObj =cell2mat(u); PredVar = cell2mat(s);
    PredObj = PredObj'; PredVar = PredVar';
    fitnessP = LCB_LS(subproblem.weight, PredObj, PredVar, subproblem.alpha, subproblem.subpmin, params.Dmethod);

    NFEs=1;
    [fitnessBestP,indexBestP]=min(fitnessP);
    bestP=P(indexBestP,:);
    recRMSE(1:NP)=fitnessP;
    trace = [];
    while NFEs<Max_NFEs
        
        fitnessBestP_old = fitnessBestP;
        trace = [trace, fitnessBestP];
        for i=1:NP  
            k0=randi([1,NP]);
            while(k0==i)
                k0=randi([1,NP]);   
            end
            P1=P(k0,:);
            k1=randi([1,NP]);
            while(k1==i||k1==k0)
                k1=randi([1,NP]);
            end
            P2=P(k1,:);
            k2=randi([1,NP]);
            while(k2==i||k2==k1||k2==k0)
                k2=randi([1,NP]);
            end
            P3=P(k2,:);
            
            V(i,:)=P1+F.*(P2-P3);   
            
            for j=1:Dim
              if (V(i,j)>UB(i,j)||V(i,j)<LB(i,j))
                 V(i,j)=LB(i,j)+rand*(UB(i,j)-LB(i,j));         
              end
            end
            
            jrand=randi([1,Dim]); 
            for j=1:Dim
                k3=rand;
                if(k3<=CR||j==jrand)
                    U(i,j)=V(i,j);
                else
                    U(i,j)=P(i,j);
                end
            end
        end
        
%         time_begin=tic;
        % Uobj = zeros(params.N_obj, NP);
        % for i = 1 : params.N_obj
        %     dmodel = model{i};
        %     dfitness=my_rbfpredict(dmodel.RBF_Model, dmodel.P, U);
        %     Uobj(i, :) = dfitness;
        % end
        % fitnessU = subobjective(weight, Uobj, params.Dmethod);
%         fitnessU=my_rbfpredict(model.RBF_Model, model.P, U);
%         [u, s] = kriging_predictor(U, model, ghx, ghy, mop.domain(:, 1)', mop.domain(:, 2)');
%         fitnessU = -(subpmin - u) .* normcdf((subpmin - u) ./ sqrt(s)) - s .* normpdf((subpmin - u) ./ sqrt(s));
        [u, s] = predict_tasks(U, model);
        PredObj =cell2mat(u); PredVar = cell2mat(s);
        PredObj = PredObj'; PredVar = PredVar';
        [fitnessU, SubpObj, SubpVar] = LCB_LS(subproblem.weight, PredObj, PredVar, subproblem.alpha, subproblem.subpmin, params.Dmethod);
        NFEs=NFEs+1;
        
        for i=1:NP 
            if(fitnessU(i)<fitnessP(i))
                P(i,:)=U(i,:);
                fitnessP(i)=fitnessU(i);
                if(fitnessU(i)<fitnessBestP)
                   fitnessBestP=fitnessU(i);
                   bestP=U(i,:);
                   bestObj = SubpObj(i);
                   bestVar = SubpVar(i);
                end
            end
            recRMSE(NFEs)=fitnessP(i);
        end
        error=abs(fitnessBestP_old-fitnessBestP); 
        if error <= minerror   
            flag_er=flag_er+1;
        else
            flag_er=0;
        end
        G=G+1;
    end
    bestFitness=fitnessBestP;
    endNFEs = NFEs;
    time_cost=toc(time_begin);
end