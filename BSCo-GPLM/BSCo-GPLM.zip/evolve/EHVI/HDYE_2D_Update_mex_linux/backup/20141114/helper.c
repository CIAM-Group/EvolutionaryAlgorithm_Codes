#include "helper.h"
#include "ehvi_consts.h"
#include <math.h>


