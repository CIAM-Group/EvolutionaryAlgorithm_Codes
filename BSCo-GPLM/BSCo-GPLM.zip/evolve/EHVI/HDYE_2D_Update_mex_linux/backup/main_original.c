//Command-line application for calculating the 3-Dimensional
//Expected Hypervolume Improvement.
//By Iris Hupkens, 2013
#include <deque>
#include <iostream>
#include <fstream>
#include <iomanip>
#include "ehvi_calculations.h"
#include "ehvi_sliceupdate.h"
#include "ehvi_montecarlo.h"
#include "string.h"
#include "ehvi_multi.h"
#include <vector>
#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
// #include "mex.h"

using namespace std;


 unsigned int
timeDif(
    struct timeval *before,
    struct timeval *after)
{
    return ((after->tv_sec * 1000000 + after->tv_usec) - 
        (before->tv_sec * 1000000 + before->tv_usec));
}


//Performs the EHVI calculations using the scheme requested by the user.
void doscheme(char *schemename, deque<individual*> & testcase, double r[], vector<mus*> & pdf){
  double answer;
  vector<double> answervector;
  if (pdf.size() == 1)
    if (strcmp(schemename,"sliceupdate") == 0){
      cerr << "Calculating with slice-update scheme..." << endl;
      answer = ehvi3d_sliceupdate(testcase, r, pdf[0]->mu, pdf[0]->s);
      cout << answer << endl;
    } else if (strcmp(schemename,"2term") == 0){
      cerr << "Calculating with 2-term scheme..." << endl;
      answer = ehvi3d_2term(testcase, r, pdf[0]->mu, pdf[0]->s);
      cout << answer << endl;
    } else if (strcmp(schemename,"5term") == 0){
      cerr << "Calculating with 5-term scheme..." << endl;
      answer = ehvi3d_5term(testcase, r, pdf[0]->mu, pdf[0]->s);
      cout << answer << endl;
    } else if (strcmp(schemename,"8term") == 0){
      cerr << "Calculating with 8-term scheme..." << endl;
      answer = ehvi3d_8term(testcase, r, pdf[0]->mu, pdf[0]->s);
      cout << answer << endl;
    } else if (strcmp(schemename,"montecarlo") == 0){
      cerr << "Calculating with Monte Carlo scheme (" << MONTECARLOS << " iterations)..." << endl;
      answer = ehvi3d_montecarlo(testcase, r, pdf[0]->mu, pdf[0]->s);
      cout << answer << endl;
    } else {
        cerr << "Scheme " << schemename << " does not exist. Proper options are:" << endl
             << "2term" << endl
             << "5term" << endl
             << "8term" << endl
             << "sliceupdate" << endl
             << "montecarlo" << endl;
    }
  else {
    if (strcmp(schemename,"sliceupdate") == 0){
      cerr << "Calculating with slice-update scheme (multi-version)..." << endl;
      answervector = ehvi3d_sliceupdate(testcase, r, pdf);
      for (int i=0;i<answervector.size();i++)
        cout << answervector[i] << endl;
    } else if (strcmp(schemename,"5term") == 0){
      cerr << "Calculating with 5-term scheme (multi-version)..." << endl;
      answervector = ehvi3d_5term(testcase, r, pdf);
      for (int i=0;i<answervector.size();i++)
        cout << answervector[i] << endl;
    } else {
        cerr << "Scheme " << schemename << " does not exist." << endl
             << "Multi-versions have only been implemented for the 5-term and slice-update schemes!" << endl;
    }
  }
}

//Checks if p dominates P. Removes points dominated by p from P and return the number of points removed.
int checkdominance(deque<individual*> & P, individual* p){
  int nr = 0;
  for (int i=P.size()-1;i>=0;i--){
    if (p->f[0] >= P[i]->f[0] && p->f[1] >= P[i]->f[1] && p->f[2] >= P[i]->f[2]){
      cerr << "Individual " << (i+1) << " is dominated or the same as another point; removing." << endl;
      P.erase(P.begin()+i);
      nr++;
    }
  }
  return nr;
}

//Loads a testcase from the file with the name filename.
void loadtestcase(char *filename, deque<individual*> & testcase, double r[], vector<mus*> & pdf){
  ifstream file;
  int n, inds = 0;
  file.open(filename, ios::in);
  file >> n;
  for (int i=0;i<n;i++){
    individual * tempvidual = new individual;
    file >> tempvidual->f[0] >> tempvidual->f[1] >> tempvidual->f[2];
	/* 
    tempvidual->f[0] = tempvidual->f[0];
    tempvidual->f[1] = tempvidual->f[1];
    tempvidual->f[2] = tempvidual->f[2]; */
	
    checkdominance(testcase,tempvidual);
    testcase.push_back(tempvidual);
  }
  file >> r[0] >> r[1] >> r[2];
  
  while (!file.eof()){
    if (inds > 0)
      pdf.push_back(new mus);
    file >> pdf[inds]->mu[0] >> pdf[inds]->mu[1] >> pdf[inds]->mu[2];
    file >> pdf[inds]->s[0] >> pdf[inds]->s[1] >> pdf[inds]->s[2];
	cout << pdf[inds]->mu[0] << " " << pdf[inds]->mu[1] << " " << pdf[inds]->mu[2] << " " << pdf[inds]->s[0] << " " << pdf[inds]->s[1] << " " << pdf[inds]->s[2] << endl;
    if (file.fail()){
      //We discover this while trying to read an individual and will end it here.
      pdf.pop_back();
      file.close();
      return;
    }
    inds++;
  }
  file.close();
}

int loadtestcase_interface(int n,  double** data0, int m, double** data2, double* data1, deque<individual*> & testcase, double r[], vector<mus*> & pdf){
   int inds = 0;
  
   struct timeval before, after;
 
  for (int i=0;i<n;i++){
    individual * tempvidual = new individual;
    tempvidual->f[0] = *(*(data0 + i));
	tempvidual->f[1] = *(*(data0 + i) + 1);
	tempvidual->f[2] = *(*(data0 + i) + 2);
    checkdominance(testcase,tempvidual);
    testcase.push_back(tempvidual);
  }
  //file >> r[0] >> r[1] >> r[2];
  r[0] = *(data1);
  r[1] = *(data1 + 1);
  r[2] = *(data1 + 2);
  for (int i=0; i<m; i++){
    if (inds > 0)
		pdf.push_back(new mus);
	pdf[inds]->mu[0] = *(*(data2 + i));
	pdf[inds]->mu[1] = *(*(data2 + i) + 1);
	pdf[inds]->mu[2] = *(*(data2 + i) + 2);
	pdf[inds]->s[0] = *(*(data2 + i) + 3);
	pdf[inds]->s[1] = *(*(data2 + i) + 4);
	pdf[inds]->s[2] = *(*(data2 + i) + 5);
	//cout << pdf[inds]->mu[0] << " " << pdf[inds]->mu[1] << " " << pdf[inds]->mu[2] << " " << pdf[inds]->s[0] << " " << pdf[inds]->s[1] << " " << pdf[inds]->s[2] << endl;
   /*  if (file.fail()){
      //We discover this while trying to read an individual and will end it here.
      pdf.pop_back();
      file.close();
      return;
    } */
    inds++;
  }
  
   // gettimeofday(&before, NULL); 
	vector<double> answer = ehvi3d_sliceupdate(testcase, r, pdf);
    for (int i=0;i<answer.size();i++)
    cout << answer[i] << endl; 

	/* gettimeofday(&after, NULL);
	ofstream test("Time_IRS_update.txt", ios::app);
	test<<(timeDif(&before, &after))<<endl;  */
	
	return 0 ;
}

int main(int argc, char *argv[]){
  
  struct timeval before, after;
  vector<double> answer;
  
  
  int n, m;
  deque<individual*> testcase;
  double r[DIMENSIONS];
  double mu[DIMENSIONS];
  double s[DIMENSIONS];
  double** data0, **data2;
  double* data1;
  vector<mus*> pdf;
  mus * tempmus = new mus;
  pdf.push_back(tempmus);
  cout << setprecision(10);
  
  
 
 if (argc > 1){
    
	ifstream file;
	file.open(argv[1], ios::in);
  file >> n;
  file >> m;
  // data0: the existing points n*3
  // data1: reference points    1*3
  // data2: the evaluated points/added points m*6
  data0 = (double**)malloc(n*sizeof(double*));
  data1 = (double*)malloc(3*sizeof(double));
  data2 = (double**)malloc(m*sizeof(double*));
  for(int i=0;i<n;i++){
	*(data0+i) = (double*)malloc(3*sizeof(double));
	file >> *(*(data0+i)) >> *(*(data0+i)+1) >> *(*(data0+i)+2);
  }
  file >> *(data1 + 0) >> *(data1 + 1) >> *(data1 + 2);
  
  for(int i=0;i<m;i++){
	*(data2+i) = (double*)malloc(6*sizeof(double));
	file >> *(*(data2+i)) >> *(*(data2+i)+1) >> *(*(data2+i)+2) >>  *(*(data2+i)+3) >>  *(*(data2+i)+4) >>  *(*(data2+i)+5);
  }
  
  
  for (int i=0;i<m;i++){
	for (int j=0;j<6;j++){
		*(*(data2+i)+j) = j+i*6;
		cout << *(*(data2+i)+j) <<endl;
		
		//cout <<*(*(data2+i)) << " " <<*(*(data2+i)+1) << " " <<  *(*(data2+i)+2) << " " <<  *(*(data2+i)+3) << " " <<  *(*(data2+i)+4) << " " <<  *(*(data2+i)+5)<< endl;
	}
  }
  
  

  
/*   for(int i=0;i<n;i++){
	cout << *( *(data0 + i) + 0) << *( *(data0 + i) + 1) << *( *(data0 + i) + 2) << endl;
  }
  cout << *(data1 + 0) << *(data1 + 1) << *(data1 + 2) << endl;
  
  for(int i=0;i<m;i++){
	cout <<*(*(data2+i)) << " " <<*(*(data2+i)+1) << " " <<  *(*(data2+i)+2) << " " <<  *(*(data2+i)+3) << " " <<  *(*(data2+i)+4) << " " <<  *(*(data2+i)+5)<< endl;
  }   */

  
  

  
  
  
//	loadtestcase_interface(n, data0, m, data2, data1,  testcase,r,pdf);
//  cerr << "Loading testcase from file..." << endl;
    //loadtestcase(argv[1],testcase,r,pdf);
	
	/* cout << "Dimension is " << DIMENSIONS <<endl;
	cout << "------------------" << endl;
	cout << "Reference points are" << endl;
	cout << r[0] << endl;
	cout << r[1] << endl;
	cout << r[2] << endl;
	
	
	cout << "------------------" << endl;
	cout << "The size/number of evaluated point(s):  " << pdf.size() << endl; */
	
	//cout << *testcase[1] << endl;
	
	
	
	
	
	
	

	
	
	
	
	
	
	
//	cout << r;
//	cout << pdf;
	
	
	

	//gettimeofday(&before, NULL); 
	//vector<double> answer = ehvi3d_sliceupdate(testcase, r, pdf);
    /* for (int i=0;i<answer.size();i++)
    cout << answer[i] << endl; */

	/* gettimeofday(&after, NULL);
	ofstream test("Time_IRS_update.txt", ios::app);
	test<<(timeDif(&before, &after))<<endl;
	for (int i=0;i<answer.size();i++)
    cout << answer[i] << endl;
	
    return 0; */ 
  }
  else {
  /*
    cerr << "Welcome to the EHVI calculator. Please create a testcase to try out " << endl
         << " the available calculation schemes." << endl;
    cerr << "(Alternative usage: \"" << argv[0] << " FILENAME [schemes] \"" << endl;
    cerr << "How many individuals?" << endl;
    cin >> n;
    cerr << "Enter their x, y and z coordinates. They will be tested for mutual non-dominance." << endl;
    for (int i = 1;i <= n;i++){
      individual* tempvidual = new individual;
      cerr << "Individual " << i << " of " << n << ": ";
      cin >> tempvidual->f[0] >> tempvidual->f[1] >> tempvidual->f[2];
      i = i - checkdominance(testcase,tempvidual);
      testcase.push_back(tempvidual);
    }
    cerr << "Enter the x, y and z coordinate of the reference point. It should be dominated" << endl;
    cerr << "by all individuals in the population." << endl;
    cin >> r[0] >> r[1] >> r[2];
    cerr << "Enter the mean vector." << endl;
    cin >> mu[0] >> mu[1] >> mu[2];
    cerr << "Enter the standard deviation vector." << endl;
    cin >> s[0] >> s[1] >> s[2];
*/
  
  }
  
	
/*
  cerr << "Running your test, please wait..." << endl;
  double answer;
  cerr << "Performing Monte Carlo simulation (" << MONTECARLOS << " iterations)..." << endl;
  answer = ehvi3d_montecarlo(testcase, r, mu, s);
  cout << answer << endl;
  cerr << "Calculating with 8-term scheme.." << endl;
  answer = ehvi3d_8term(testcase, r, mu, s);
  cout << answer << endl;
  cerr << "Calculating with 5-term scheme.." << endl;
  answer = ehvi3d_5term(testcase, r, mu, s);
  cout << answer << endl;
  cerr << "Calculating with 2-term scheme.." << endl;
  answer = ehvi3d_2term(testcase, r, mu, s);
  cout << answer << endl;
  cerr << "Calculating with slice update scheme..." << endl;
  answer = ehvi3d_sliceupdate(testcase, r, mu, s);
  cout << answer << endl;
*/ 
	
	
	
  return 0;
}
