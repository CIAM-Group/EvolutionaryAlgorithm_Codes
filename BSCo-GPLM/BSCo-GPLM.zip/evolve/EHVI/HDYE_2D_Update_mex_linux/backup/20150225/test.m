clear all;
clc;
% mex *.c
load('type=2_data_p=100_eval=1000.mat');
% points_added_PF(:,3) = [];
% points_added_PF(:,5) = [];
% points_exist_PF(:,3)  =[];
% ref(:,3) = [];

points_added_PF(:,1:3) = -points_added_PF(:,1:3) ;
points_exist_PF = -points_exist_PF;
ref = -ref; 

% [a,b,c] = ehvi_calculations(points_exist_PF,ref,points_added_PF)
tic;
A=ehvi_calculations(points_exist_PF,ref,points_added_PF);
toc;
A=A';

% ehvi_calculations(points_exist_PF,ref,points_added_PF);
