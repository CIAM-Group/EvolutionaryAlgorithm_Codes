function  [y,mse] = predictor0(x, dmodel)
%PREDICTOR  Predictor for y(x) using the given DACE model.
%
% Call:   [y,mse] = predictor(x, dmodel)
%
% Input
% x      : trial design sites with n dimensions.  
%          For mx trial sites x:
%          If mx = 1, then both a row and a column vector is accepted,
%          otherwise, x must be an mx*n matrix with the sites stored
%          rowwise.
% dmodel : Struct with DACE model; see DACEFIT
%
% Output
% y    : predicted response at x.
% mse  : Estimated mean squared error of the predictor;
  if  isnan(dmodel.beta)
    y = NaN;   
    error('DMODEL has not been found')
  end
  [m, n] = size(dmodel.S);  % number of design sites and number of dimensions
  sx = size(x);            % number of trial sites and their dimension
  if  min(sx) == 1 && n > 1 % Single trial point 
    nx = max(sx);
    if  nx == n 
      mx = 1;  x = x(:).';
    end
  else
    mx = sx(1);  nx = sx(2);
  end
  if  nx ~= n
    error('Dimension of trial sites should be %d',n)
  end
  
  % Normalize trial sites  
  x = (x - repmat(dmodel.Ssc(1,:),mx,1)) ./ repmat(dmodel.Ssc(2,:),mx,1);
  q = size(dmodel.Ysc,2);  % number of response functions
  y = zeros(mx,q);         % initialize result
  mu = (10+m)*eps;  
  if  mx == 1  % one site only
        dx = repmat(x,m,1) - dmodel.S;  % distances to design sites
        f = feval(dmodel.regr, x); % predictor only
        r = feval(dmodel.corr, dmodel.ThetaP, dx);
        sy = f * dmodel.beta + (dmodel.gamma*r).'; % Scaled predictor
        y = (dmodel.Ysc(1,:) + dmodel.Ysc(2,:) .* sy)';% Predictor
    if  nargout > 1 % MSE wanted      
        rt = dmodel.C \ r;
        u = dmodel.Ft.' * rt - f.';
        v = dmodel.G \ u;
        rRsigma2=sum(rt.^2);
        if rRsigma2>1
           warning('rRsigma2 is larger than 1 due to calculation error, it has been repaired to 1');
           rRsigma2(rRsigma2>1)=1;
        end  
        mse = repmat(dmodel.sigma2,mx,1) .* repmat((1 + sum(v.^2) - rRsigma2 + mu)',1,q);
    end
  else  % several trial sites
    % Get distances to design sites  
    dx = zeros(mx*m,n);  kk = 1:m;
    for  k = 1 : mx
      dx(kk,:) = repmat(x(k,:),m,1) - dmodel.S;
      kk = kk + m;
    end
    % Get regression function and correlation
    f = feval(dmodel.regr, x);
    r = feval(dmodel.corr, dmodel.ThetaP, dx);
    r = reshape(r, m, mx);
    % Scaled predictor 
    sy = f * dmodel.beta + (dmodel.gamma * r).';
    % Predictor
    y = repmat(dmodel.Ysc(1,:),mx,1) + repmat(dmodel.Ysc(2,:),mx,1) .* sy;
    if  nargout > 1   % MSE wanted
      rt = dmodel.C \ r;
      u = dmodel.G \ (dmodel.Ft.' * rt - f.');
      mse = repmat(dmodel.sigma2,mx,1) .* repmat((1 + colsum(u.^2) - colsum(rt.^2) + mu)',1,q);
    end  
  end % of several sites
end
% >>>>>>>>>>>>>>>>   Auxiliary function  ====================

function  s = colsum(x)
% Columnwise sum of elements in  x
if  size(x,1) == 1  
    s = x; 
else
    s = sum(x); 
end
end