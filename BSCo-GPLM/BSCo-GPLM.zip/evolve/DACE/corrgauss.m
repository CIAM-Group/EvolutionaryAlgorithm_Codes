function  [r, dr] = corrgauss(ThetaP, d)
%CORRGAUSS  Gaussian correlation function,
%
%           n
%   r_i = prod exp(-ThetaP_j *|d_ij|^p) ,  i = 1,...,m
%          j=1
%
% If length(ThetaP) = 1, then the model is isotropic:
% all  ThetaP_j = ThetaP .
%
% Call:    r = corrgauss(ThetaP, d)
%          [r, dr] = corrgauss(ThetaP, d)
%
% ThetaP :  parameters in the correlation function
% d     :  m*n matrix with differences between given data points
% r     :  correlation

% hbn@imm.dtu.dk  
% Last update June 2, 2002

[m,n] = size(d);  % number of differences and dimension of data
if  length(ThetaP) == 1
  theta = repmat(ThetaP,m,n);p=2*ones(m,n);
elseif length(ThetaP)==n
  theta = repmat(ThetaP',m,1);p=2*ones(m,n);  
elseif  length(ThetaP)==2*n
  theta = repmat(ThetaP(1:n)',m,1);p=repmat(ThetaP(n+1:end)',m,1);
else
  error('Length of ThetaP must be 1, %d or %d',n,2*n)
end

td = -theta.*(abs(d).^p);
r = exp(sum(td, 2));

if  nargout > 1
    dr=-theta.*p.*(abs(d).^(p-1)).* repmat(r,1,n);
%   dr = repmat(-2*ThetaP(:).',m,1) .* d .* repmat(r,1,n);
end