clc
clear

% DE = load('Experiment_RES\AlphaData_Fix_newDE_Check.mat').problemSet;
Normal = load('Experiment_RES\leastSquare\AlphaData.mat').problemSet;
testset = {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6', 'DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ5', 'DTLZ6', 'DTLZ7', 'WFG1', 'WFG2', 'WFG3', 'WFG4', 'WFG5', 'WFG6', 'WFG7', 'WFG8', 'WFG9'};
% testset = {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6', 'WFG1', 'WFG2', 'WFG3', 'WFG4'};
% testset = {'WFG9'};
Num = length(testset);
for i = 1 : Num
%     deData = DE{i}.IterationsStructs;
%     DEiteration = length(deData);
%     DEarr = zeros(1, DEiteration);
%     for j = 1 : DEiteration
%         subproblem = deData(j).subproblems;
%         alpha = [subproblem.alpha];
%         meanA = mean(alpha);
%         DEarr(j) = meanA;
%     end
    nData = Normal{i}.IterationsStructs;
    Niteration = length(nData);
    Narr = zeros(1, Niteration);
%     score = [nData.score];
    for j = 1 : Niteration
        subproblem = nData(j).subproblems;
        alpha = [subproblem.alpha];
        alpha(isinf(alpha)) = 0;
        meanA = mean(alpha);
        Narr(j) = meanA;
    end
%     if length(Narr) == length(DEarr)
%         x = linspace(1, length(Narr), length(Narr));
%     else
%         [Narr(end+1:max([length(Narr), length(DEarr)])), DEarr(end+1:max([length(Narr), length(DEarr)]))] = deal(0);
%         x = linspace(1, length(Narr), length(Narr));
%     end
    x = linspace(1, length(Narr), length(Narr));
    figure
    plot(x, Narr);
%     hold on
%     plot(x, score)
    xlabel('iteration')
    ylabel('Alpha')
%     legend('gamma', 'score')
    title(testset{i})
%     legend('Uniform', 'DE')
    exportgraphics(gca,['Experiment_RES\leastSquare\pic\', testset{i}, '.eps'])
end