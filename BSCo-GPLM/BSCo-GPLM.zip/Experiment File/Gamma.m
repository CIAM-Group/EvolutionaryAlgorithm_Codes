clc
clear

gammaD = load('Experiment_RES\GammaData_ASS.mat').problemSet;
score = load('Experiment_RES\Score.mat').problemSet;
score(9 : 12) = [];
gammaD(9 : 11) = [];
testset = {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6', 'DTLZ1', 'DTLZ2', 'DTLZ3', 'WFG1', 'WFG2', 'WFG3', 'WFG4', 'WFG5', 'WFG6', 'WFG7', 'WFG8', 'WFG9'};
G = zeros(2, length(testset));
for i = 1 : length(testset)
    data = gammaD{i}.gamma;
    meanGamma = cellfun(@(x) mean(x), data);
    gamma = mean(meanGamma, 2);
    maxgamma = max(gamma);
    mingamma = min(gamma);
    G(1, i) = maxgamma; G(2, i) = mingamma;
%     x = linspace(1, length(gamma), length(gamma));
%     figure
%     plot(x, gamma);
%     title(testset{i})
end