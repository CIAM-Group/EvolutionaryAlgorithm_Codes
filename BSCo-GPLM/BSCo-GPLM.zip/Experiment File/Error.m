clc
clear

LS = load('Experiment_RES/Error/LS_Error2.mat').problemSet;
RBF = load('Experiment_RES/Error/RBF_Error2.mat').problemSet;

Nproblem = length(LS);
for i = 1 : Nproblem
    LSpro = LS{1, i}.IterationsStructs;
    RBFpro = RBF{1, i}.IterationsStructs;
    iter = length(LSpro);
    LSerror = zeros(1, iter);
    RBFerror = zeros(1, iter);
    for j = 1 : iter
        LSerror(j) = mean(LSpro(j).E);
        RBFerror(j) = mean(RBFpro(j).E);
    end
    figure
    x = linspace(1, iter, iter);
    plot(x, LSerror)
    hold on
    plot(x, RBFerror)
    legend('LS', 'RBF')
    xlabel('iteration')
    ylabel('Error')
    ylim([0, 1])
    title(['WFG', num2str(i + 4)])
    exportgraphics(gca,['Experiment_RES\Error\pic\', 'WFG', num2str(i + 4), '.eps'])
end