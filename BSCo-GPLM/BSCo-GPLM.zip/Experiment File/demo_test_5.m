function demo_test_5()
    dbstop if error
    warning off
    clc;
    clear;
%     restoredefaultpath;
    cal_igd = 'yes';
    %%
    methodname = 'DDICBO';
    maxruntime = 1; sel = 20;
    AFstructCell = {};
    AFstructCell{end + 1} = struct('name', 'ALCB'); 
    % testset = {'ZDT1', 'ZDT2', 'ZDT6', 'ZDT3', 'LZ1', 'LZ2', 'LZ3', 'LZ4', 'ZDT4', 'DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ4', 'mDTLZ1', 'mDTLZ2', 'mDTLZ3', 'mDTLZ4'};
    testset = {'ZDT1'};
%      testset = {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6', 'DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ5', 'DTLZ6', 'DTLZ7', 'WFG1', 'WFG2', 'WFG3', 'WFG4', 'WFG5', 'WFG6', 'WFG7', 'WFG8', 'WFG9'};
    GPname = 'DEGP';

    %% for every test problem
        for ii = 1:length(testset)
            % for every AFs 
            tic
            for AFstructSingleCell = AFstructCell
                AFstruct = AFstructSingleCell{end};
                rng('default');
                testname = testset{ii};
                disp([methodname, '-', GPname, '-', AFstruct.name, ' on ', testname]);
                AFchars = [AFstruct.name];
                [params, mop] = loadparams(testname);
                PS = cell(1, maxruntime);
                PF = PS;

                if strcmp(cal_igd, 'yes')
                    igd = zeros(maxruntime, 1);
                    [PFtrue, ~] = true_pareto(deblank(mop.name), 500, mop.pd);
                end

                % initialize the cells for each runtimeDataStruct
                runtimeDataStructCells = cell(1, maxruntime);
                % for every run
                tic
                for jj = 1:maxruntime
                    disp(['starting runtime ', num2str(jj), '/', num2str(maxruntime)]);
                    [EvaInds, subproblems] = init(mop, params);
                    [EvaPS, EvaPF, IterationsStructs] = moeadego(mop, params, EvaInds, subproblems, sel, AFstruct, PFtrue, GPname);
                    
                    if strcmp(cal_igd, 'yes')
                        igd(jj) = IGD(PFtrue, EvaPF{1, end});
                        fprintf('The IGD-values in first %d run times for %s testing %s problem\n', jj, methodname, testname);
                        fprintf('%.4f \n', igd);
                    end
                    
                    PS{1, jj} = EvaPS; PF{1, jj} = EvaPF;
                    %
                    runtimeDataStruct = struct();
                    runtimeDataStruct.runtime = jj;
                    runtimeDataStruct.EvaPS = EvaPS;
                    runtimeDataStruct.EvaPF = EvaPF;
                    runtimeDataStruct.IterationsStructs = IterationsStructs;
                    runtimeDataStruct.igd = igd(jj);
                    runtimeDataStructCells{1,jj} = runtimeDataStruct;
                end
                toc
                
                fprintf('mean_igd=%.4f,medianigd=%.4f\n', mean(igd), median(igd))
                file_name = [GPname, '_', testname, '_', AFchars, '_maxrun_', num2str(maxruntime), '.mat'];
                fold_name = 'Experiment_RES';
                
                if exist(fold_name, 'dir') ~= 7 % not a folder
                    system(['mkdir ' fold_name]);
                end
                
                file_path = strcat(cd, ['\' fold_name '\']);
                % save([file_path, file_name], 'PF', 'PS');
                PFruns = PF;
                PSruns = PS;
                IGDruns = igd;
                save([file_path, file_name], 'params', 'mop', 'PFtrue', 'PFruns', 'PSruns', 'IGDruns','testname', 'methodname', 'AFchars', 'AFstruct', 'maxruntime','runtimeDataStructCells');
            end
        end
end
