clc
clear

Train = load('MSEValidation_Train2.mat').MSEres;
Train = loadMSE(Train);
%DDICBO_DTLZ = load('leastSquare/10D/LSsummaryDTLZ.mat').res;
%DDICBO_ZDT = load("leastSquare/10D/LSsummaryZDT.mat").res;
DDICBO = Train;
% delete = [1, 8];
% DDICBO(delete, :) = [];
Test = load("MSEValidation_Train2.mat").TrainRes;
Test = loadTestMSE(Test);
% delete = [4, 6, 7];
% DDICBO_GL(delete, :) = [];
% Test = Test(1 : 9, :);

Mean = zeros(1, size(Test, 1));
Std = Mean; H = Mean;
SOTAMean = Mean; SOTAStd = Std;


for i = 1 : size(Test, 1)
    tempIGD = DDICBO(i, DDICBO(i, :) ~= 0);
    len = length(Test(i, :) ~= 0);
    meanIGD = mean(tempIGD);
    stdIGD = std(tempIGD);
    [~, h] = ranksum(Test(i, 1 : len), tempIGD(1 : len));
    Mean(i) = meanIGD; Std(i) = stdIGD; H(i) = h;
    SOTAMean(i) = mean(Test(i, :)); SOTAStd(i) = std(Test(i, :));
end
SOTAres = [SOTAMean; SOTAStd; H]';
DDICBOres = [Mean; Std]';

function [res] = loadMSE(data)
    res = zeros(length(data), 30);
    for i = 1 : length(data)
        temp = data(i).MMSE;
        res(i, :) = temp(1, :);
    end
end
function [res] = loadTestMSE(data)
    res = zeros(length(data), 30);
    for i = 1 : length(data)
        temp = data(i).MRMSE;
        res(i, :) = temp(1, :);
    end
end

