function Res = testGP()
    clc
    clear

    problem = {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6'...
        'DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ4', 'DTLZ5', 'DTLZ6', 'DTLZ7', ... 
        'WFG1', 'WFG2', 'WFG3', 'WFG4', 'WFG5', 'WFG6', 'WFG7', 'WFG8', 'WFG9'};
    GPname = {'InGP', 'CoMOGP'};
    initialSize = 100;
    Res = cell(length(problem), 1);
    for i = 1 : length(problem)
        res = zeros(30, length(GPname));
        parfor ii = 1 : 30
            testname = problem{i};
            [params, mop] = loadparams(testname); 
             [~, subproblem] = init(mop, params, 'None');
            domains = mop.domain(:, 2) - mop.domain(:, 1);
            lowerbound = mop.domain(:, 1);
            Pop = lhsdesign(initialSize, mop.pd, 'iterations', 5) .* repmat(domains', initialSize, 1) + repmat(lowerbound', initialSize, 1);
            Obj = zeros(size(Pop, 1), params.N_obj);
            for j = 1 : initialSize
                Obj(j, :) = evaluate(mop, Pop(j, :)');
            end
    %% Train GP models
            GPmodels = cell(1, length(GPname));
            for j = 1 : length(GPname)
                GPmodels{j} = trainGP(Pop, Obj, params, GPname{j});
            end
    %% Get training error
            TRerror = getTRerror(GPmodels, Pop, Obj, GPname, params, subproblem);
            res(ii, :) = TRerror;
        end
        [~, h] = ranksum(res(:, 1), res(:, 2));
        Res{i} = [mean(res), h];
    end
    
end

function models = trainGP(X, Y, params, GPname)
    Nobj = params.N_obj;
    X_train_cell = cell(1, Nobj); Y_train_cell = cell(1, Nobj);
    GPstruct = struct();
    switch GPname
        case 'CoMOGP'
            GPstruct.GPname = 'CoMOGP';
            GPstruct.modelMethod = 'CoMOGP';
            GPstruct.mode = 'MTGP_diff_sn2';
            GPstruct.meanfunc = '2';
            GPstruct.ts = 0.7;
        case 'InGP'
            GPstruct.GPname = 'InGP';
            GPstruct.modelMethod = 'InGP';
            GPstruct.mode = 'SingGP';
            GPstruct.meanfunc = '2';
            GPstruct.ts = 0.7;
    end
    for i = 1 : Nobj
        X_train_cell{1, i} = X;
        Y_train_cell{1, i} = Y(:, i);
    end

    switch GPname
        case 'InGP'
            models = cell(1, Nobj);
            for i = 1 : Nobj
                dmodel = learn_gp(X_train_cell(i), Y_train_cell(i), GPstruct);
                models{1, i} = dmodel;
            end
        case 'CoMOGP'
            models = learn_gp(X_train_cell, Y_train_cell, GPstruct);
    end
end

function error = getTRerror(models, X, Y, GPname, params, subproblem)
    error = zeros(1, length(GPname));
    test_Y = subobjective([subproblem.weight], Y', params.Dmethod)';
    idealpoint = min(Y)';
    for i = 1 : length(GPname)
        predObj = zeros(size(X, 1), params.N_obj);
        predVar = zeros(size(X, 1), params.N_obj);
        SubpObjs = zeros(length(subproblem), size(test_Y, 1));
        if strcmp('InGP', GPname{i})
            model = models{i};
            for j = 1 : params.N_obj
                [u, s] = predict_tasks(X, model{j});
                u = cell2mat(u); s = cell2mat(s);
                predObj(:, j) = u; predVar(:, j) = s;
            end
            for j = 1 : length(subproblem)
                [tempObj, ~] = tchGP(subproblem(j).weight, predObj', predVar', idealpoint);
                SubpObjs(j, :) = tempObj;
            end
            diff = (SubpObjs - test_Y).^2;
        else
            model = models{i};
            [u, s] = predict_tasks(X, model);
            u = cell2mat(u); s = cell2mat(s);
            predObj = u; predVar = s;
            for j = 1 : length(subproblem)
                [tempObj, ~] = tchGP(subproblem(j).weight, predObj', predVar', idealpoint);
                SubpObjs(j, :) = tempObj;
            end
            diff = (SubpObjs - test_Y).^2;
        end
        RMSE = mean(sqrt(diff), 2);
        error(i) = mean(RMSE);
    end
end

function [SubpMeans, SubpVars] = tchGP(weight, ObjMeans, ObjVars, idealpoint)
    % Transfer the obective prediction to subproblem
        [Nobj, Nw] = size(weight);
        Nind = size(ObjMeans, 2);
        if Nind == 1
            U = weight .* repmat((ObjMeans - idealpoint), 1, Nw);
            V = (weight .^ 2) .* repmat(ObjVars, 1, Nw);
        elseif Nw == 1
            U = repmat(weight, 1, Nind) .* (ObjMeans - repmat(idealpoint, 1, Nind));
            V = (repmat(weight, 1, Nind) .^ 2) .* ObjVars;
        elseif Nw == Nind
            U = weight .* (ObjMeans - repmat(idealpoint, 1, Nind));
            V = (weight .^ 2) .* ObjVars;
        else
            error('individual size must be same as weight size, or equals 1');
        end
    
        Cur_u = U(1, :); Cur_v = V(1, :);
    
        for i = 2:Nobj
            u1 = Cur_u; v1 = Cur_v;
            u2 = U(i, :); v2 = V(i, :);
            t = sqrt(v1 + v2);
            a = (u1 - u2) ./ t;
            Cur_u = u1 .* normcdf(a) + u2 .* normcdf(-a) + t .* normpdf(a);
            Cur_v = (u1 .^ 2 + v1) .* normcdf(a) + (u2 .^ 2 + v2) .* normcdf(-a) + (u1 + u2) .* t .* normpdf(a) - Cur_u .^ 2;
    
            if any(Cur_v < 0)
                if all(Cur_v >- eps)
                    Cur_v(Cur_v < 0) = 0;
                    warning('Predicted objective variance is less than 0, and has been corrected to 0');
                else
                    error('Predicted objective variance is less than 0, and the error is too large');
                end
    
            end
            if any(isnan([Cur_u, Cur_v]))
                Cur_u = 0; Cur_v = 0;
            end
        end
        SubpMeans = Cur_u; SubpVars = Cur_v;
end

