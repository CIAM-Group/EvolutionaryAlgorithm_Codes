dbstop if error
warning off
clc;
clear;
ModelName = {'CoMOGP'};
initialSize = 400;
repetition = 20;
res = zeros(length(ModelName), repetition);
RMSEres = zeros(length(ModelName), repetition);
problem = {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6', 'DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ4', 'DTLZ5', 'DTLZ6', 'DTLZ7', 'WFG1', 'WFG2', 'WFG3', 'WFG4',... 
            'WFG5', 'WFG6', 'WFG7', 'WFG8', 'WFG9'};
MSEres = struct('MMSE', [], 'mean', [], 'var', [], 'H', []);
TrainRes = struct('RMSE', [], 'mean', [], 'var', [], 'H', []);
MSEres = repmat(MSEres, 1, 21); TrainRes = repmat(TrainRes, 1, 21);
for jj = 1 : length(problem)
    [params, mop] = loadparams(problem{jj});
    for ii = 1 : repetition
        %% Initialize settings
        [~, subproblem] = init(mop, params, 'None');
        %% Generate solutions
        domains=mop.domain(:,2)-mop.domain(:,1);
        lowerbound=mop.domain(:,1);
        Pop=lhsdesign(initialSize,mop.pd,'iterations',5).*repmat(domains',initialSize,1)+repmat(lowerbound',initialSize,1);
        Obj = zeros(size(Pop, 1), params.N_obj);
        for i = 1 : initialSize
            Obj(i, :) = evaluate(mop, Pop(i, :)');
        end
        %% Train & Test Split
        Npop = size(Obj, 1); TrainSize = ceil(0.75 * Npop);
        PopIdx = linspace(1, Npop, Npop);
        trainIdx = randsample(PopIdx, TrainSize);
        testIdx = setdiff(PopIdx, trainIdx);
        Train_X = Pop(trainIdx, :); Train_y = Obj(trainIdx, :);
        Test_X = Pop(testIdx, :); Test_y = Obj(testIdx, :);
        idealpoint = [0; 0];
        settingStruct = struct('dynamic', true, 'cluster', false, 'random', false, 'strategy', 'ASS', 'globalpred', true);
        %% Train objective models
        Models = cell(1, 3);
        GPstruct = struct();
        for i = 1 : length(ModelName)
            switch ModelName{i}
            case 'CoMOGP'
                GPstruct.GPname = 'CoMOGP';
                GPstruct.modelMethod = 'CoMOGP';
                GPstruct.mode = 'MTGP_diff_sn2';
                GPstruct.meanfunc = '2';
                GPstruct.ts = 0.7;
                EvaInds = struct('parameter', Train_X', 'objective', Train_y');
                [Model, ~] = GPModelTraining(EvaInds, params, GPstruct, settingStruct);
            case 'GPLM'
                GPstruct.GPname = 'CoMOGP';
                GPstruct.modelMethod = 'CoMOGP';
                GPstruct.mode = 'MTGP_diff_sn2';
                GPstruct.meanfunc = '2';
                GPstruct.ts = 0.7;
                
                EvaIdx = linspace(1, size(Train_X, 1), size(Train_X, 1));
                CoMOGPSize = ceil(0.7 * length(EvaIdx));
                CoMOGPIdx = randsample(EvaIdx, CoMOGPSize);
                GPLMIdx = setdiff(EvaIdx, CoMOGPIdx);
                CoMOGP_X = Train_X(CoMOGPIdx, :); CoMOGP_y = Train_y(CoMOGPIdx, :);
                GPLM_X = Train_X(GPLMIdx, :); GPLM_y = Train_y(GPLMIdx, :);
                EvaInds = struct('parameter', CoMOGP_X', 'objective', CoMOGP_y');
                [Model, ~] = GPModelTraining(EvaInds, params, GPstruct, settingStruct);
            case 'RBF'
                GPstruct.GPname = 'RBF';
                GPstruct.ts = 0.7;
                EvaInds = struct('parameter', Train_X', 'objective', Train_y');
                [Model, ~] = GPModelTraining(EvaInds, params, GPstruct, settingStruct);
            end
            Models{i}= Model;
        end
        %% Generate subproblem predictions
        ModelObjs = cell(1, 3);
        for i = 1 : length(ModelName)
            switch ModelName{i}
            case 'CoMOGP'
                [u, s] = predict_tasks(Test_X, Models{i}.model);
                u = cell2mat(u); s = cell2mat(s);
                PredObj = u'; PredVar = s';
                SubpObjs = zeros(length(subproblem), size(Test_y, 1));
                SubpVars = zeros(length(subproblem), size(Test_y, 1));
                for j = 1 : length(subproblem)
                    [tempObjs, tempVars] = tchGP(subproblem(j).weight, PredObj, PredVar, idealpoint);
                    SubpObjs(j, :) = tempObjs; SubpVars(j, :) = tempVars;
                end
            case 'GPLM'
                [u, s] = predict_tasks(GPLM_X, Models{i}.model); % Training GPLM model
                [test_u, test_s] = predict_tasks(Test_X, Models{i}.model); % Generate test sample prediction
                u = cell2mat(u); s = cell2mat(s);
                test_u = cell2mat(test_u); test_s = cell2mat(test_s);
                test_u = test_u'; test_s = test_s';
                PredObj = u'; PredVar = s';
                SubpObjs = zeros(length(subproblem), size(Test_y, 1));
                for j = 1 : length(subproblem)
                    [testObjs, testVars] = tchGP(subproblem(j).weight, test_u, test_s, idealpoint);
                    GPLMInd = struct('parameter', GPLM_X', 'objective', GPLM_y', 'PredObjs', PredObj, 'PredVars', PredVar);
                    subproblem(j) = SubpAlpha(GPLMInd, params, subproblem(j), idealpoint); % Training GPLM model
                    c = subproblem(j).alpha;
                    tempObjs = testObjs - c .* sqrt(testVars);
                    SubpObjs(j, :) = tempObjs;
                end
            case 'RBF'
                model = Models{i}.model;
                SubpObjs = zeros(length(subproblem), size(Test_X, 1));
                for j = 1 : length(subproblem)
                    y = zeros(params.N_obj, size(Test_X, 1));
                    for k = 1 : params.N_obj
                        dmodel = model{k};
                        y(k, :) = my_rbfpredict(dmodel.RBF_Model, dmodel.P, Test_X);
                    end
                    SubpObjs(j, :) = subobjective(subproblem(k).weight, y, params.Dmethod);
                end
            end
            ModelObjs{i} = SubpObjs;
        end
        %% Prepare test data

        %     TestObj = zeros(length(subproblem), size(Test_y, 1));
        TestObj = sub_objective([subproblem.weight], Test_y', params.Dmethod, idealpoint);
        %% Validate the Mean Square Error
        MMSE = zeros(1, length(ModelName));
        MSE = zeros(length(ModelName), size(Test_y, 1));
        for i = 1 : length(ModelName)
            Pred = ModelObjs{i};
            Error = TestObj - Pred;
            Square = Error.^2;
            Sqrt = sqrt(Square);
            mse = mean(Sqrt, 2);
            MSE(i, :) = mse;
            MMSE(i)= mean(mse);
        end
        res(:, ii) = MMSE;

        %% Obtain training error
        [MRMSE, ~] = TrainError(Models, ModelName, Train_X, Train_y, subproblem, params, idealpoint);
        RMSEres(:, ii) = MRMSE;

    end
%% Wilcoxon rank-sum test
H = zeros(1, length(ModelName) - 1);
TH = zeros(1, length(ModelName) - 1);
for i = 1 : length(ModelName) - 1
    base = res(end, :);
    TrainBase = RMSEres(end, :);
    compared = res(i, :);
    TrainCompared = RMSEres(i, :);
    [~, h] = ranksum(compared, base);
    [~, th] = ranksum(TrainCompared, TrainBase);
    H(i) = h;
    TH(i) = th;
end
%% Wilcoxon rank-sum test
    MSEres(jj).MMSE = res;
    MSEres(jj).mean = mean(res, 2);
    MSEres(jj).var = var(res, [], 2);
    MSEres(jj).H = H;

    TrainRes(jj).RMSE = RMSEres;
    TrainRes(jj).mean = mean(RMSEres, 2);
    TrainRes(jj).var = var(RMSEres, [], 2);
    TrainRes(jj).H = TH;
    
end
 save('MSEValidation_Train3.mat', 'MSEres', 'TrainRes')

function [SubpMeans, SubpVars] = tchGP(weight, ObjMeans, ObjVars, idealpoint)
    % Transfer the obective prediction to subproblem
        [Nobj, Nw] = size(weight);
        Nind = size(ObjMeans, 2);
        if Nind == 1
            U = weight .* repmat((ObjMeans - idealpoint), 1, Nw);
            V = (weight .^ 2) .* repmat(ObjVars, 1, Nw);
        elseif Nw == 1
            U = repmat(weight, 1, Nind) .* (ObjMeans - repmat(idealpoint, 1, Nind));
            V = (repmat(weight, 1, Nind) .^ 2) .* ObjVars;
        elseif Nw == Nind
            U = weight .* (ObjMeans - repmat(idealpoint, 1, Nind));
            V = (weight .^ 2) .* ObjVars;
        else
            error('individual size must be same as weight size, or equals 1');
        end
    
        Cur_u = U(1, :); Cur_v = V(1, :);
    
        for i = 2:Nobj
            u1 = Cur_u; v1 = Cur_v;
            u2 = U(i, :); v2 = V(i, :);
            t = sqrt(v1 + v2);
            a = (u1 - u2) ./ t;
            Cur_u = u1 .* normcdf(a) + u2 .* normcdf(-a) + t .* normpdf(a);
            Cur_v = (u1 .^ 2 + v1) .* normcdf(a) + (u2 .^ 2 + v2) .* normcdf(-a) + (u1 + u2) .* t .* normpdf(a) - Cur_u .^ 2;
    
            if any(Cur_v < 0)
                if all(Cur_v >- eps)
                    Cur_v(Cur_v < 0) = 0;
                    warning('Predicted objective variance is less than 0, and has been corrected to 0');
                else
                    error('Predicted objective variance is less than 0, and the error is too large');
                end
    
            end
            if any(isnan([Cur_u, Cur_v]))
                Cur_u = 0; Cur_v = 0;
            end
        end
        SubpMeans = Cur_u; SubpVars = Cur_v;
end
function [MRMSE, RMSE] = TrainError(Models, ModelName, X, y, subproblem, params, idealpoint)
    TestObj = zeros(length(subproblem), size(y, 1));
    for i = 1 : length(subproblem)
        TestObj(i, :) = sub_objective(subproblem(i).weight, y', params.Dmethod, idealpoint);
    end
    MRMSE = zeros(1, length(ModelName));
    for i = 1 :length(ModelName)
        switch ModelName{i}
            case 'CoMOGP'
                [u, s] = predict_tasks(X, Models{i}.model);
                u = cell2mat(u); s = cell2mat(s);
                PredObj = u'; PredVar = s';
                SubpObjs = zeros(length(subproblem), size(y, 1));
                SubpVars = zeros(length(subproblem), size(y, 1));
                for j = 1 : length(subproblem)
                    [tempObjs, tempVars] = tchGP(subproblem(j).weight, PredObj, PredVar, idealpoint);
                    SubpObjs(j, :) = tempObjs; SubpVars(j, :) = tempVars;
                end
        end
        error = SubpObjs - TestObj;
        Square = error.^2;
        Sqrt = sqrt(Square);
        RMSE = mean(Sqrt, 2);
        MRMSE(i) = mean(RMSE); 
    end
end

function obj = sub_objective(weight, ind, method, idealpoint)
    if (nargin==2)
        obj = ws(weight, ind);
%     elseif (nargin==3)
%         obj = te(weight, ind, idealpoint);
    else
        if strcmp(method, 'ws')
            obj=ws(weight, ind);
        elseif strcmp(method, 'rtch')
            obj=rtch(weight, ind, idealpoint);
        elseif strcmp(method, 'tch')
            obj=tch(weight, ind, idealpoint);
        elseif strcmp(method, 'pbi')
            obj=pbi(weight, ind, idealpoint);
        elseif strcmp(method,'ww')
            obj=ww(weight,ind);
        else
            obj= te(weight, ind, idealpoint);
        end
    end
end

function obj = tch(weight, ind, idealpoint)
    s = size(weight, 2);     
    indsize = size(ind,2);   
%     weight((weight==0))=0.0000001;
    if indsize==s 
        part2 = ind-idealpoint(:,ones(1, indsize));
        obj = max(weight.*part2);
    elseif indsize ==1
        part2 = ind-idealpoint;
        obj = max(weight.*part2(:,ones(1, s)));
    elseif s==1
        part2=ind-idealpoint(:,ones(1, indsize));
        obj = max(weight(:,ones(1, indsize)).*part2);
        
    else
        error('individual size must be same as weight size, or equals 1');
    end
    
end