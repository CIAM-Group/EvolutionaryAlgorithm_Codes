clc
clear

algorithm = {'NSGAIIIEHVI'};
M = [2, 3];
D = [8, 10];
problem = {'ZDT', 'WFG', 'DTLZ'};
Num = [6, 9, 7];
maxruntime = 30;
for i = 1 : length(algorithm)
    for ii = 1 : length(M)
        for j = 1 : length(D)
            IGD = zeros(21, maxruntime);
            counter = 1;
            for jj = 1 : length(problem)
                if strcmp(problem{jj}, 'ZDT') && M(ii) == 3
                    continue;
                end
                for k = 1 : Num(jj)
                    if strcmp(problem{jj}, 'ZDT') && k == 5
                        continue;
                    end
                    for kk = 1 : maxruntime
                        filename = [algorithm{i}, '_', problem{jj}, num2str(k), '_M', num2str(M(ii)), '_D', num2str(D(j)), '_', num2str(kk), '.mat'];
                        foldname = algorithm{i};
                        file_path = strcat(cd, ['/' foldname '/']);
                        load([file_path, filename])
                        IGD(counter, kk) = mean(metric.IGD);
                    end
                    counter = counter + 1;
                end
            end
            save([algorithm{i}, '_M', num2str(M(ii)), '_D', num2str(D(j)), '.mat'], 'IGD')
        end
    end
end