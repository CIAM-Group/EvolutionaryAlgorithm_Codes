function demo_test_par()
    dbstop if error
    warning off
    clc;
    clear;
%     restoredefaultpath; 
    cal_igd = 'yes';
    %%
    methodname = 'DDICBO';
    maxruntime = 30; sel = 20;
    AFstructCell = {};
    GPname = 'InGP';
    AFstructCell{end + 1} = struct('name', 'GPLM');
    % testset = {'ZDT1', 'ZDT2', 'ZDT6', 'ZDT3', 'LZ1', 'LZ2', 'LZ3', 'LZ4', 'ZDT4', 'DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ4', 'mDTLZ1', 'mDTLZ2', 'mDTLZ3', 'mDTLZ4'};
%     testset = {'ZDT1', 'ZDT2'};
    testset = {'DTLZ4'};
    
    switch GPname
        case 'CoMOGP'
            GPstruct.GPname = 'CoMOGP';
            GPstruct.modelMethod = 'CoMOGP';
            GPstruct.mode = 'MTGP_diff_sn2';
            GPstruct.meanfunc = '2';
            GPstruct.ts = 0.7;
        case 'InGP'
            GPstruct.GPname = 'InGP';
            GPstruct.modelMethod = 'InGP';
            GPstruct.mode = 'SingGP';
            GPstruct.meanfunc = '2';
            GPstruct.ts = 0.7;
        case 'DEGP'
            GPstruct.modelMethod = 'DEGP';
            GPstruct.ts = 0.7;
        case 'RBF'
            GPstruct.GPname = GPname;
            GPstruct.modelMethod = 'RBF';
            GPstruct.ts = 0.7;
    end
    settingStruct = struct('dynamic', true, 'cluster', false, 'random', false, 'strategy', 'None', 'globalpred', false);
    %% for every test problem
        for ii = 1:length(testset)
            % for every AFs 
            tic
            for AFstructSingleCell = AFstructCell
                AFstruct = AFstructSingleCell{end};
                rng('default');
                testname = testset{ii};
                disp([methodname, '-', GPname, '-', AFstruct.name, ' on ', testname]);
                AFchars = [AFstruct.name];
                [params, mop] = loadparams(testname);
                PS = cell(1, maxruntime);
                PF = PS;
                % initialize the cells for each runtimeDataStruct
%                 runtimeDataStructCells = cell(1, maxruntime);
                % for every run
                tic
                parfor jj = 1:maxruntime
                    if strcmp(cal_igd, 'yes')
                        [PFtrue, ~] = true_pareto(deblank(mop.name), 500, mop.pd, mop.od);
                    end
                    disp(['starting runtime ', num2str(jj), '/', num2str(maxruntime)]);
                    [EvaInds, subproblems] = init(mop, params, settingStruct.strategy);
                    [EvaPS, EvaPF, IterationsStructs] = moeadego(mop, params, EvaInds, subproblems, sel, AFstruct, PFtrue, GPstruct, settingStruct);
                    
                    if strcmp(cal_igd, 'yes')
                        igd_temp = IGD(PFtrue, EvaPF{1, end});
                        fprintf('The IGD-values in first %d run times for %s testing %s problem\n', jj, methodname, testname)
                        fprintf('%.4f \n', igd_temp)
                    end
                    igd(jj) = igd_temp;
%                     PS{1, jj} = EvaPS; PF{1, jj} = EvaPF;
                    %
                    runtimeDataStruct = struct();
                    runtimeDataStruct.runtime = jj;
                    runtimeDataStruct.EvaPS = EvaPS;
                    runtimeDataStruct.EvaPF = EvaPF;
                    runtimeDataStruct.IterationsStructs = IterationsStructs;
                    runtimeDataStruct.igd = igd_temp;
                    runtimeDataStructCells_par{jj} = runtimeDataStruct;
                end
                toc
                runtimeDataStructCells = runtimeDataStructCells_par;
                fprintf('mean_igd=%.4f,medianigd=%.4f\n', mean(igd), median(igd))
                file_name = [GPname, '_', testname, '_', AFchars, '_maxrun_', num2str(maxruntime), '.mat'];
                fold_name = 'Experiment_RES\BSCoE_GPLM_RE\';

                
                if exist(fold_name, 'dir') ~= 7 % not a folder
                    system(['mkdir ' fold_name])
                end
                
                file_path = strcat(cd, ['\' fold_name '\']);
                % save([file_path, file_name], 'PF', 'PS');
                
                PFruns = PF;
                PSruns = PS;
                IGDruns = igd;
                save([file_path, file_name], 'params', 'mop', 'PFruns', 'PSruns', 'IGDruns','testname', 'methodname', 'AFchars', 'AFstruct', 'maxruntime','runtimeDataStructCells');
            end
        end
end
