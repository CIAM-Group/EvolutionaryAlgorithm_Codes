function demo_test_problemPar()
    dbstop if error
    warning off
    clc;
    clear;
    %     restoredefaultpath;
    cal_igd = 'yes';
    %%
    methodname = 'DDICBO';
    sel = 20;
    GPname = 'CoMOGP';
    AFstruct = struct('name', 'LCB_LS');
    % testset = {'ZDT1', 'ZDT2', 'ZDT6', 'ZDT3', 'LZ1', 'LZ2', 'LZ3', 'LZ4', 'ZDT4', 'DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ4', 'mDTLZ1', 'mDTLZ2', 'mDTLZ3', 'mDTLZ4'};
    %     testset = {'ZDT1', 'ZDT2'};
    testset = {'WFG1', 'WFG2', 'WFG3', 'WFG4'};
%% for every test problem
    file_name = 'SelectSubp';
    fold_name = 'Experiment_RES\leastSquare';
    file_path = strcat(cd, ['\' fold_name '\']);
    ProblemCell = {};

    switch GPname
        case 'CoMOGP'
            GPstruct.GPname = 'CoMOGP';
            GPstruct.modelMethod = 'CoMOGP';
            GPstruct.mode = 'MTGP_diff_sn2';
            GPstruct.meanfunc = '2';
            GPstruct.ts = 0.7;
        case 'InGP'
            GPstruct.GPname = 'InGP';
            GPstruct.modelMethod = 'InGP';
            GPstruct.mode = 'SingGP';
            GPstruct.meanfunc = '2';
            GPstruct.ts = 0.7;
        case 'DEGP'
            GPstruct.GPname = 'DEGP';
            GPstruct.modelMethod = 'DEGP';
            GPstruct.ts = 0.7;
        case 'RBF'
            GPstruct.GPname = 'RBF';
            GPstruct.modelMethod = 'CoMOGP';
            GPstruct.mode = 'MTGP_diff_sn2';
            GPstruct.meanfunc = '2';
            GPstruct.ts = 0.7;
    end
    settingStruct = struct('dynamic', true, 'cluster', false, 'random', false);
    parfor ii = 1:length(testset)
        tic
        rng('default');
        testname = testset{ii};
        disp([methodname, '-', GPname, '-', AFstruct.name, ' on ', testname]);
        [params, mop] = loadparams(testname);
        tic
        if strcmp(cal_igd, 'yes')
            [PFtrue, ~] = true_pareto(deblank(mop.name), 500, mop.pd, mop.od);
        end
        [EvaInds, subproblems] = init(mop, params);
        [EvaPS, EvaPF, IterationsStructs] = moeadego(mop, params, EvaInds, subproblems, sel, AFstruct, PFtrue, GPstruct, settingStruct);
        
        if strcmp(cal_igd, 'yes')
            igd = IGD(PFtrue, EvaPF{1, end});
            fprintf('%.4f \n', igd)
        end
        problemStruct = struct();
        problemStruct.EvaPS = EvaPS;
        problemStruct.EvaPF = EvaPF;
        problemStruct.IterationsStructs = IterationsStructs;
        problemStruct.igd = igd;
        ProblemCell{ii} = problemStruct;
        toc
        fprintf('mean_igd=%.4f,medianigd=%.4f\n', mean(igd), median(igd))
    end
    problemSet = ProblemCell;
    if exist(fold_name, 'dir') ~= 7 % not a folder
        system(['mkdir ' fold_name]);
    end
    save([file_path, file_name], 'problemSet');
end
