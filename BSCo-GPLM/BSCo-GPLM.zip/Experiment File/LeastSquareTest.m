clc
clear
load('EvaObj.mat')
load('SubpObj.mat')
load("SubpStd.mat")

% x = linspace(1, 50, 50);
% I = zeros(1, length(x));
% for i = 1 : length(x)
%     coe = (50 - x(i));
%     ideal = leastSquare(SubpObj, SubpStd, EvaObj, coe);
%     I(i) = ideal;
% end
% I = abs(I);
% plot(x, I);

% lobound = ideal - 100;
% upbound = ideal + 100;
% x = linspace(lobound, upbound, 100);
% obj = sum(h(x, EvaObj, SubpObj, SubpStd));
% idealObj = sum(h(ideal, EvaObj, SubpObj, SubpStd));
% plot(x, obj)
% hold on
% scatter(ideal, idealObj)
% xlabel('x')
% ylabel('obj')

load('Experiment_RES\leastSquare\AlphaData.mat')
for i = 1 : length(problemSet)
    data = problemSet{i}.IterationsStructs;
    Nobj = size(problemSet{i}.EvaPF{1}, 1);
    iteration = length(data);
    MSE = zeros(1, iteration);
    x = linspace(1, iteration, iteration);
    for j = 1 : iteration
        EvaInds = data(j).NewEvaInds;
        CoMOGP = data(j).NewModel;
        subproblems = data(j).subproblems;
        trainIdx = CoMOGP.idx;
        model = CoMOGP.model;
        evaIdx = linspace(1, length(EvaInds), length(EvaInds));
        testIdx = setdiff(evaIdx, trainIdx);
        testSet = [EvaInds(testIdx).parameter];
        testY = [EvaInds(testIdx).objective]';
        Y = [EvaInds.objective]'; idealpoint = min(Y);
        [u, s] = predict_tasks(testSet', model);
        PredObj = cell2mat(u); PredVar = cell2mat(s);
        SubpMSE = zeros(1, length(subproblems));
        for k = 1 : length(subproblems)
            [SubpObj, SubpVar] = tchGP(subproblems(i).weight, PredObj', PredVar', idealpoint');
            EvaObj = tch(subproblems(i).weight, testY', idealpoint');
            error = sqrt((EvaObj - SubpObj).^2);
            error((error == max(error)) == 1) = [];
            error((error == min(error)) == 1) = [];
            SubpMSE(k) = mean(error);
        end
        MSE(j) = mean(SubpMSE);
    end
    figure
    plot(x, MSE);
end

function [alpha] = leastSquare(PredObj, PredVar, EvaObj, coe)
    if size(PredObj, 1) == 1
        PredObj = PredObj';
    end
    if size(PredVar, 1) == 1
        PredVar = PredVar';
    end
    if size(EvaObj, 1) == 1
        EvaObj = EvaObj';
    end
    alpha = (PredVar' * PredVar) \ PredVar' * ((PredObj - EvaObj) .* coe);
end

function [obj] = h(x, EvaObj, SubpObj, SubpVar)
    if size(SubpObj, 1) == 1
        SubpObj = SubpObj';
    end
    if size(SubpVar, 1) == 1
        SubpVar = SubpVar';
    end
    if size(EvaObj, 1) == 1
        EvaObj = EvaObj';
    end
    obj = (EvaObj - (SubpObj - x .* SubpVar)).^2;
end

function [bound] = CalcAlpha(PredObj, PredVar, EvaObj)
    [~, RO] = sort(EvaObj);
    PredR = PredObj(RO);
    VarR = PredVar(RO);
    Ndata = length(EvaObj); bounds = zeros(1, Ndata - 1);
    eq = bounds; bound = [inf, inf];
    for i = 2 : Ndata
        bounds(i - 1) = (PredR(i - 1) - PredR(i)) ./ (VarR(i - 1) - VarR(i));
        if VarR(i - 1) - VarR(i) < 0
            eq(i - 1) = -1;
        else
            eq(i - 1) = 1;
        end
    end
    for i = 1 : length(bounds)
        if eq(i) == -1
            if isinf(bound(2))
                bound(2) = bounds(i);
            elseif bounds(i) < bound(2) && bounds(i) > bound(1)
                bound(2) = bounds(i);
            end
        else
            if isinf(bound(1)) && bounds(i) < bound(2)
                bound(1) = bounds(i);
            elseif bounds(i) > bound(1) && bounds(i) < bound(2)
                bound(1) = bounds(i);
            end
        end
    end
end

function [SubpMeans, SubpVars] = tchGP(weight, ObjMeans, ObjVars, idealpoint)
% Transfer the obective prediction to subproblem
    [Nobj, Nw] = size(weight);
    Nind = size(ObjMeans, 2);

    if Nind == 1
        U = weight .* repmat((ObjMeans - idealpoint), 1, Nw);
        V = (weight .^ 2) .* repmat(ObjVars, 1, Nw);
    elseif Nw == 1
        U = repmat(weight, 1, Nind) .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (repmat(weight, 1, Nind) .^ 2) .* ObjVars;
    elseif Nw == Nind
        U = weight .* (ObjMeans - repmat(idealpoint, 1, Nind));
        V = (weight .^ 2) .* ObjVars;
    else
        error('individual size must be same as weight size, or equals 1');
    end

    Cur_u = U(1, :); Cur_v = V(1, :);

    for i = 2:Nobj
        u1 = Cur_u; v1 = Cur_v;
        u2 = U(i, :); v2 = V(i, :);
        t = sqrt(v1 + v2);
        a = (u1 - u2) ./ t;
        Cur_u = u1 .* normcdf(a) + u2 .* normcdf(-a) + t .* normpdf(a);
        Cur_v = (u1 .^ 2 + v1) .* normcdf(a) + (u2 .^ 2 + v2) .* normcdf(-a) + (u1 + u2) .* t .* normpdf(a) - Cur_u .^ 2;

        if any(Cur_v < 0)
            if all(Cur_v >- eps)
                Cur_v(Cur_v < 0) = 0;
                warning('Predicted objective variance is less than 0, and has been corrected to 0');
            else
                error('Predicted objective variance is less than 0, and the error is too large');
            end

        end
        if any(isnan([Cur_u, Cur_v]))
            Cur_u = 0; Cur_v = 0;
        end
    end
    SubpMeans = Cur_u; SubpVars = Cur_v;
end
function obj = tch(weight, ind, idealpoint)
    s = size(weight, 2);     %权值个数
    indsize = size(ind,2);   %目标个数
%     weight((weight==0))=0.0000001;
    if indsize==s 
        part2 = ind-idealpoint(:,ones(1, indsize));
        obj = max(weight.*part2);
    elseif indsize ==1
        part2 = ind-idealpoint;
        obj = max(weight.*part2(:,ones(1, s)));
    elseif s==1
        part2=ind-idealpoint(:,ones(1, indsize));
        obj = max(weight(:,ones(1, indsize)).*part2);
        
    else
        error('individual size must be same as weight size, or equals 1');
    end
    
end