function [params,mop]=loadparams(testname,varargin)
%LOADPARAMS Load the parameter settings from external file.
%   The detailed explanation goes here, MOEA/D-EGO uses two optimizers, one
%   is the DE optimizer which is responsible for the parameters of GP models, 
%   the other one is MOEA-DE which aims to find the most potential Ke solutions under the built models.
  params = get_structure('parameter');
  % General Setting for MOEA/D-EGO
  params.Dmethod = 'tch'; %decomposition method both in the subproblem modeling and in the decomposition in MOEA/D-DE optimizer.
  params.L1 = 80;%the maximal number of points usd for building local model
  params.L2 = 20;%the number of points for adding one more model
  params.Ke = 5;%the number of points selected for evalutation at each iteration
  params.RegionSize = 20;%the number of regions devided during the prescreen process
  params.Mindiffer = 1e-5;% the minimum Euclidean distance for identifying two different solutions
  params.DE_Pop = 50;%the population size of the DE optimizer.
  params.DE_Gens = 50;%the maximal generations of DE optimizer.
  params.DE_CR = 0.1;%the crossover rate in DE optimizer.
  params.DE_F = 0.5;%the fator in DE optimizer.
  params.MOEAD_Gens = 100;%the maximal generations of MOEA/D-DE optimizer.
  params.MOEAD_CR = 1.0;%the crossover rate in MOEA/D-DE optimizer.
  params.MOEAD_F = 0.5;%the fator in MOEA/D-DE optimizer.
  params.MOEAD_NeiUseR = 0.9; %(neighbor use rate)the rate to use the neighbouring solutions for mating and updating in MOEA/D-DE optimizer.
  params.MOEAD_UpSize = 2;%(update size)the maximum update number for each iteration in MOEA/D-DE optimizer
    
  params.model_method = 'GP';
  params.nd_size = 20;
  params.TrainSize = 100;
  params.AlphaMethod = 'DE';

  % setting of the kaapaEA here
  params.kappaDE_Gens = 500;

  % set for the default for a specific problem here.

  switch lower(testname)
	case {'kno1','pol'}
      xobj=2; 
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'zdt1','zdt2','zdt3','zdt4','zdt6'}
      xobj=8;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=99;
      params.MOEAD_NeiSize=20;
    case {'dtlz1','dtlz2','dtlz3','dtlz4','dtlz5','dtlz6','dtlz7','convexdtlz2'}
      xobj=8;
      params.evaluation=300;    
      params.initsize=11*xobj-1;
      params.MOEAD_H=99;
      params.MOEAD_NeiSize=20;
    case {'mdtlz1','mdtlz2','mdtlz3','mdtlz4'}
      xobj=6;
      params.evaluation=300;        
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;   
     case {'glt1','glt2','glt3','glt4'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'glt5','glt6'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;
    case {'jy1','jy2','jy3','jy4','jym4'}
      xobj=8;
      params.evaluation=300;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'jy5','jy6'}
      xobj=6;
      params.evaluation=300;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;
    case {'lgz1','lgz2','lgz3','lgz4','lgz5'}
      xobj=8;
      params.evaluation=200;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'lgz6','lgz7'}
      xobj=6;
      params.evaluation=300;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;   
    case {'lz1','lz2','lz3','lz4',...
                'lz5','lz7','lz8','lz9'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'lz6'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;
    case {'uf1','uf2','uf3','uf4','uf5','uf6','uf7'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'uf8','uf9','uf10'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;      
      params.MOEAD_NeiSize=20;
    case {'wzlij1','wzlij2','wzlij3','wzlij4'...
               'wzlij5','wzlij6','wzlij7'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;      
      params.MOEAD_NeiSize=20;
    case {'wzlij8','wzlij9'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;      
      params.MOEAD_NeiSize=20;
    case {'wosgz1','wosgz2','wosgz3','wosgz4'...
               'wosgz5','wosgz6','wosgz7','wosgz8'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;      
      params.MOEAD_NeiSize=20;
    case {'wosgz9','wosgz10','wosgz11','wosgz12'...
               'wosgz13','wosgz14','wosgz15','wosgz16'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;      
      params.MOEAD_NeiSize=20;
    case {'wfg1','wfg2','wfg3','wfg4','wfg5','wfg6','wfg7','wfg8','wfg9'}
      xobj=10;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=99;
      params.MOEAD_NeiSize=20; 
    case {'re21', 're22', 're23', 're24', 're25'}
      xobj = 1;
      params.evaluation=300;
      params.MOEAD_NeiSize=20;
      params.MOEAD_H=99;
    otherwise
      warning('Unsupported mop name');
  end
  % handle the parameters passed in from the function directly!
    if strncmpi(testname, 're', 2)
        mop=testmop(testname,xobj);
        params.initsize=11*mop.pd-1;
        params.N_dim=mop.pd;
        params.N_obj=mop.od;
    else
        mop=testmop(testname,xobj);
        params.N_dim = xobj;
        params.N_obj = mop.od;
    end
    %% -------------------------Model Settings---------------------------------
    params.ModelMethod = 'InGP';
    % 'TrGP': transferred GP, obtain the other GPS from N_obj built GPs
    % 'InGP': independent GP, build GP for each subproblem/task
    % 'MTGP': multi-task GP
    % 'SLFM': semi-parametric latent factor model (also known as linear model of coregionalization)
    % 'CoMOGP': collaborative multi-output Gaussian process
    % 'CONV': process convolution
%==============================================================================

end

