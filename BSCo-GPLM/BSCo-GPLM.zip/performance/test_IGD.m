% test_IGD.m
% 
% Matlab source codes
% 
% Test IGD metric for CEC 2009 MOO Competition
%
% Usage: test_IGD()
% 
% Please refer to the report for more information.
%

function test_IGD()

% use mex -setup to choose a compiler if necessary
disp('----------------------------------------');
disp('build IGD metric');
 mex IGD.cpp;
disp('----------------------------------------');
% testset={'MOP1','MOP2','MOP3','MOP4','MOP5'};
testset={'MOP1','MOP2','MOP3','MOP4','MOP5','tec09_f1','tec09_f2','tec09_f3','tec09_f4','tec09_f5','tec09_f7','tec09_f8','tec09_f9','tec09_f6'};
% testset={'MOP1','MOP7','tec09_f8'};
% result=zeros(length(testset),30);
for i=1:length(testset)
testname=testset{i};
result=zeros(1,30);
disp('----------------------------------------');
fprintf('test IGD without constraint on %s\n',testname);
% load the PF* data
n=sprintf('pf_data/%s.dat',testname);
PFStar  = load(n);
% PFStar  = load('pf_data/MOP2.dat');
PFStar  = PFStar';

for j=1:30

% f       = sprintf('E:/result/%s-%d',testname,j);
f       = sprintf('E:/former result/%s-%d',testname,j);

% f='E:/result/tec09_f2'

a=load(f);
PF=a.df;
if i<=5
ParetoF = ParetoFilter(PF' );
ind     = cec09filter(ParetoF,100);
PF    =(ParetoF(:, ind));
else
PF=PF';
end
igd=IGD(PFStar, PF);
str  = sprintf('%.5f = IGD(PFStar, PF)', igd);
disp(str);
pf1=PFStar(1,:);
pf2=PFStar(2,:);
plot(pf1,pf2)
hold on 
pf_1=PF(1,:);
pf_2=PF(2,:);
plot(pf_1,pf_2,'or')

result(j)=igd;

% mean(result)
clear f ind PF;
disp('----------------------------------------');

end
 f       = sprintf('E:/IGD/%s/%s-IGD',testname,testname)
 save(f, 'result') ;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load the PF* data
PFStar  = load('pf_data/MOP1.dat');
PFStar  = PFStar';
ind     = cec09filter(PFStar',100);
PFStar    =(PFStar(ind, :))';
% randomly generate 1000 points inside the search space
xrange = xboundary('UF1', 30);
x  = repmat(xrange(:,1),[1,1000]) + repmat((xrange(:,2)-xrange(:,1)),[1,1000]).*rand(30, 1000);
% evaluate the points
fobj = cec09('UF1');
PF   = fobj(x);

% PF  = load('pf_data/UF1.dat');
a=load('E:/result/MOP1-1');
PF=a.df;
ind     = cec09filter(PF',300);
PF    =(PF(ind, :))';


str  = sprintf('%.5f = IGD(PFStar, PF)', IGD(PFStar, PF));
disp(str);
clear PFStar xrange x fobj PF;
disp('----------------------------------------');

disp('----------------------------------------');
disp('test IGD with constraint on CF1')
% load the PF* data
PFStar  = load('pf_data/CF1.dat');
PFStar  = PFStar';

% randomly generate 1000 points inside the search space
xrange = xboundary('CF1', 10);
x      = repmat(xrange(:,1),[1,1000]) + repmat((xrange(:,2)-xrange(:,1)),[1,1000]).*rand(10, 1000);
% evaluate the points
fobj   = cec09('CF1');
[PF,C] = fobj(x);
str  = sprintf('%.5f = IGD(PFStar, PF, C)', IGD(PFStar, PF, C));
disp(str);
clear PFStar xrange x fobj PF C;
disp('----------------------------------------');

end