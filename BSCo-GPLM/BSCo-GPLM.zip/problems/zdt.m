function mop=zdt(mop,testname,dimension)
%%run for zdt problems
switch lower(testname)
    case 'zdt1'
        mop=zdt1(mop,dimension);
    case 'zdt2'
        mop=zdt2(mop,dimension);
    case 'zdt3'
        mop=zdt3(mop,dimension);        
    case 'zdt4'
        mop=zdt4(mop,dimension);            
    case 'zdt6'
        mop=zdt6(mop,dimension);                    
    otherwise
        error('Undefined test problem name');
end
end
%%
function p=zdt1(p,dim)
   p.name='ZDT1';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(2,1);
      y(1)=x(1);
      su=sum(x)-x(1);    
      g=1+9*su/(dim-1);
      y(2)=g*(1-sqrt(y(1)/g));
    end
end
%%
function p=zdt2(p,dim)
   p.name='ZDT2';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(2,1);
      y(1) = x(1);
      su = sum(x)-x(1);    
      g = 1 + 9 * su / (dim - 1);
      y(2) =g*(1 - (y(1) / g).^2);
    end
end
%%
function p=zdt3(p,dim)
   p.name='ZDT3';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(2,1);
      y(1) = x(1);
      su = sum(x)-x(1);    
      g = 1 + 9 * su / (dim - 1);
      y(2) =g*(1 - sqrt(y(1) / g)-(y(1)./g).*sin(10*pi*y(1)));
     end
end
%%
function p=zdt4(p,dim)
   p.name='ZDT4';
   p.od=2;
   p.pd=dim;
   p.domain=[[0;-5*ones(dim-1,1)] [1;5*ones(dim-1,1)]];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(2,1);
      y(1) = x(1);
      aa=x.^2-10*cos(4*pi*x);
      su=sum(aa)-aa(1);  
      g = 1+10*(length(x)-1)+su;
      y(2) =g*(1 - sqrt(y(1) / g));
   end
end
%%
function p=zdt6(p,dim)
   p.name='ZDT6';
   p.od=2;
   p.pd=dim;
   p.domain=[zeros(dim,1) ones(dim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(2,1);
      y(1)=1-exp(-4*x(1)).*(sin(6*pi*x(1))).^6;
      g=1+9*((sum(x)-x(1))/(dim-1)).^0.25;
      h=1-(y(1)./g).^2;
      y(2)=g.*h;
   end
end


