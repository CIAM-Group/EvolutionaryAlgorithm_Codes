function mop=testmop(testname,pdim)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.
mop=struct('name',[],'od',[],'pd',[],'domain',[],'func',[]);
testname = lower(testname);
    switch testname
        case 'kno1'
            mop=kno1(mop);
        case 'pol'
            mop=pol(mop);
        case 'convexdtlz2'
            odim=3;
            mop=convexdtlz2(mop,pdim,odim);
        case {'zdt1','zdt2','zdt3','zdt4','zdt6'}
            mop=zdt(mop,testname,pdim);
        case {'dtlz1','dtlz2','dtlz3','dtlz4','dtlz5','dtlz6','dtlz7'}
            odim=2;
            mop=dtlz(mop,testname,pdim,odim);            
        case {'mdtlz1','mdtlz2','mdtlz3','mdtlz4'}
            odim=3;
            mop=mDTLZ(mop,testname,pdim,odim);  
        case {'wfg1','wfg2','wfg3','wfg4','wfg5','wfg6','wfg7','wfg8','wfg9'}
            odim=2; k=odim-1;
            mop=wfg(mop,testname,pdim,odim,k);  
        case {'lz1','lz2','lz3','lz4','lz5','lz6','lz7','lz8','lz9'}
            mop=lz(mop,testname,pdim);
        case {'zzj1','zzj2','zzj3','zzj4','zzj5','zzj6','zzj7','zzj8','zzj9','zzj10'}
            mop=zzj(mop,testname,pdim);
        case {'glt1','glt2','glt3','glt4','glt5','glt6'}
            mop=glt(mop,testname,pdim);
        case {'jy1','jy2','jy3','jy4','jy5','jy6','jym4'}
            mop=jy(mop,testname,pdim);
        case {'lgz1','lgz2','lgz3','lgz4','lgz5','lgz6','lgz7'}
            mop=lgz(mop,testname,pdim);            
        case {'wzlij1','wzlij2','wzlij3','wzlij4','wzlij5','wzlij6','wzlij7','wzlij8','wzlij9'}
            mop=wzlij(mop,testname,pdim);
        case {'wosgz1','wosgz2','wosgz3','wosgz4','wosgz5','wosgz6','wosgz7','wosgz8','wosgz9','wosgz10','wosgz11','wosgz12','wosgz13','wosgz14','wosgz15','wosgz16'}
            mop=wosgz(mop,testname,pdim);
        case {'uf1', 'uf2','uf3','uf4','uf5','uf6','uf7'}
            mop=cecproblems(mop,testname, pdim);
            mop.od=2;
        case {'uf8','uf9','uf10'}
            mop=cecproblems(mop,testname, pdim);
            mop.od=3;
        case {'r2_dtlz2_m5', 'r3_dtlz3_m5', 'wfg1_m5'}
            mop=cecproblems2(mop,testname, pdim); 
        case  {'re21', 're22', 're23', 're24', 're25'}
            mop = REP(mop, testname);
        otherwise 
            error('Undefined test problem name'); 
    end    
end
%%  KNO1 function generator
function p=kno1(p)
 p.name='KNO1';
 p.od = 2;      % dimension of objectives
 p.pd = 2;      % dimension of x
 p.domain= [0 3;0 3];   % search domain
 p.func = @evaluate;
 
 function y = evaluate(x) %KNO1 evaluation function.
    y=zeros(2,1);
    c = x(1)+x(2);
	f = 9-(3*sin(2.5*c^2) + 3*sin(4*c) + 5 *sin(2*c+2));
	g = (pi/2.0)*(x(1)-x(2)+3.0)/6.0;
	y(1)= 20-(f*cos(g));
	y(2)= 20-(f*sin(g)); 
 end
end
%%  POL function generator
function p=pol(p)
 p.name='POL';
 p.od = 2;      % dimension of objectives
 p.pd = 2;      % dimension of x
 p.domain= [-pi pi;-pi pi];   % search domain
 p.func = @evaluate;
 
 function y = evaluate(x) %KNO1 evaluation function.
	y=zeros(2,1);
	A1=0.5*sin(1)-2*cos(1)+sin(2)-1.5*cos(2);
	A2=1.5*sin(1)-cos(1)+2*sin(2)-0.5*cos(2);
	B1=0.5*sin(x(1))-2*cos(x(1))+sin(x(2))-1.5*cos(x(2));
	B2=1.5*sin(x(1))-cos(x(1))+2*sin(x(2))-0.5*cos(x(2));        
	y(1)= 1+(A1-B1)^2+(A2-B2)^2;
	y(2)= (x(1)+3)^2+(x(2)+1)^2; 
 end
end
%%
function p =convexdtlz2(p,pdim,odim)
 p.name     = 'ConvexDTLZ2';
 p.pd       = pdim;% default pd=30
 p.od       = odim;
 p.domain   = [zeros(1,pdim); ones(1,pdim)];
 p.func     = @evaluate;
 
 function y = evaluate(x)
	n   = pdim;
    g=sum((x(3:n)-0.5).^2);
    y   = zeros(1,3);
    y(1)= ((1+g)*cos(0.5*pi*x(1))*cos(0.5*pi*x(2)))^4;
    y(2)= ((1+g)*cos(0.5*pi*x(1))*sin(0.5*pi*x(2)))^4;
    y(3)= ((1+g)*sin(0.5*pi*x(1)))^4;
 end
end
%cec09 UF1 - UF10
function p=cecproblems(p, testname,dim)
 p.name=upper(testname);
 p.pd=dim;
 p.domain=xboundary(upper(testname),dim);
 p.func=cec09(upper(testname));
end

%cec09 UF11 - UF13
function p=cecproblems2(p, testname,dim)
 p.name=upper(testname);
 p.pd=dim;
 p.od=2;
 p.domain=xboundary(upper(testname),dim);
 p.func=cec09m(upper(testname));
end



