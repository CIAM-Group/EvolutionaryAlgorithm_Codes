function mop=mDTLZ(mop,testname,pdim,odim)
%%run for the test problems dtlz serious.
switch lower(testname)
    case 'mdtlz1'
        mop=mDTLZ1(mop,pdim,odim);
    case 'mdtlz2'
        mop=mDTLZ2(mop,pdim,odim);        
    case 'mdtlz3'
        mop=mDTLZ3(mop,pdim,odim);        
    case 'mdtlz4'
        mop=mDTLZ4(mop,pdim,odim);                                                      
    otherwise
        error('Undefined test problem name');
end
end
%%%%%%%%%%FUNCTIONS%%%%%%
%%
function p=mDTLZ1(p,pdim,odim)
   p.name='mDTLZ1';
   p.od=odim;
   p.pd=pdim;
   p.domain=[zeros(pdim,1) ones(pdim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(odim,1);
      g=zeros(odim,1);
      for j=1:odim
      xm=x(odim+j-1:odim:pdim,1);
      g(j)=100*(length(xm)+sum((xm-0.5).^2-cos(20*pi*(xm-0.5))));
      end
      y(1)=0.5*(1-prod(x(1:odim-1,1)))*(1+g(1));
      y(odim)=0.5*(x(1))*(1+g(odim));
      for i=2:odim-1
          y(i)=0.5*(1-prod(x(1:odim-i,1))*(1-x(odim-i+1)))*(1+g(i));
      end                        
   end
end
%% %%%%%
function p=mDTLZ2(p,pdim,odim)
   p.name='mDTLZ2';
   p.od=odim;
   p.pd=pdim;
   p.domain=[zeros(pdim,1) ones(pdim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(odim,1);
      g=zeros(odim,1);
      for j=1:odim
      xm=x(odim+j-1:odim:pdim,1);
      g(j)=sum((xm-0.5).^2);
      end
      y(1)=(1-prod(cos(pi*x(1:odim-1,1)./2)))*(1+g(1));
      y(odim)=(1-sin(pi*x(1)/2))*(1+g(odim));
      for i=2:odim-1
          y(i)=(1-prod(cos(pi*x(1:odim-i,1)./2))*sin(pi*x(odim-i+1)./2))*(1+g(i));
      end  
    end
end
%% %%%%%
function p=mDTLZ3(p,pdim,odim)
   p.name='mDTLZ3';
   p.od=odim;
   p.pd=pdim;
   p.domain=[zeros(pdim,1) ones(pdim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      y=zeros(odim,1);
      g=zeros(odim,1);
      for j=1:odim
      xm=x(odim+j-1:odim:pdim,1);
      g(j)=100*(length(xm)+sum((xm-0.5).^2-cos(20*pi*(xm-0.5))));
      end
      y(1)=(1-prod(cos(pi*x(1:odim-1,1)./2)))*(1+g(1));
      y(odim)=(1-sin(pi*x(1)/2))*(1+g(odim));
      for i=2:odim-1
          y(i)=(1-prod(cos(pi*x(1:odim-i,1)./2))*sin(pi*x(odim-i+1)./2))*(1+g(i));
      end       
    end
end
%%
function p=mDTLZ4(p,pdim,odim)
   p.name='mDTLZ4';
   p.od=odim;
   p.pd=pdim;
   p.domain=[zeros(pdim,1) ones(pdim,1)];
   p.func=@evaluate;
   function y=evaluate(x)
      a=100;
      x=x.^a;
      y=zeros(odim,1);
      g=zeros(odim,1);
      for j=1:odim
      xm=x(odim+j-1:odim:pdim,1);
      g(j)=sum((xm-0.5).^2);
      end
      y(1)=(1-prod(cos(pi*x(1:odim-1,1)./2)))*(1+g(1));
      y(odim)=(1-sin(pi*x(1)/2))*(1+g(odim));
      for i=2:odim-1
          y(i)=(1-prod(cos(pi*x(1:odim-i,1)./2))*sin(pi*x(odim-i+1)./2))*(1+g(i));
      end  
   end
end

