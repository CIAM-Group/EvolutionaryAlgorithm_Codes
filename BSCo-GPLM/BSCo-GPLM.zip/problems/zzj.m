function mop=zzj(mop,testname, dimension)
    switch lower(testname)          
        case 'zzj1'
            mop=zzj1(mop, dimension);
        case 'zzj2'
            mop=zzj2(mop, dimension);
        case 'zzj3'
            mop=zzj3(mop, dimension);
        case 'zzj4'
            mop=zzj4(mop, dimension);
        case 'zzj5'
            mop=zzj5(mop, dimension);     
        case 'zzj6'
            mop=zzj6(mop, dimension); 
        case 'zzj7'
            mop=zzj7(mop, dimension); 
        case 'zzj8'
            mop=zzj8(mop, dimension); 
        case 'zzj9'
            mop=zzj9(mop, dimension); 
        case 'zzj10'
            mop=zzj10(mop, dimension);                        
        otherwise 
            error('Undefined test problem name');                
    end 
end
function p = zzj1(p,dim)
 p.name     = 'ZZJ1';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:);
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end

%%
function p = zzj2(p,dim)
 p.name     = 'ZZJ2';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:);
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj3(p,dim)
 p.name     = 'ZZJ3';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:);
    G   = 1.0 + 9.0*((X1 - X(1))'*(X1 - X(1))/9.0)^0.25;

    F(1)= 1.0-exp(-4.0*X(1))*sin(6.0*pi*X(1)).^6.0;
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj4(p,dim)
 p.name     = 'ZZJ4';
 p.pd       = dim;
 p.od       = 3;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(3,1);
    N   = size(X,1);
    X1  = X(3:N,:);
    G   = (X1 - X(1))'*(X1 - X(1));
    
    F(1) = cos(0.5*pi*X(1))*cos(0.5*pi*X(2))*(1.0+G);
    F(2) = cos(0.5*pi*X(1))*sin(0.5*pi*X(2))*(1.0+G);    
    F(3) = sin(0.5*pi*X(1))*(1.0+G);
end
end

%%
function p = zzj5(p,dim)
 p.name     = 'ZZJ5';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:).^2.0;
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end

%%
function p = zzj6(p,dim)
 p.name     = 'ZZJ6';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:).^2.0;
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj7(p,dim)
 p.name     = 'ZZJ7';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:).^2.0;
    G   = 1.0 + 9.0*((X1 - X(1))'*(X1 - X(1))/9.0)^0.25;

    F(1)= 1.0-exp(-4.0*X(1))*sin(6.0*pi*X(1)).^6.0;
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj8(p,dim)
 p.name     = 'ZZJ8';
 p.pd       = dim;
 p.od       = 3;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(3,1);
    N   = size(X,1);
    X1  = X(3:N,:).^2.0;
    G   = (X1 - X(1))'*(X1 - X(1));
    
    F(1) = cos(0.5*pi*X(1))*cos(0.5*pi*X(2))*(1.0+G);
    F(2) = cos(0.5*pi*X(1))*sin(0.5*pi*X(2))*(1.0+G);    
    F(3) = sin(0.5*pi*X(1))*(1.0+G);
end
end

%%
function p = zzj9(p,dim)
 p.name     = 'ZZJ9';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = (X(2:N,:)*10.0).^2.0;
    G   = 2.0 + (X1 - X(1))'*(X1 - X(1))/(4000.0)+ prod(cos((X1-X(1))./((1:N-1)'.^0.5)));

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end

%%
function p = zzj10(p,dim)
 p.name     = 'ZZJ10';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = (X(2:N,:)*10.0).^2.0;
    G   = 1.0 + 10.0*(N-1) + (X1 - X(1))'*(X1 - X(1))/(4000.0)- 10.0*sum(cos(2*pi*(X1-X(1))));

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end
